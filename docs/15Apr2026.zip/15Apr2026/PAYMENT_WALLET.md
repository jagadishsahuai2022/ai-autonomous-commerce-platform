﻿# DelegateCart — Payment & Wallet Integration

> **Round 57 — April 15, 2026**

---

## 1. Overview

DelegateCart supports internal wallet payments and external payment gateway integration. The wallet is the primary payment method for autonomous checkout.

---

## 2. Wallet Architecture

```
User → "Add Funds" → Payment Gateway (Stripe/Razorpay) → Webhook
     → WalletTransaction(credit, idempotencyKey=paymentIntentId)
     → User.walletBalance += amount

User → Checkout → AutopilotPaymentExecutor
     → IdempotencyGuard.check(orderId + userId) in Redis
     → If not seen: WalletTransaction(debit, amount, orderId)
     → User.walletBalance -= amount
     → Order.paymentStatus = 'PAID'
     → IdempotencyGuard.mark(orderId + userId)
```

---

## 3. Data Model

```sql
-- WalletTransaction
CREATE TABLE "WalletTransaction" (
  "id"              SERIAL PRIMARY KEY,
  "userId"          INTEGER REFERENCES "User"("id"),
  "amount"          DECIMAL(12,2) NOT NULL,          -- positive=credit, negative=debit
  "type"            TEXT NOT NULL,                    -- 'credit' | 'debit' | 'refund'
  "orderId"         INTEGER REFERENCES "Order"("id"), -- null for fund additions
  "idempotencyKey"  TEXT UNIQUE,                      -- prevents duplicate charges
  "status"          TEXT NOT NULL DEFAULT 'completed', -- 'pending' | 'completed' | 'failed'
  "gateway"         TEXT,                             -- 'stripe' | 'razorpay' | 'internal'
  "gatewayTxnId"    TEXT,                             -- external reference
  "createdAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- User balance (denormalized for performance)
ALTER TABLE "User" ADD COLUMN "walletBalance" DECIMAL(12,2) NOT NULL DEFAULT 0;
```

---

## 4. Idempotency for Payments

Every debit operation must include an `idempotencyKey`:
- Format: `{userId}:{orderId}:{timestamp-rounded-to-minute}`
- Stored in Redis with 24hr TTL: `SET idempotency:{key} "processed" EX 86400`
- Before executing payment: `GET idempotency:{key}` — if exists, return cached result
- After executing: set the Redis key

For external webhooks: use `paymentIntentId` from the gateway as the idempotency key.

---

## 5. Autonomous Checkout Payment Step

```typescript
// apps/autopilot-engine/src/steps/PaymentExecutor.ts (pattern)
async execute(order: Order, user: User) {
  const key = `${user.id}:${order.id}`;
  
  // Check idempotency
  const cached = await redis.get(`idempotency:${key}`);
  if (cached) return JSON.parse(cached);
  
  // Validate balance
  if (user.walletBalance < order.total) {
    throw new InsufficientFundsError(order.total - user.walletBalance);
  }
  
  // Execute in transaction
  const result = await db.transaction(async (trx) => {
    await trx.query(
      'UPDATE "User" SET "walletBalance" = "walletBalance" - $1 WHERE "id" = $2',
      [order.total, user.id]
    );
    await trx.query(
      'INSERT INTO "WalletTransaction"("userId","amount","type","orderId","idempotencyKey") VALUES($1,$2,$3,$4,$5)',
      [user.id, -order.total, 'debit', order.id, key]
    );
    await trx.query(
      'UPDATE "Order" SET "paymentStatus" = $1, "paidAt" = NOW() WHERE "id" = $2',
      ['PAID', order.id]
    );
    return { success: true, transactionId: key };
  });
  
  // Cache result
  await redis.set(`idempotency:${key}`, JSON.stringify(result), 'EX', 86400);
  return result;
}
```

---

## 6. External Payment Gateway Webhook

```typescript
// POST /api/payments/webhook (Next.js API route)
// Signature verification first — never trust unverified webhooks
const sig = req.headers['stripe-signature'];
const event = stripe.webhooks.constructEvent(rawBody, sig, WEBHOOK_SECRET);

if (event.type === 'payment_intent.succeeded') {
  const pi = event.data.object;
  // Idempotent credit — won't double-credit if webhook fires twice
  await creditWallet(pi.metadata.userId, pi.amount/100, pi.id);
}
```

---

## 7. Refund Flow

```
Order cancellation → PaymentRefundService
  → Check Order.paymentStatus === 'PAID'
  → WalletTransaction(type='refund', amount=+order.total)
  → User.walletBalance += order.total
  → Order.paymentStatus = 'REFUNDED'
  → Notification: "Your refund of ₹{amount} has been processed"
```

---

## 8. Security Controls

| Threat | Mitigation |
|--------|-----------|
| Double-debit | Idempotency key in Redis + DB UNIQUE constraint on idempotencyKey |
| Webhook spoofing | Stripe signature verification with HMAC |
| Negative balance | Pre-check balance before debit |
| Concurrent debit | DB transaction + row-level lock (`SELECT FOR UPDATE`) |
| Admin balance manipulation | Wallet updates only via service layer; direct DB access requires 2-person review |
