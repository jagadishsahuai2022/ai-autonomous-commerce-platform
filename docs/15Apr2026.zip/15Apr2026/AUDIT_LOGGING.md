﻿# DelegateCart — Audit Logging & Error Handling

> **Round 57 — April 15, 2026**

---

## 1. Audit Trail Design

### 1.1 Learning Dashboard Audit (SmartIntentEngineResponse.comments)

Every admin action on a learning record is appended as a JSON entry to the `comments` JSONB array:

```typescript
interface AuditEntry {
  text: string;          // human-readable description
  timestamp: string;     // ISO 8601
  userId: string;        // admin email
  action: AuditAction;
}

type AuditAction =
  | 'created'               // record first inserted by system
  | 'supervisor_edited'     // admin changed supervisedResponse
  | 'ai_enriched'           // batch LLM enrichment ran
  | 'toggled_active'        // active/inactive toggled
  | 'duplicate_deactivated' // duplicate auto-deactivated
```

Example `comments` array:
```json
[
  { "action": "created", "text": "Auto-captured from query", "timestamp": "2026-04-10T08:00:00Z", "userId": "system" },
  { "action": "supervisor_edited", "text": "Supervised response updated by admin", "timestamp": "2026-04-10T09:15:00Z", "userId": "admin@delegatecart.com" },
  { "action": "ai_enriched", "text": "AI enriched using gpt-4", "timestamp": "2026-04-10T10:00:00Z", "userId": "admin@delegatecart.com" }
]
```

### 1.2 Order Audit Trail

Order state transitions are logged in `OrderStatusHistory`:
```sql
CREATE TABLE "OrderStatusHistory" (
  "id"        SERIAL PRIMARY KEY,
  "orderId"   INTEGER REFERENCES "Order"("id"),
  "status"    TEXT NOT NULL,
  "changedBy" INTEGER REFERENCES "User"("id"),
  "reason"    TEXT,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

## 2. Application Logging

### Next.js API Routes
```typescript
// Logging pattern in /api/admin/learning/route.ts
console.log(`[learning-api] GET params: page=${page} limit=${pageSize} sort=${sortField} filterQueryBy=${filterQueryBy}`);
// Errors:
console.error('[learning-api] DB error:', error);
return NextResponse.json({ error: 'Failed to fetch records' }, { status: 500 });
```

### NestJS
```typescript
// All modules use NestJS built-in logger
private readonly logger = new Logger(LearningService.name);

this.logger.log(`Enriching record ${id} with model ${model}`);
this.logger.error(`Enrichment failed for ${id}`, error.stack);
```

Log levels: `verbose` < `debug` < `log` < `warn` < `error`

---

## 3. Error Handling Patterns

### 3.1 AI Enrichment — Per-Record Error Collection
```typescript
// Enrichment does NOT stop on single record failure
const errors: Record<number, string> = {};
for (const id of selectedIds) {
  try {
    await enrichRecord(id, model);
  } catch (err) {
    errors[id] = err.message;
    // Continue to next record
  }
}
// Show errors in UI after all records processed
```

### 3.2 Next.js API Route Error Handling
```typescript
try {
  const result = await getSmartIntentRecords(...);
  return NextResponse.json(result);
} catch (error) {
  console.error('[learning-api] Error:', error);
  return NextResponse.json(
    { error: 'Internal server error', records: [], total: 0 },
    { status: 500 }
  );
}
```

### 3.3 Frontend Error States
- API failures show toast notification: `toast.error('Failed to load records')`
- AI enrichment failures shown in progress overlay with per-record error list
- Chat query failures show inline error message in chat: assistant message with error text

---

## 4. Security-Relevant Audit Events

| Event | Where logged |
|-------|-------------|
| Admin login / logout | NextAuth event log |
| Admin learning page access | Server component logs + `x-user-email` header check |
| Enrichment batch triggered | `comments` JSONB + console.log |
| Supervised response edited | `comments` JSONB |
| Record active/inactive toggle | `comments` JSONB |
| Payment executed | `WalletTransaction` record |
| Order status changed | `OrderStatusHistory` |
| Push subscription created | DB `PushSubscription` + timestamp |

---

## 5. Structured Error Responses

All API routes return consistent error shapes:
```typescript
// Success
{ data: T, error: null }

// Error
{ data: null, error: string, code?: string }
// HTTP status codes: 400 (bad input), 401 (unauth), 403 (forbidden), 404 (not found), 500 (server error)
```

---

## 6. Monitoring Hooks

- `console.error` calls are caught by Docker logging driver
- All Docker logs available via: `docker logs ai-commerce-web --tail 100 -f`
- Database slow query log enabled (pg config: `log_min_duration_statement = 1000`) for queries > 1s
- Redis connection errors trigger service restart (Docker `restart: unless-stopped`)
