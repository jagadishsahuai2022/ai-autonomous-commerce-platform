﻿# DelegateCart — AI Search & LLM Integration

> **Round 57 — April 15, 2026**

---

## 1. Architecture

```
User Query (natural language)
    ↓
Next.js POST /api/ai/shopping-intent
    ↓
NestJS AIModule → ShoppingIntentService
    ↓
    ├─ IntentParser (Node.js microservice :8001)
    │      → Regex + rule-based extraction
    │      → Optional: LLM refinement
    │      → Output: IntentResult { budget, category, preferences, missingParams }
    │
    ├─ QuestionGenerator (Python ai-service :8000)
    │      → Takes missingParams
    │      → LLM generates clarifying questions
    │      → Returns: Question[] with multiple-choice options
    │
    ├─ (User answers questions)
    │
    ├─ ProductAggregator (Node.js :8002)
    │      → Fetches from internal ProductDB
    │      → Fetches from external vendor APIs (if enabled)
    │      → Deduplicates + normalizes
    │
    └─ ProductRankingEngine (Node.js :8003)
           → Applies weighted 5-dimension scoring
           → Returns RankedProduct[] sorted by composite score
```

---

## 2. LLM Provider Support

The ai-service (Python/FastAPI) supports multiple LLM providers:

| Provider | Models | Usage |
|----------|--------|-------|
| OpenAI | gpt-4, gpt-4o, gpt-3.5-turbo | Enrichment, question gen |
| Anthropic | claude-3-opus, sonnet, haiku | Alternative enrichment |
| Ollama (local) | llama3, mistral | Dev/test without API costs |

Model selection at enrichment time is configurable per batch operation in the Learning Dashboard.

---

## 3. Intent Parsing

### Input
```
"best laptop under 50k for gaming with good battery"
```

### Extraction Algorithm (rule-based first, LLM fallback)

```typescript
// apps/intent-parser/src/parser.ts pattern
function parseIntent(query: string): IntentResult {
  const result: IntentResult = { missingParams: [] };
  
  // Budget extraction
  const budgetMatch = query.match(/(?:under|below|upto|within)\s*(?:₹|rs\.?)?\s*(\d[\d,]*)/i);
  if (budgetMatch) result.budget = parseINR(budgetMatch[1]);
  else result.missingParams.push('budget');
  
  // Category extraction
  result.category = detectCategory(query); // 'laptop' | 'phone' | etc.
  
  // Preference extraction
  if (/gaming/i.test(query)) result.preferences.gaming = true;
  if (/battery/i.test(query)) result.preferences.battery = 'high';
  
  // Missing params → will generate questions for these
  if (!result.preferences.use_case) result.missingParams.push('use_case');
  
  return result;
}
```

### Output
```json
{
  "category": "laptop",
  "budget": 50000,
  "preferences": { "gaming": true, "battery": "high" },
  "missingParams": ["use_case", "portability"],
  "confidence": 0.85
}
```

---

## 4. Product Ranking Algorithm

### Weights
```
budget_fit   25% — price vs stated budget
quality      25% — review quality signals
brand_trust  20% — brand reputation tier
delivery     15% — speed of delivery
ratings      15% — user star ratings
```

### Scoring per dimension
```typescript
function scoreBudgetFit(price: number, budget: number): number {
  if (price <= budget) return Math.min(1, 1 - (price / budget - 0.5)); // reward being under budget
  const overage = (price - budget) / budget;
  return Math.max(0, 1 - overage * 2); // penalize >50% over budget → 0
}

function scoreDelivery(deliveryDays: number): number {
  return Math.max(0, 1 - deliveryDays / 30); // 0-day=1.0, 30-day=0.0
}

function scoreRatings(starRating: number): number {
  return (Math.max(1, Math.min(5, starRating)) - 1) / 4; // 5=1.0, 1=0.0
}
```

### Final Score
```typescript
const score = Math.round(
  (budgetFit * 0.25 + quality * 0.25 + brandTrust * 0.20 + delivery * 0.15 + ratings * 0.15) * 100
);
```

---

## 5. Admin LLM Enrichment Pipeline

```
Admin selects records → chooses model → clicks "Enrich"
    ↓
For each record:
  Build enrichment prompt:
    "Given this shopping query: {queryText}
     Initial intent: {intentEngineResponse JSON}
     Improve the intent classification. Return JSON with:
     { category, budget, preferences, improvements, confidence }"
    ↓
  POST to ai-service /enrich
    ↓
  Store result in SmartIntentEngineResponse.aiEnrichedResponse
  Set enhancedByAI = true
  Append audit comment
```

---

## 6. External Product Fallback

When internal product DB has < 5 results for a query:
```
ProductAggregator detects low result count
    ↓
Calls external vendor APIs (configurable):
  - Flipkart Product API
  - Amazon Product Advertising API
  - Custom vendor webhooks
    ↓
Results normalized to internal RawProduct format
Marked as isExternal=true
    ↓
Combined with internal results and ranked
External products shown with "External" badge in UI
```

---

## 7. Response Format

```typescript
// Final API response
interface ShoppingIntentResponse {
  questions?: Question[];        // if more info needed
  products?: RankedProduct[];    // when ready to show
  explanation?: string;          // markdown explanation
  timeline?: TimelineStep[];     // performance data
}

interface RankedProduct {
  id: string; name: string; brand: string;
  price: number; originalPrice?: number;
  score: number;                 // 0–100 composite
  rating?: number;               // star rating 1–5
  deliveryDays?: number;
  features?: string[];
  isExternal?: boolean;
  scoreBreakdown?: {
    budget: number; quality: number; brand: number;
    delivery: number; ratings: number;
  };
}
```
