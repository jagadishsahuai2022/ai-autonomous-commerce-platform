﻿# DelegateCart — Notification API

> **Round 57 — April 15, 2026**

---

## 1. Overview

DelegateCart has three notification channels:
1. **In-app** — bell icon badge + notification center drawer
2. **WebSocket real-time** — instant push while user is online
3. **Browser Push** — Service Worker push notifications (offline support)

---

## 2. Data Model

```sql
CREATE TABLE "Notification" (
  "id"          SERIAL PRIMARY KEY,
  "userId"      INTEGER REFERENCES "User"("id") ON DELETE CASCADE,
  "type"        TEXT NOT NULL,      -- 'order_placed' | 'payment_processed' | 'price_drop' | 'recommendation' | ...
  "title"       TEXT NOT NULL,
  "body"        TEXT NOT NULL,
  "data"        JSONB,              -- type-specific payload (orderId, productId, ...)
  "isRead"      BOOLEAN NOT NULL DEFAULT FALSE,
  "readAt"      TIMESTAMPTZ,
  "createdAt"   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notif_user_unread ON "Notification"("userId", "isRead") WHERE "isRead" = FALSE;

CREATE TABLE "PushSubscription" (
  "id"          SERIAL PRIMARY KEY,
  "userId"      INTEGER REFERENCES "User"("id") ON DELETE CASCADE,
  "endpoint"    TEXT NOT NULL UNIQUE,
  "p256dh"      TEXT NOT NULL,
  "auth"        TEXT NOT NULL,
  "createdAt"   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

## 3. NestJS Notification Module

### NotificationService — key methods

```typescript
// Create + deliver notification
async createNotification(userId: number, type: NotifType, title: string, body: string, data?: object) {
  // 1. Persist to DB
  const notif = await prisma.notification.create({ data: { userId, type, title, body, data } });
  
  // 2. Emit WebSocket event (if user is online)
  this.gateway.emitToUser(userId, 'notification', { id: notif.id, type, title, body, data });
  
  // 3. Send browser push (if subscription exists)
  const sub = await prisma.pushSubscription.findFirst({ where: { userId } });
  if (sub) {
    await webpush.sendNotification({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
      JSON.stringify({ title, body, data })
    );
  }
  
  return notif;
}

// Mark all as read
async markAllRead(userId: number) {
  await prisma.notification.updateMany({
    where: { userId, isRead: false },
    data: { isRead: true, readAt: new Date() }
  });
  this.gateway.emitToUser(userId, 'notifications_cleared', {});
}
```

### NotificationGateway (WebSocket)

```typescript
@WebSocketGateway({ cors: { origin: process.env.FRONTEND_URL } })
export class NotificationGateway {
  @WebSocketServer() server: Server;
  
  // User joins their personal room on connect
  handleConnection(client: Socket) {
    const userId = extractUserId(client);
    client.join(`user:${userId}`);
  }
  
  emitToUser(userId: number, event: string, data: object) {
    this.server.to(`user:${userId}`).emit(event, data);
  }
}
```

---

## 4. Notification Types

| Type | Trigger | Payload |
|------|---------|---------|
| `order_placed` | Order created | `{ orderId, total, itemCount }` |
| `payment_processed` | Wallet debit | `{ amount, orderId, balance }` |
| `price_drop` | Product price falls below target | `{ productId, name, oldPrice, newPrice }` |
| `recommendation` | AI generates new recommendations | `{ queryText, productCount }` |
| `autopilot_complete` | Autonomous checkout finishes | `{ orderId, steps }` |
| `autopilot_failed` | Autonomous checkout fails | `{ step, reason }` |
| `wallet_credited` | Funds added to wallet | `{ amount, newBalance }` |

---

## 5. Frontend Integration

### WebSocket client (in shopping assistant page)

```typescript
// apps/web/hooks/useNotifications.ts (pattern)
const socket = io(process.env.NEXT_PUBLIC_WS_URL!, { autoConnect: false });

useEffect(() => {
  socket.connect();
  socket.on('notification', (notif) => {
    addToast(notif.title, notif.body);
    setBadgeCount(c => c + 1);
  });
  socket.on('notifications_cleared', () => setBadgeCount(0));
  return () => socket.disconnect();
}, []);
```

### Bell Icon Badge

```tsx
// In navigation header
<button onClick={openNotificationCenter}>
  <Bell className="w-5 h-5" />
  {unreadCount > 0 && (
    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
      {unreadCount > 9 ? '9+' : unreadCount}
    </span>
  )}
</button>
```

---

## 6. Browser Push Setup (Service Worker)

```javascript
// public/sw.js
self.addEventListener('push', event => {
  const data = event.data?.json() ?? {};
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: '/icon-192x192.png',
      data: data.data
    })
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = `/orders/${event.notification.data?.orderId}`;
  event.waitUntil(clients.openWindow(url));
});
```

---

## 7. Rate Limiting

- Max 10 notifications per user per minute (Redis counter with TTL)
- Bulk price-drop notifications: batched per user (one notification for N products)
- Push notification dedup: if same `orderId` notification already sent within 5 minutes, skip push
