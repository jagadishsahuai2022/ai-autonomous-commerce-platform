﻿# DelegateCart — Agentic AI Integration

> **Round 57 — April 15, 2026**

---

## 1. What "Agentic AI" Means Here

DelegateCart uses a multi-step agentic flow where the AI:
1. **Parses intent** from free-text user input
2. **Generates clarifying questions** based on missing parameters
3. **Waits for user responses** (human-in-the-loop)
4. **Executes product search** with enriched parameters
5. **Ranks products** using a weighted multi-dimension scoring model
6. **Provides explanation** for its recommendations

This is "agentic" because the AI takes sequential, goal-directed steps — not just a single prompt → response.

---

## 2. Pipeline Stages

```
Stage 1: INTENT ANALYSIS
  Input: raw query string (e.g., "best laptop under 50k for gaming")
  Tool: intent-parser microservice + LLM
  Output: IntentResult {
    category, budget, preferences, missingParams, confidence
  }

Stage 2: QUESTION GENERATION
  Input: IntentResult (specifically missingParams)
  Tool: question-generator (part of ai-service)
  Output: Question[] — multiple choice questions like:
    "What's your primary use case?" [Gaming, Work, Both]
    "Do you prefer lightweight or performance?" [Lightweight, Performance, Balanced]

Stage 3: ANSWER COLLECTION
  Mechanism: React ChoiceMessage UI component
  User clicks option → appended to answeredParams
  All questions answered → Stage 4 triggered

Stage 4: PRODUCT SEARCH
  Input: IntentResult + answeredParams
  Tool: product-aggregator (calls vendor APIs + internal DB)
  Output: RawProduct[]

Stage 5: PRODUCT RANKING
  Input: RawProduct[] + budget + preferences + answeredParams
  Tool: product-ranking-engine
  Algorithm: Weighted scoring across 5 dimensions:
    budget_fit  25%  — how well price matches stated budget
    quality     25%  — review scores, durability signals
    brand_trust 20%  — brand reputation tier
    delivery    15%  — delivery speed score
    ratings     15%  — star ratings (normalized)
  Output: RankedProduct[] sorted by composite score (higher = better)

Stage 6: RESPONSE GENERATION
  Tool: response-formatter
  Output: Markdown explanation + product card list
```

---

## 3. Integration Points

### 3.1 Next.js → NestJS AI Endpoint

```
POST /api/ai/shopping-intent
Body: { query: string, sessionId: string, answers?: Record<string, string> }
Response: {
  questions?: Question[]
  products?: RankedProduct[]
  explanation?: string
  timeline?: TimelineStep[]   // each step with duration in ms
}
```

### 3.2 NestJS → AI Microservices

| NestJS Module | Microservice | Protocol | Endpoint |
|--------------|-------------|----------|----------|
| AIModule | intent-parser | HTTP | POST /parse |
| AIModule | ai-service (Python) | HTTP | POST /enrich, POST /questions |
| AIModule | product-aggregator | HTTP | GET /search |
| AIModule | product-ranking-engine | HTTP | POST /rank |

### 3.3 LLM Integration (ai-service Python)

```python
# apps/ai-service/app/main.py pattern
@app.post("/enrich")
async def enrich_intent(req: EnrichRequest):
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": build_enrichment_prompt(req.query, req.intent)}
    ]
    response = await openai_client.chat.completions.create(
        model=req.model,
        messages=messages,
        response_format={"type": "json_object"}
    )
    return parse_enrichment_response(response.choices[0].message.content)
```

---

## 4. Self-Learning Integration (Round 30)

After every successful agentic flow completion:
1. **Auto-capture** to `SmartIntentEngineResponse` table
2. Fields captured: `queryBy` (user email/session), `queryText`, `intentEngineResponse` (Stage 1 output), `initialProductSuggestionText` (Stage 6 output)
3. Admin can later view/correct as supervised learning data
4. Batch LLM enrichment can improve `aiEnrichedResponse` field

---

## 5. AI Score Dimensions (Detail)

| Dimension | Weight | How calculated |
|-----------|--------|----------------|
| `budget_fit` | 25% | `max(0, 1 - (price - budget) / budget)` — 0 if over budget |
| `quality` | 25% | Weighted avg of review text sentiment + product rating |
| `brand_trust` | 20% | Brand tier lookup: Tier1=1.0, Tier2=0.7, Unknown=0.4 |
| `delivery` | 15% | `1 - (deliveryDays / 30)` — same-day=1.0, 30-day=0.0 |
| `ratings` | 15% | `(starRating - 1) / 4` — 5-star=1.0, 1-star=0.0 |

Final score = sum(dimension × weight) × 100

---

## 6. Question Generation Strategy

Questions are only generated for `missingParams` — parameters not derivable from the query:

| Missing Param | Generated Question | Options |
|--------------|-------------------|---------|
| `use_case` | "What's the primary use?" | [Gaming, Work, Both, Creative, Study] |
| `portability` | "Prefer lightweight or performance?" | [Lightweight, Performance, Balanced] |
| `display_preference` | "Screen size preference?" | [13-inch, 15-inch, 17-inch+] |
| `brand_preference` | "Brand preference?" | [Any, Premium only, Value for money] |
| `delivery_urgency` | "How soon do you need it?" | [Today, Within a week, No rush] |

Maximum 3 questions generated per session to avoid fatigue.

---

## 7. Failover Behavior

| Failure | Behavior |
|---------|---------|
| intent-parser down | Fall back to keyword extraction (regex-based) |
| ai-service down | Skip question generation, proceed with direct search |
| product-aggregator down | Use internal product DB only |
| product-ranking-engine down | Sort by price as fallback |
| All AI services down | Show "AI features temporarily unavailable" message; still show keyword-matched products |
