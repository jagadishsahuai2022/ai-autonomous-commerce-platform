﻿# Round 57 — Release Notes (15 April 2026)

## Summary

R57 fixes a critical product detail mismatch bug (listing showed correct products, detail page showed random mock data), normalizes 100,000 product image URLs, hardens the web API layer against synthetic data leakage, and fixes infinite scroll / count widget UX issues.

---

## Critical Bug Fixed: Product Detail Mismatch

**Root cause chain:**
1. `ProductService.findOne()` called `this.prisma.findProductById(id, [...])` — but `findProductById` was not available at runtime in Docker (stale build), throwing `TypeError: this.prisma.findProductById is not a function`
2. Backend returned **500** on every `GET /products/:id` request
3. Web detail route (`/api/products/[id]`) silently fell through to synthetic mock data generation
4. Mock generator used `(id - 1) % totalProducts` which mapped to a completely different product name and category
5. Result: clicking "Apple Aspire 5 Eco" (Laptops) on listing showed "Hawkins Kadai 28cm" (Cookware) on detail page

---

## Changes

### 1. API Product Service Fix

**File changed:** `apps/api/src/modules/product/product.service.ts`

- Replaced `this.prisma.findProductById(id, [...fields])` with `this.prisma.product.findUnique({ where: { id } })`
- Uses Prisma model directly — no custom wrapper method dependency
- Unit tests updated in `product.service.spec.ts` to match new mock pattern

### 2. Database Image URL Normalization

**Migration:** `scripts/r57-db-imageurl-normalization.sql`

- All 100,000 Product rows had relative `imageUrl` paths (`/images/products/smartphones/1.webp`) pointing to non-existent files
- Migrated to absolute URLs: `https://loremflickr.com/640/640/{category_keyword}?lock={id}`
- Category-specific keywords: smartphone, laptop, headphones, television, camera, tablet, smartwatch, speaker, printer, gaming-console, refrigerator, washing-machine, microwave, air-conditioner, vacuum, mens-fashion, womens-fashion, kids-fashion, sports-shoes, backpack

### 3. Web Products Listing Route Hardened

**File changed:** `apps/web/app/api/products/route.ts`

- Added `toPublicImageUrl(raw)` helper — normalizes relative DB paths and Docker-internal URLs to absolute public URLs
- Image enrichment now prefers `toPublicImageUrl(p.imageUrl)` over synthetic category images
- Synthetic/mock product fallback **disabled by default** — requires `allowSynthetic=true` query param or `ENABLE_SYNTHETIC_PRODUCTS` env
- Added `page`/`limit` param support alongside `skip`/`take`

### 4. Web Product Detail Route Hardened

**File changed:** `apps/web/app/api/products/[id]/route.ts`

- Same `toPublicImageUrl()` helper added
- Image enrichment prefers DB `imageUrl` over synthetic generation
- Mock/synthetic fallback **disabled by default** — returns 404 with `dataSource: 'database-only'` when backend fails
- Explicit opt-in required: `allowSynthetic=true` query param

### 5. Infinite Scroll Fix

**File changed:** `apps/web/hooks/useProducts.ts`

- Removed `maxPages: 50` hard limit that capped scroll at 1,000 products (50 × 20)
- All 100,000 products now accessible via infinite scroll

### 6. Product Count Widget Fix

**File changed:** `apps/web/app/products/page.tsx`

- Changed count badge condition to `totalProducts > 0` — badge now correctly shows "80 / 100,000" style counts during loading

---

## Database State After R57

| Metric | Value |
|--------|-------|
| Total Products | 100,000 |
| Categories | 20 (5,000 products each) |
| Image URLs | Absolute (loremflickr CDN) |
| Product columns | id, name, price, category, description, imageUrl, featured, eligibleForReplacement, eligibleForReturn, eligibleForVirtualTryOn, createdAt, updatedAt |

---

## Docker

- Image: `delegatecart-web:r57`, `delegatecart-api:r57`
- Requires rebuild after R57 changes: `docker compose build api web`
- Container: `dc-web-r39`
- Port: `3010`
- Network: `delegatecart_ai-commerce-network`
- Database: `postgresql://admin:password@ai-commerce-postgres:5432/ai_commerce?schema=public`

## Testing

- E2E: `round39-comprehensive.spec.ts` — covers impersonation, RBAC visibility, cross-user data, per-search validation
- Video proof: Screenshots captured for all 6 non-admin roles + admin impersonation flow
- R35 regression: Maintained compatibility with existing 45/47 baseline
