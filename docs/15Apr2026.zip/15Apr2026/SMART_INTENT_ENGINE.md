﻿# DelegateCart — Smart Intent Engine: Logic, Workflow & Technical KT

## What Is the Smart Intent Engine?

The Smart Intent Engine (SIE) is a **rule-based + ML-hybrid system** that converts free-form natural language shopping queries into structured intent objects, clarifying questions, and ranked product lists — without requiring a full LLM call for every interaction.

---

## File Map

```
apps/web/lib/smart-intent/
  intent-engine.ts        — Main engine class (analyzeIntent, answerQuestion, resolveProducts)
  intent-classifier.ts    — Rule-based category + constraint extraction
  question-generator.ts   — Generates clarifying questions from intent gaps
  product-search.ts       — Catalog search + filter application
  response-builder.ts     — Formats final recommendation list

apps/web/app/api/intent/
  analyze/route.ts        — POST /api/intent/analyze
  answer/route.ts         — POST /api/intent/answer  
  external-products/route.ts — POST /api/intent/external-products (fallback catalog)

apps/api/src/smart-intent/  — NestJS mirror for API service integration
```

---

## Core Data Structures

### IntentData
```typescript
{
  user_intent: string;          // raw query
  category: string;             // detected category (laptop, phone, headphone, ...)
  budget: { min: number; max: number } | null;
  constraints: string[];        // ["wireless", "noise-cancelling", ...]
  preferences: Record<string, string>; // { brand: "Sony", color: "black" }
  questions_needed: string[];   // ids of missing dimensions
  confidence: number;           // 0-1
}
```

### ClarifyingQuestion
```typescript
{
  id: string;
  text: string;
  type: 'multiple_choice' | 'range' | 'yes_no';
  options?: string[];
  category: string;             // budget | brand | features | delivery | usage
}
```

### RankedProduct
```typescript
{
  rank: number;
  product: { id, name, brand, price, rating, review_count, delivery_time, key_features, source, imageUrl, isExternal? };
  score: number;         // composite 0-1
  confidence: number;    // AI confidence in this ranking
  explanation: {
    final_score: number;
    summary: string;
    key_strengths: string[];
    key_weaknesses: string[];
    budget_fit_score: { score, reason };
    quality_score: { score, reason };
    brand_preference_score: { score, reason };
    delivery_speed_score: { score, reason };
    ratings_score: { score, reason };
  }
}
```

---

## Workflow

### Phase 1: Intent Analysis (`analyzeIntent`)
```
User Query → intent-classifier
  ├── Category Detection: regex patterns (priority order: headphone > phone > laptop > ...)
  ├── Budget Extraction: /under (\d+k?)|(\d+)k_(\d+)k|between/
  ├── Brand Detection: /sony|apple|samsung|oneplus|realme/i
  ├── Feature Extraction: /wireless|noise.cancel|waterproof|fast.charg/i
  └─▶ IntentData + questions_needed list
       └── question-generator: generates ClarifyingQuestion[] for missing dimensions
           └─▶ addMessage({ type: 'clarifying_question', questions })
```

### Phase 2: Answer Collection (`answerQuestion`)
```
For each answer:
  ├── Store answer in server session ({userId}_{questionId} → answer)
  ├── Update IntentData constraints & preferences
  ├── Check if all required questions answered
  └── If (answers_collected < total_questions):
       └─▶ { ready: false, answers_collected, total_questions }
      If (answers_collected >= total_questions):
       └── product-search (with full IntentData)
           └─▶ { ready: true, products: RankedProduct[] }
```

### Phase 3: Product Search & Ranking
```
ProductSearch (lib/smart-intent/product-search.ts):
  1. SELECT * FROM "Product" WHERE category ILIKE $1
  2. Apply budget filter: price BETWEEN min AND max * 1.2
  3. Apply brand filter (if specified)
  4. Apply feature filter (jsonb key_features @> ?)
  5. Sort by rating DESC LIMIT 50

RankingEngine (product-ranking-engine):
  For each product:
    budget_score    = 1 - abs(price - budget.max) / budget.max      (weight 0.25)
    quality_score   = rating / 5 * reviewCountBoost                  (weight 0.25)
    brand_score     = brandMatchLookup[brand] ?? 0.7                 (weight 0.20)
    delivery_score  = 1 - daysMin / 10                               (weight 0.15)
    ratings_score   = min(review_count / 1000, 1)                    (weight 0.15)
    
    final_score = Σ(dimension_score × weight)
  
  Sort by final_score DESC → top 8 products → RankedProduct[]
```

### Phase 4: External Fallback (`/api/intent/external-products`)
```
Triggered when: products.length === 0 AND showExternalProducts === true

EXTERNAL_CATALOGUE (route.ts):
  ├── 11 categories × 3-8 products each
  ├── Category detection (regex, priority order — headphone before phone)
  ├── Budget extraction from answers
  └── Returns top 4 filtered products { isExternal: true }

Displayed with amber "External" badge in ProductRecommendationCarousel
```

---

## Self-Learning Feedback Loop

```
Every query processed:
  └─▶ INSERT SmartIntentEngineResponse {
        queryBy: session email,
        queryText: user query,
        intentEngineResponse: { category, budget, constraints, questions },
        isActive: true
      }

Admin Dashboard (/admin/learning):
  ├── Server-side paginated grid (DB-side filtering, sorting, paging)
  ├── Supervisor can edit "supervised response" (correct intent classification)
  ├── AI Enrichment batch (call LLM to generate aiEnrichedResponse)
  └── Active records feed back into ranking as boosted signals (planned v2)
```

---

## Security Considerations

- All category/sort fields are whitelisted (no SQL injection via user input)
- External product catalog is hardcoded server-side (no user-controlled URLs)
- Budget extraction uses regex on user answers — no eval, no code execution
- Answer storage uses parameterised DB inserts

---

## Testing

- **Unit**: `apps/web/test/unit/smart-intent-*.test.ts` — intent classification, budget extraction, question generation
- **Integration**: `apps/web/test/unit/question-validation.test.ts` — end-to-end flow
- **E2E**: `apps/web/e2e/round29-features-validation.spec.ts` — external products, toggle, chat flow
