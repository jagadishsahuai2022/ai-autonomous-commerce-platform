﻿# DelegateCart — Functional Documentation

> **Round 57 — April 15, 2026** | Supersedes prior versions in `docs/10Apr2026/`

---

## 1. Product Overview

DelegateCart is an AI-powered e-commerce shopping assistant platform that combines:
- **Smart Intent Engine**: Parses natural-language shopping queries into structured product-search parameters
- **Autonomous Checkout (Autopilot)**: Completes purchases end-to-end without user intervention
- **Agentic AI Integration**: NestJS-backed LLM pipeline for intent parsing, question generation, product ranking
- **Self-Learning Dashboard**: Admin/supervisor interface for reviewing, correcting, and enriching AI responses
- **Real-time WebSocket notifications**: Live purchase and recommendation updates

---

## 2. User Roles

| Role | Capabilities |
|------|-------------|
| **Guest** | Browse products, view recommendations |
| **Shopper** | Full shopping assistant, autonomous checkout, shopping lists |
| **Admin** | All shopper + access to learning dashboard, LLM enrichment, system metrics |
| **Learning Supervisor** | Access to learning dashboard only (via `supervisedlearning@delegatecart.com`) |
| **Observability** | Read access to metrics and logs (via `observability@delegatecart.com`) |

---

## 3. Feature Inventory

### 3.1 Shopping Assistant (`/shopping-assistant`)
- **Natural language query input**: User types query, Smart Intent Engine returns clarifying questions
- **Shortcut chip queries (Round 30)**: Pre-built prompts (e.g., "Best laptop under ₹50,000") click to immediately trigger full chat flow — same as manually typing and submitting
- **Collapsible chat session panels (Round 30)**: Each user query starts a new session panel. Older sessions auto-collapse when a new query is sent. User can manually toggle any session.
- **Product ranking sidebar**: Live-updated ranked product list with AI score, price, rating, delivery time
- **Dynamic metrics bar (Round 30)**: "Products", "Avg score", "Time saved" — computed from live session data; each is a clickable link to a detailed analytics page
- **AI scoring details**: `/shopping-assistant/metrics/products` — full product grid with brand distribution, score breakdown
- **Score analytics**: `/shopping-assistant/metrics/score` — 5-dimension scoring methodology, distribution chart
- **Time-saved analytics**: `/shopping-assistant/metrics/time-saved` — traditional vs AI comparison, pipeline timing

### 3.2 Self-Learning Dashboard (`/admin/learning`)
- **Paginated, sortable grid**: Server-side paging, column header sort, page size control
- **Per-column filters (Round 30)**: Filter popups on "Query By" and "Query Text" columns — filters sent to DB; 350ms debounce
- **Toolbar filters**: Active/Inactive toggle, AI-enriched/unenriched toggle
- **AI Enrichment**: Select records → choose LLM model → enrich in batch with progress tracking
- **Inline JSON editor**: Edit `supervisedResponse` and `aiEnrichedResponse` inline
- **Audit trail**: Comments column shows per-record action history
- **Duplicate deactivation**: Exact-match duplicate detection with safe deactivation

### 3.3 Autonomous Checkout (Autopilot)
- **Auto-select delivery**: Best delivery window selected automatically
- **Auto-apply coupon**: System finds and applies best available coupon
- **Auto-fill address**: Uses default/preferred shipping address
- **Auto-pay**: Executes payment via preferred wallet/payment method
- **Real-time progress**: WebSocket events push checkout step status to UI
- **Manual override**: User can pause/take-over at any step

### 3.4 Shopping Lists
- Create named lists with target prices
- AI populates lists with ranked product suggestions
- Share lists with other users
- Notifications when price drops below target

### 3.5 Notifications
- **In-app**: Bell icon, notification center drawer
- **Push**: Browser push notifications for price alerts, order updates
- **WebSocket real-time**: Instant delivery for checkout events, recommendations

### 3.6 Wallet & Payments
- Internal wallet with balance
- Add funds via payment gateway
- Auto-pay from wallet during autonomous checkout
- Transaction history with idempotency protection

---

## 4. Page Map

| Route | Component | Auth Required |
|-------|-----------|---------------|
| `/` | Home/Landing | No |
| `/shopping-assistant` | ShoppingAssistant + ShoppingChat | Optional |
| `/shopping-assistant/metrics/products` | Products metrics page | No |
| `/shopping-assistant/metrics/score` | Score analytics page | No |
| `/shopping-assistant/metrics/time-saved` | Time saved analytics | No |
| `/admin/learning` | LearningDashboard | Admin/Supervisor |
| `/admin/products` | ProductManagement | Admin |
| `/admin/users` | UserManagement | Admin |
| `/checkout` | CheckoutFlow | Yes |
| `/checkout/autopilot` | AutopilotCheckout | Yes |
| `/orders` | OrderHistory | Yes |
| `/wallet` | WalletManagement | Yes |
| `/notifications` | NotificationCenter | Yes |
| `/profile` | UserProfile | Yes |

---

## 5. Data Flows

### 5.1 Chat Query Flow (Round 30)
```
User types / clicks chip
    → setPendingQuery(text)        [shopping-assistant/page.tsx]
    → ShoppingChat receives pendingQuery prop
    → pendingQuery useEffect fires → handleSendMessage(text)
    → POST /api/ai/intent          [NestJS or Next.js route]
    → Smart Intent Engine parses intent
    → Returns clarifying questions
    → Questions rendered as ChoiceMessage components
    → User selects options
    → Final product ranking returned
    → Products stored in liveProducts state
    → Metrics bar updated (productsCount, avgScore, timeSaved)
    → New session panel created, older sessions auto-collapsed
```

### 5.2 Learning Dashboard Filter Flow (Round 30)
```
Admin sets per-column filter (queryBy/queryText text input)
    → setColFilter(field, value) + setPage(0)
    → debounced fetchRecords() fires after 350ms
    → GET /api/admin/learning?filterQueryBy=X&filterQueryText=Y&page=N&limit=L&sort=...
    → getSmartIntentRecords() builds WHERE clause with ILIKE
    → Count + records returned
    → Grid re-renders with server-filtered data
```

---

## 6. Non-Functional Requirements

| Aspect | Requirement | Status |
|--------|-------------|--------|
| Performance | Learning dashboard loads < 2s for 10K records | Met (server-side paging) |
| Security | Admin routes require session + email whitelist | Met |
| Scalability | DB-side ALL filtering/sorting/paging | Met (Round 30) |
| UX | Chat sessions don't overflow — auto-collapse | Met (Round 30) |
| Observability | All AI enrichment errors captured per-record | Met |
| Idempotency | Checkout/payment operations idempotent | Met (see IDEMPOTENCY.md) |
| Data Integrity | Product detail matches listing (same source) | Met (R57 — synthetic fallback disabled) |
| Image Fidelity | All 100K products have resolvable image URLs | Met (R57 — loremflickr CDN migration) |
| Scroll | Full catalog browsable via infinite scroll | Met (R57 — maxPages cap removed) |

---

## 7. R57 Product System Changes

### 7.1 Product Detail Consistency Fix
- **Problem**: Clicking a product on listing showed a completely different product on the detail page
- **Root cause**: Backend `GET /products/:id` returned 500 (TypeError), web fell back to synthetic mock data
- **Fix**: API uses `prisma.product.findUnique()` directly instead of custom wrapper method
- **Guard**: Synthetic product fallback disabled by default in web API routes

### 7.2 Image URL Normalization
- **Before**: 100K products had relative `imageUrl` paths (`/images/products/smartphones/1.webp`) — files did not exist
- **After**: Absolute URLs via `https://loremflickr.com/640/640/{category}?lock={id}` — 20 category-specific keywords
- **Migration**: `scripts/r57-db-imageurl-normalization.sql` — `UPDATE 100000` rows

### 7.3 Product Catalog Scale
- **100,000 products** across 20 categories (5,000 each)
- Infinite scroll with no page cap — full catalog browsable
- Count widget shows real-time "loaded / total" badge (e.g., "80 / 100,000")
