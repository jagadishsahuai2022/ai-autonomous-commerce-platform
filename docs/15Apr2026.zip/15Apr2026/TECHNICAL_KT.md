﻿# DelegateCart — Technical KT Document

> **Round 57 — April 15, 2026**

---

## 1. Repository Layout

```
delegatecart/
├── apps/
│   ├── web/                   Next.js 14 App Router (Port 3000)
│   │   ├── app/               App Router pages and layouts
│   │   │   ├── admin/         Admin-only pages (learning dashboard, etc.)
│   │   │   ├── api/           Next.js API routes
│   │   │   └── shopping-assistant/  Shopper-facing pages + metrics sub-pages
│   │   ├── components/        Shared React components
│   │   │   ├── ShoppingChat.tsx     Main chat interface (collapsible sessions)
│   │   │   └── ...
│   │   ├── hooks/             Custom React hooks
│   │   │   └── useShoppingAssistant.ts   Primary state management hook
│   │   ├── lib/
│   │   │   └── db.ts          Direct PostgreSQL access via 'pg' library
│   │   └── public/
│   ├── api/                   NestJS backend (Port 3001)
│   │   ├── src/modules/       Feature modules (auth, products, orders, ...)
│   │   └── prisma/            Prisma schema + migrations
│   ├── ai-service/            Python FastAPI (Port 8000)
│   ├── intent-parser/         Node.js (Port 8001)
│   ├── product-aggregator/    Node.js (Port 8002)
│   ├── product-ranking-engine/ Node.js (Port 8003)
│   └── autopilot-engine/      Node.js (Port 8004)
├── packages/
│   ├── config/                Shared ESLint, TypeScript configs
│   ├── types/                 Shared TypeScript interfaces
│   └── ui/                    Shared UI component library
├── infra/
│   ├── docker/                Dockerfiles
│   ├── kafka/                 Kafka config
│   ├── kubernetes/            K8s manifests
│   └── postgres/              DB init scripts
├── docs/
│   ├── 9Apr2026/              Previous round KT docs
│   └── 10Apr2026/             Current round KT docs (this folder)
└── docker-compose.yml         Full stack local dev
```

---

## 2. Key Dependencies

### apps/web
| Package | Version | Purpose |
|---------|---------|---------|
| next | 14.2.35 | Framework |
| react | 18.x | UI library |
| tailwindcss | 3.x | Styling |
| framer-motion | 11.x | Animations (chat sessions, metrics) |
| lucide-react | 0.x | Icon library |
| zustand | 4.x | Global state (auth, cart) |
| @tanstack/react-query | 5.x | Server state / caching |
| pg | 8.x | Direct PostgreSQL (lib/db.ts) |
| next-auth | 4.x | Authentication |
| radix-ui/* | Latest | Accessible UI primitives |

### apps/api
| Package | Version | Purpose |
|---------|---------|---------|
| @nestjs/core | 10.x | NestJS framework |
| @nestjs/websockets | 10.x | WebSocket support |
| @nestjs/throttler | 5.x | Rate limiting |
| prisma | 5.x | ORM |
| ioredis | 5.x | Redis client |
| kafkajs | 2.x | Kafka client |
| bcrypt | 5.x | Password hashing |
| passport-jwt | 4.x | JWT auth strategy |

---

## 3. Environment Variables

### apps/web (.env.local)
```env
DATABASE_URL=postgresql://admin:password@localhost:5432/ai_commerce
NEXTAUTH_SECRET=delegatecart-secret-key-change-in-production
NEXTAUTH_URL=http://localhost:3000
NEXT_PUBLIC_API_URL=http://localhost:3001
NEXT_PUBLIC_WS_URL=ws://localhost:3001
```

### apps/api (.env)
```env
DATABASE_URL=postgresql://admin:password@localhost:5432/ai_commerce
REDIS_URL=redis://localhost:6379
KAFKA_BROKERS=localhost:9092
JWT_SECRET=delegatecart-jwt-secret
AI_SERVICE_URL=http://localhost:8000
INTENT_PARSER_URL=http://localhost:8001
```

---

## 4. Local Development

```powershell
# Start all infrastructure
docker-compose up -d postgres redis kafka zookeeper

# Install dependencies (from repo root)
pnpm install

# Run web app
cd apps/web ; pnpm dev      # starts Next.js on :3000

# Run API
cd apps/api ; pnpm start:dev  # starts NestJS on :3001

# Run all via Turborepo
turbo dev
```

---

## 5. Database Access Pattern

### Direct PostgreSQL (`lib/db.ts`)
Used for: admin learning dashboard, complex analytics queries, batch operations

```typescript
import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Always parameterized — no string interpolation
const result = await pool.query(
  'SELECT * FROM "SmartIntentEngineResponse" WHERE "queryBy" ILIKE $1 LIMIT $2 OFFSET $3',
  [`%${search}%`, limit, offset]
);
```

### Prisma ORM (`apps/api/prisma`)
Used for: standard CRUD, auth, orders, products

```typescript
const user = await prisma.user.findUnique({ where: { email } });
const order = await prisma.order.create({ data: { ... } });
```

---

## 6. Authentication Flow

```
POST /api/auth/signin (NextAuth)
  → Credentials provider validates email + bcrypt.compare(password, hash)
  → Creates JWT session with { userId, email, role }
  → Sets HttpOnly secure cookie

Subsequent requests:
  → NextAuth middleware extracts session from cookie
  → getServerSession() in API routes / Server Components
  → For admin routes: check session.user.email in LEARNING_EMAILS whitelist
```

Default admin: `admin@delegatecart.com` / `Admin@DC2024!`  
Other supervisors: `supervisedlearning@delegatecart.com`, `observability@delegatecart.com`

---

## 7. Round 30 Implementation Summary

### Files Modified

| File | Change |
|------|--------|
| `apps/web/lib/db.ts` | Refactored `getSmartIntentRecords`: unified rawConditions pattern, added filterQueryBy + filterQueryText params |
| `apps/web/app/api/admin/learning/route.ts` | Extract + pass filterQueryBy, filterQueryText to DB function |
| `apps/web/app/admin/learning/page.tsx` | Per-column filter UI + debounced fetch + filteredRecords = records (server-side) |
| `apps/web/components/ShoppingChat.tsx` | pendingQuery prop, chatSessions useMemo, collapsible session panels, auto-collapse effect |
| `apps/web/app/shopping-assistant/page.tsx` | pendingQuery state, chip onClick, computed metrics, Link tiles |

### Files Created

| File | Purpose |
|------|---------|
| `apps/web/app/shopping-assistant/metrics/products/page.tsx` | Full product analytics page |
| `apps/web/app/shopping-assistant/metrics/score/page.tsx` | AI score methodology page |
| `apps/web/app/shopping-assistant/metrics/time-saved/page.tsx` | Time savings comparison page |
| `docs/10Apr2026/*.md` | KT documentation for this round |

---

## 8. Testing

```powershell
# Unit tests (Vitest)
$env:NODE_OPTIONS = ""; cd apps/web ; pnpm vitest

# E2E tests (Playwright)
$env:NODE_OPTIONS = ""
node "...\@playwright+test@1.58.2\...\cli.js" test e2e/ --reporter=line

# TypeScript check
cd apps/web ; npx tsc --noEmit
```

E2E specs for Round 30 features: `apps/web/e2e/round30-features-validation.spec.ts`
