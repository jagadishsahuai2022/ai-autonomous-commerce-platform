# DelegateCart — High Level Design (HLD)

> **Round 30 — April 10, 2026**

---

## 1. System Context

```
┌─────────────────────────────────────────────────────────────────┐
│                         INTERNET                                 │
│                                                                   │
│   ┌──────────────┐   HTTPS    ┌──────────────────────────────┐  │
│   │   Shopper    │──────────▶ │   Next.js Web App            │  │
│   │   Browser    │            │   apps/web  :3000            │  │
│   └──────────────┘            └───────────┬──────────────────┘  │
│                                           │                       │
│   ┌──────────────┐   HTTPS + WS           │ REST / WS            │
│   │   Admin      │◀─────────────────────┐ │                       │
│   │   Browser    │                      │ ▼                       │
│   └──────────────┘            ┌─────────┴────────────────────┐  │
│                                │   NestJS API                 │  │
│                                │   apps/api  :3001            │  │
│                                └────────┬─────────────────────┘  │
└────────────────────────────────────────┼────────────────────────┘
                                          │
               ┌──────────────────────────┼────────────────┐
               │                          │                │
               ▼                          ▼                ▼
     ┌──────────────────┐    ┌────────────────────┐  ┌──────────┐
     │   PostgreSQL      │    │   Redis Cache      │  │  Kafka   │
     │   :5432           │    │   :6379            │  │  :9092   │
     └──────────────────┘    └────────────────────┘  └──────────┘
               │
    ┌──────────┴────────────┐
    │  Microservices        │
    │  ai-service  :8000    │
    │  intent-parser :8001  │
    │  product-ranking :8002│
    │  product-aggregator   │
    │  autopilot-engine     │
    └───────────────────────┘
```

---

## 2. Logical Tiers

### Tier 1: Presentation (Next.js)
- **Server Components**: Product listing, static pages, SEO-friendly renders
- **Client Components**: ShoppingChat, ShoppingAssistant, LearningDashboard, metrics pages
- **API Routes**: `/api/admin/learning`, `/api/auth`, `/api/checkout`, `/api/notifications`
- **Key libraries**: Tailwind CSS, Radix UI, framer-motion, Zustand, TanStack Query

### Tier 2: Application (NestJS)
- **Modules**: Auth, Products, Checkout, Orders, Wallet, Notifications, AI, Autopilot, Learning
- **Guards**: JWT auth guard, Role guard, Admin guard
- **Interceptors**: Logging, timing, error normalization
- **WebSocket Gateway**: Real-time checkout events, notifications

### Tier 3: Data
- **PostgreSQL**: Primary store — users, orders, products, AI records, wallet
- **Redis**: Session tokens, cache, idempotency keys, pub/sub
- **Kafka**: Async events — order placed, payment processed, notification dispatch

### Tier 4: AI Microservices
- **ai-service** (Python/FastAPI): LLM integration (OpenAI / Anthropic)
- **intent-parser** (Node): Query → structured intent JSON
- **product-ranking-engine** (Node): Weighted scoring algorithm
- **product-aggregator** (Node): Fetches from multiple vendor APIs

---

## 3. Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Frontend framework | Next.js 14 App Router | Server Components + API routes in one app |
| Backend framework | NestJS | DI, modules, WebSocket support, TypeScript-first |
| DB ORM | Prisma + raw SQL | Prisma for standard CRUD; raw SQL for complex analytics queries |
| Caching | Redis | Session, idempotency, pub/sub |
| Async messaging | Kafka | Durable, replay-capable event log |
| State (frontend) | Zustand + useState | Zustand for global auth/cart; local useState for page-specific state |
| AI orchestration | LangChain-style pipeline | Intent parse → question gen → search → product rank → answer |
| Filtering strategy (Round 30) | DB-side (PostgreSQL ILIKE) | Replace buggy client-side ILIKE in JS |

---

## 4. Security Architecture

```
Browser
  ↓ HTTPS (TLS 1.3)
Next.js Edge / Middleware
  ↓ NextAuth session check
API Routes / NestJS Controllers
  ↓ JWT validation + Role check + email whitelist (admin routes)
Service Layer
  ↓ Parameterized SQL (no string interpolation)
PostgreSQL
  ↓ Row-level: user_id scoping | Admin: isActive filter
```

- **SQL injection prevention**: All user inputs go through parameterized queries (`$1`, `$2`, …)
- **XSS prevention**: React renders strings as text by default; no `dangerouslySetInnerHTML` on user content
- **CSRF**: Next.js SameSite cookie + CSRF token on state-changing API calls
- **Rate limiting**: NestJS `@nestjs/throttler` on all public endpoints
- **Admin route protection**: Email whitelist (`LEARNING_EMAILS`) checked before any DB operation

---

## 5. Scalability Approach

| Layer | Mechanism |
|-------|-----------|
| Web tier | Horizontal (Docker replicas, load balancer) |
| API tier | Horizontal (NestJS stateless, Redis for shared state) |
| DB tier | Read replicas via PgBouncer; connection pooling |
| AI tier | Python workers scale per queue depth |
| Cache | Redis Cluster (not yet implemented — roadmap) |

---

## 6. Observability

- **Structured logging**: Winston (NestJS), console.log with JSON format (Next.js API routes)
- **Performance metrics**: Request duration in response headers (`X-Request-Duration-Ms`)
- **Frontend timing**: `window.performance` timeline in shopping assistant
- **Admin visibility**: Learning dashboard shows `updatedAt`, `createdAt`, enrichment status per record
- **Error tracking**: Per-record error capture in AI enrichment batch; stored in `comments` JSONB

---

## 7. Round 30 Changes to Architecture

| Area | Before | After |
|------|--------|-------|
| Learning grid filtering | Client-side JS ILIKE | DB-side PostgreSQL ILIKE with debounce |
| Chat UX | Flat messages list | Session-grouped collapsible panels |
| Chip queries | Hardcoded labels, no action | Click → pendingQuery → full chat flow |
| Metrics bar | Hardcoded static text | Computed from liveProducts / liveTimeline |
| Metrics pages | Did not exist | 3 dedicated analytics pages created |
