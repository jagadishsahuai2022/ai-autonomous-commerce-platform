# DelegateCart — System Architecture (Round 30 — April 10, 2026)

## Overview

DelegateCart is an AI-powered e-commerce platform that combines a Next.js storefront, NestJS API, autonomous checkout engine, smart intent parser, product aggregator, product ranking engine, and an AI microservice into a unified monorepo (pnpm workspaces / Turborepo).

---

## Top-Level Component Map

```
┌─────────────────────────────────────────────────────────────┐
│                    USER BROWSER / CLIENT                    │
│         Next.js 14 (apps/web) — SSR + Client Components    │
└────────────────────────────┬────────────────────────────────┘
                             │ HTTPS / WebSocket
              ┌──────────────▼─────────────────┐
              │     NestJS REST API (apps/api)  │
              │   JWT Auth · Prisma ORM · RBAC  │
              └──┬──────────┬──────────┬────────┘
                 │          │          │
       ┌─────────▼──┐  ┌────▼────┐ ┌──▼──────────────┐
       │  PostgreSQL │  │  Redis  │ │   Apache Kafka   │
       │  (primary)  │  │  Cache  │ │ (event streaming)│
       └─────────────┘  └─────────┘ └──────────────────┘
                 │
  ┌──────────────┼──────────────────────────────────────┐
  │              │  MICROSERVICES                       │
  │  ┌───────────▼──────────────────────────────────┐  │
  │  │  apps/ai-service  (Python FastAPI)            │  │
  │  │  LLM proxy · OpenRouter · Gemini · Claude     │  │
  │  └──────────────────────────────────────────────┘  │
  │  ┌──────────────────────────────────────────────┐  │
  │  │  apps/autopilot-engine  (Node.js / NestJS)   │  │
  │  │  Autonomous checkout · Approval workflow      │  │
  │  └──────────────────────────────────────────────┘  │
  │  ┌──────────────────────────────────────────────┐  │
  │  │  apps/intent-parser  (Node.js)               │  │
  │  │  Smart intent extraction · NLP rules         │  │
  │  └──────────────────────────────────────────────┘  │
  │  ┌──────────────────────────────────────────────┐  │
  │  │  apps/product-aggregator  (Node.js)          │  │
  │  │  Multi-source product fetch · Normalisation  │  │
  │  └──────────────────────────────────────────────┘  │
  │  ┌──────────────────────────────────────────────┐  │
  │  │  apps/product-ranking-engine  (Node.js)      │  │
  │  │  5-dimension AI ranking · Scoring pipeline   │  │
  │  └──────────────────────────────────────────────┘  │
  └─────────────────────────────────────────────────────┘
```

---

## Key Technology Choices

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| Frontend | Next.js 14, React 18, Tailwind CSS, Framer Motion | SSR/CSR hybrid, edge-ready, animation-first UX |
| API | NestJS 10, Prisma 5, REST + WebSocket | DI framework, type-safe DB layer, real-time events |
| Auth | NextAuth.js + JWT | Session + token duality; admin RBAC via email allowlist |
| Database | PostgreSQL 15 | ACID compliance; JSONB for flexible intent/enrichment data |
| Cache | Redis 7 | Session store, rate-limiting, hot products |
| Messaging | Apache Kafka | Event sourcing for checkout, notifications, audit trail |
| AI/LLM | Python FastAPI + OpenRouter / Gemini / Claude | Pluggable LLM provider with fallback chain |
| Search | In-DB ILIKE + vector distance (planned) | Server-side `getSmartIntentRecords` with per-column filters |
| Container | Docker Compose (dev/test) | Single-command local deployment |
| Monorepo | pnpm workspaces + Turborepo | Shared packages (`config`, `types`, `ui`); incremental builds |

---

## Data Flow: Smart Shopping Query

```
1. User types query (or clicks shortcut chip)
   └─▶ ShoppingChat.tsx pendingQuery → handleSendMessage()
       └─▶ POST /api/chat/message
           └─▶ Next.js API Route → intent-parser microservice
               └─▶ SmartIntentEngine (lib/smart-intent/)
                   ├─▶ NLP rule engine → IntentData
                   ├─▶ Clarifying question generation
                   └─▶ answerQuestion() loop
                       └─▶ product-aggregator → catalog products
                           └─▶ product-ranking-engine (5-dim scoring)
                               └─▶ RankedProduct[] → addMessage() (product_recommendation)
                                   └─▶ ProductRecommendationCarousel
                                       └─▶ [External fallback if no matches + toggle ON]
                                           └─▶ POST /api/intent/external-products
```

---

## Self-Learning / Supervised Learning Loop

```
Query arrives ──▶ SmartIntentEngine.process()
                 ├─▶ Write SmartIntentEngineResponse (DB)
                 │     { queryText, intentEngineResponse, isActive: true }
                 └─▶ Admin reviews at /admin/learning
                     ├─▶ Filter: DB-side ILIKE (filterQueryBy, filterQueryText, filterActive, filterAI)
                     ├─▶ Supervisor edits → PATCH supervisedResponse
                     ├─▶ AI enrichment batch → POST /api/admin/learning { action: enrich-batch }
                     │     └─▶ LLM enrichment (Gemini/Claude/OpenRouter)
                     │         └─▶ updateAIEnrichedResponse()
                     └─▶ Active records feed back into ranking as boosted signals
```

---

## Infrastructure Diagram (Docker Compose)

```
docker network: delegatecart_ai-commerce-network
  ├── ai-commerce-postgres   (postgres:15-alpine)  port 5432
  ├── ai-commerce-redis      (redis:7-alpine)       port 6379
  ├── ai-commerce-kafka      (confluentinc/cp-kafka) port 9092
  ├── ai-commerce-zookeeper  (zookeeper)            port 2181
  ├── ai-commerce-web        (delegatecart-web:new) port 3000  ◄── Next.js
  └── ai-commerce-api        (delegatecart-api)     port 3001  ◄── NestJS
```

---

## Security Architecture

- **Auth**: NextAuth `CredentialsProvider` with bcrypt password hashing; JWT `NEXTAUTH_SECRET`
- **Admin RBAC**: Email allowlist check (`LEARNING_EMAILS`, `ADMIN_EMAILS`) in every API route
- **SQL Injection**: Whitelisted sort fields + parameterised queries (`$1`, `$2`, …) — no string concatenation
- **XSS**: React escaping; CSP headers in `next.config.js`
- **OWASP Top 10**: All validated at API boundaries; no user input directly in SQL; Prisma ORM for non-raw queries

---

## New Features Added (Round 29 → Round 30)

| Feature | Files Modified |
|---------|---------------|
| DB-side per-column filtering | `lib/db.ts`, `app/api/admin/learning/route.ts`, `app/admin/learning/page.tsx` |
| Shortcut chip → chat query | `app/shopping-assistant/page.tsx`, `components/ShoppingChat.tsx` |
| Collapsible chat sessions | `components/ShoppingChat.tsx` |
| Clickable metrics + detail pages | `app/shopping-assistant/page.tsx`, `app/shopping-assistant/metrics/*/page.tsx` |
| External products catalog | `app/api/intent/external-products/route.ts` |
| External badge in carousel | `components/ProductRecommendationCarousel.tsx` |
