# DelegateCart — Observability & Monitoring

> **Round 30 — April 10, 2026**

---

## 1. Observability Stack

| Layer | Tool | Location |
|-------|------|---------|
| Container logs | Docker logging driver | `docker logs <service> -f` |
| Structured logs | Winston (NestJS), console.json (Next.js) | Stdout → Docker |
| Request tracing | Custom `X-Request-ID` header | Propagated across Next.js → NestJS |
| Performance timing | `X-Request-Duration-Ms` header | Set in NestJS interceptor |
| Frontend performance | `window.performance` timeline | Shopping Assistant page |
| AI pipeline timing | `TimelineStep[]` in response | Returned by intent API, shown in metrics |
| DB slow queries | pg `log_min_duration_statement` | PostgreSQL logs |

---

## 2. AI Pipeline Observability (Round 30)

The shopping assistant timeline is visible to users via the time-saved metrics page:

```typescript
// TimelineStep structure returned by AI endpoint
interface TimelineStep {
  label: string;    // e.g., "Intent Analysis", "Question Generation", "Product Search", "Ranking"
  duration: number; // milliseconds
}

// Stored in localStorage and available at /shopping-assistant/metrics/time-saved
```

The time-saved page shows:
- Each pipeline step with actual duration bar
- Comparison vs. "Traditional shopping" (research-backed 78 minutes)
- Percentage time saved
- Annualized impact projection

---

## 3. Learning Dashboard Observability

Admins can observe AI system quality through the Learning Dashboard:
- **Total records**: Total queries processed by the Smart Intent Engine
- **Enriched count**: How many have been AI-enriched
- **Active/inactive ratio**: Health of learning data pipeline
- **Per-record audit trail**: Comments column shows every action taken

---

## 4. Critical Metrics to Watch

| Metric | How to check | Threshold |
|--------|-------------|-----------|
| Next.js CPU | `docker stats ai-commerce-web` | < 80% |
| NestJS memory | `docker stats ai-commerce-api` | < 512MB |
| DB connections | `SELECT count(*) FROM pg_stat_activity` | < 100 |
| Redis memory | `redis-cli INFO memory` | < 256MB |
| Kafka consumer lag | Check consumer group lag | < 1000 messages |
| AI enrichment errors | Learning dashboard per-record errors | 0 expected |
| Autopilot success rate | Orders with status=PAID / total autopilot orders | > 95% |

---

## 5. Log Queries

```bash
# View real-time Next.js logs
docker logs ai-commerce-web -f --tail 50

# View NestJS API logs
docker logs ai-commerce-api -f --tail 50

# Filter for errors only
docker logs ai-commerce-web 2>&1 | grep -i error | tail -20

# Check slow DB queries
docker logs ai-commerce-postgres 2>&1 | grep "duration:" | tail -20

# All container statuses
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
```

---

## 6. Health Checks

```bash
# Web app health
curl http://localhost:3000/api/health

# NestJS health
curl http://localhost:3001/health

# DB connectivity
docker exec ai-commerce-postgres psql -U admin -d ai_commerce -c "SELECT NOW();"

# Redis ping
docker exec ai-commerce-redis redis-cli PING
```

---

## 7. Alerting (Roadmap)

Currently planned but not yet implemented:
- Prometheus + Grafana for time-series metrics
- Alert when autopilot failure rate > 5%
- Alert when AI enrichment queue depth > 100
- Alert when DB connection pool exhausted
- PagerDuty integration for production incidents

---

## 8. Frontend Observability

```typescript
// Shopping assistant page tracks real-time state
const [liveProducts, setLiveProducts]   // from last AI response
const [liveTimeline, setLiveTimeline]   // pipeline timing steps

// Metrics persisted to localStorage for cross-page observability
localStorage.setItem('dc-metrics-products', JSON.stringify(liveProducts));
localStorage.setItem('dc-metrics-timeline', JSON.stringify(liveTimeline));
localStorage.setItem('dc-metrics-ts', new Date().toISOString());
```

Users can navigate to `/shopping-assistant/metrics/*` for detailed analytics of their last session.
