# Round 39 — Release Notes (10 April 2026)

## Summary

R39 enhances RBAC-based dashboard visibility across all privileged roles, introduces admin impersonation ("login as user"), adds cross-user data to Smart Delegate, and enriches the Metrics Validation page with per-search validation and improved product media.

---

## Changes

### 1. Account Page — RBAC Dashboard Cards

**Files changed:** `apps/web/app/account/page.tsx`

- Replaced hardcoded `adminOnly` email check with `visibleToRoles` per card.
- Dashboard card visibility matrix:
  | Card                  | Roles                                              |
  |-----------------------|-----------------------------------------------------|
  | Observability         | admin, analytics, observability                     |
  | Self-Learning         | admin, analytics, reinforced-learning               |
  | Metrics Validation    | admin, analytics, observability, reinforced-learning |
- Uses `getCurrentUserRole()` from `lib/admin-auth.ts` at render time.

### 2. User Dropdown Menu — Role-Based Links

**Files changed:** `apps/web/app/layout-client.tsx`

- Added Observability Dashboard, Self-Learning Dashboard, and Metrics Validation links to the user dropdown menu.
- Each link is gated by the same role matrix as the account page cards.
- Icons: `Activity` (Observability), `Brain` (Learning), `CheckCircle` (Validation).

### 3. Admin Impersonation

**Files changed:** `apps/web/app/layout-client.tsx`

- New **Impersonate User** expandable section in admin dropdown listing all non-admin demo users.
- `handleImpersonate(email)` saves admin session to localStorage, creates a target user session via `/api/auth/login` (passwordless), sets `dc-impersonating=true`, and redirects to `/dashboard`.
- **Resume Admin** button (amber styling) appears when impersonating. `handleResumeAdmin()` restores admin credentials, creates fresh admin session, cleans up impersonation flags, redirects to `/admin/dashboard`.
- localStorage keys: `dc-impersonating`, `dc-admin-original-email`, `dc-admin-original-token`, `dc-admin-original-role`, `dc-admin-original-subscription`.
- Logout clears all impersonation keys.

### 4. Smart Delegate — Cross-User Data & Per-Search Validation

**Files changed:** `apps/web/app/smart-delegate/page.tsx`

- Privileged roles (`admin`, `analytics`, `observability`, `reinforced-learning`) see cross-user search results with user badge.
- Demo data generated for other DEMO_USERS when own submissions are < 3.
- User filter dropdown for isolating results by user.
- **Per-search "Validate" chip** on each SubmissionCard: stores that submission's products into `dc-metrics-products` localStorage key and navigates to Metrics Validation filtered for that specific search.

### 5. Metrics Validation — Enhanced Product Media

**Files changed:** `apps/web/app/shopping-assistant/metrics/validation/page.tsx`

- Product media section upgraded from plain gray boxes to styled gradient thumbnails with:
  - `Package` icon + labeled views (Front View, Side View, Detail, Package)
  - Gradient backgrounds per image slot
  - Video review thumbnail with rose gradient styling and play button
  - Shadow effects and hover states
- Category detection from product name for contextual display.

---

## RBAC Role Matrix (Complete)

| Role                | Admin Dashboard | Observability | Learning | Metrics Validation | Smart Delegate Cross-User | Impersonation |
|---------------------|:--:|:--:|:--:|:--:|:--:|:--:|
| admin               | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ (initiator) |
| analytics           | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ |
| observability       | ❌ | ✅ | ❌ | ✅ | ✅ | ❌ |
| reinforced-learning | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ |
| aiplus              | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| basic               | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| customer            | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |

---

## Docker

- Image: `delegatecart-web:r39`
- Container: `dc-web-r39`
- Port: `3010`
- Network: `delegatecart_ai-commerce-network`
- Database: `postgresql://admin:password@ai-commerce-postgres:5432/ai_commerce?schema=public`

## Testing

- E2E: `round39-comprehensive.spec.ts` — covers impersonation, RBAC visibility, cross-user data, per-search validation
- Video proof: Screenshots captured for all 6 non-admin roles + admin impersonation flow
- R35 regression: Maintained compatibility with existing 45/47 baseline
