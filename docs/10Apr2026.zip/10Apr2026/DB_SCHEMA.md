# DelegateCart — Complete Database Schema

> **Round 30 — April 10, 2026**

---

## 1. Core Tables

### User
```sql
CREATE TABLE "User" (
  "id"              SERIAL PRIMARY KEY,
  "email"           TEXT NOT NULL UNIQUE,
  "name"            TEXT,
  "passwordHash"    TEXT NOT NULL,
  "role"            TEXT NOT NULL DEFAULT 'USER',    -- 'USER' | 'ADMIN'
  "walletBalance"   DECIMAL(12,2) NOT NULL DEFAULT 0,
  "profileAddress"  JSONB,                            -- default shipping address
  "preferences"     JSONB NOT NULL DEFAULT '{}',      -- AI/UX preferences
  "pushSubscription" JSONB,                           -- browser push endpoint
  "createdAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### Product
```sql
CREATE TABLE "Product" (
  "id"              SERIAL PRIMARY KEY,
  "name"            TEXT NOT NULL,
  "brand"           TEXT,
  "category"        TEXT NOT NULL,
  "price"           DECIMAL(10,2) NOT NULL,
  "originalPrice"   DECIMAL(10,2),
  "description"     TEXT,
  "features"        TEXT[],
  "imageUrl"        TEXT,
  "rating"          DECIMAL(3,2),
  "reviewCount"     INTEGER NOT NULL DEFAULT 0,
  "deliveryDays"    INTEGER,
  "isAvailable"     BOOLEAN NOT NULL DEFAULT TRUE,
  "isExternal"      BOOLEAN NOT NULL DEFAULT FALSE,
  "externalUrl"     TEXT,
  "vendorId"        INTEGER,
  "metadata"        JSONB NOT NULL DEFAULT '{}',
  "createdAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_product_category ON "Product"("category");
CREATE INDEX idx_product_price ON "Product"("price");
CREATE INDEX idx_product_available ON "Product"("isAvailable");
CREATE INDEX idx_product_search ON "Product" USING GIN(to_tsvector('english', "name" || ' ' || COALESCE("brand", '') || ' ' || COALESCE("description", '')));
```

### Order
```sql
CREATE TABLE "Order" (
  "id"                    SERIAL PRIMARY KEY,
  "userId"                INTEGER REFERENCES "User"("id"),
  "status"                TEXT NOT NULL DEFAULT 'PENDING', -- PENDING | CONFIRMED | SHIPPED | DELIVERED | CANCELLED | REFUNDED
  "paymentStatus"         TEXT NOT NULL DEFAULT 'UNPAID',  -- UNPAID | PAID | REFUNDED
  "total"                 DECIMAL(12,2) NOT NULL,
  "shippingAddress"       JSONB NOT NULL,
  "couponCode"            TEXT,
  "couponDiscount"        DECIMAL(10,2),
  "deliveryMethod"        TEXT,
  "isAutopilot"           BOOLEAN NOT NULL DEFAULT FALSE,
  "autopilotSteps"        JSONB,                           -- step-by-step log
  "paidAt"                TIMESTAMPTZ,
  "clientIdempotencyKey"  TEXT UNIQUE,
  "createdAt"             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "OrderItem" (
  "id"          SERIAL PRIMARY KEY,
  "orderId"     INTEGER REFERENCES "Order"("id") ON DELETE CASCADE,
  "productId"   INTEGER REFERENCES "Product"("id"),
  "name"        TEXT NOT NULL,
  "price"       DECIMAL(10,2) NOT NULL,
  "quantity"    INTEGER NOT NULL DEFAULT 1
);
```

### Cart
```sql
CREATE TABLE "Cart" (
  "id"        SERIAL PRIMARY KEY,
  "userId"    INTEGER REFERENCES "User"("id") ON DELETE CASCADE UNIQUE,
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "CartItem" (
  "id"        SERIAL PRIMARY KEY,
  "cartId"    INTEGER REFERENCES "Cart"("id") ON DELETE CASCADE,
  "productId" INTEGER REFERENCES "Product"("id"),
  "quantity"  INTEGER NOT NULL DEFAULT 1,
  "addedAt"   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

## 2. AI & Learning Tables

### SmartIntentEngineResponse (Self-Learning System)
```sql
CREATE TABLE "SmartIntentEngineResponse" (
  "id"                            SERIAL PRIMARY KEY,
  "userId"                        INTEGER REFERENCES "User"("id") ON DELETE SET NULL,
  "queryBy"                       TEXT NOT NULL,   -- email or session id
  "queryText"                     TEXT NOT NULL,   -- raw user query
  "initialProductSuggestionText"  TEXT,            -- first AI response paragraph
  "intentEngineResponse"          JSONB NOT NULL DEFAULT '{}',
  "supervisedResponse"            JSONB NOT NULL DEFAULT '{}',
  "aiEnrichedResponse"            JSONB,
  "enhancedByAI"                  BOOLEAN NOT NULL DEFAULT FALSE,
  "isActive"                      BOOLEAN NOT NULL DEFAULT TRUE,
  "comments"                      JSONB NOT NULL DEFAULT '[]',  -- audit trail
  "createdAt"                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"                     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Performance indices for round 30 server-side filtering
CREATE INDEX idx_sie_queryby  ON "SmartIntentEngineResponse" ("queryBy");
CREATE INDEX idx_sie_active   ON "SmartIntentEngineResponse" ("isActive");
CREATE INDEX idx_sie_enhanced ON "SmartIntentEngineResponse" ("enhancedByAI");
CREATE INDEX idx_sie_text     ON "SmartIntentEngineResponse" USING GIN (to_tsvector('english', "queryText"));
CREATE INDEX idx_sie_created  ON "SmartIntentEngineResponse" ("createdAt" DESC);
```

---

## 3. Financial Tables

### WalletTransaction
```sql
CREATE TABLE "WalletTransaction" (
  "id"               SERIAL PRIMARY KEY,
  "userId"           INTEGER REFERENCES "User"("id"),
  "amount"           DECIMAL(12,2) NOT NULL,      -- positive=credit, negative=debit
  "type"             TEXT NOT NULL,               -- 'credit' | 'debit' | 'refund'
  "orderId"          INTEGER REFERENCES "Order"("id"),
  "idempotencyKey"   TEXT UNIQUE NOT NULL,        -- prevents double-processing
  "status"           TEXT NOT NULL DEFAULT 'completed',
  "gateway"          TEXT,
  "gatewayTxnId"     TEXT,
  "createdAt"        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### Coupon
```sql
CREATE TABLE "Coupon" (
  "id"            SERIAL PRIMARY KEY,
  "code"          TEXT NOT NULL UNIQUE,
  "discountType"  TEXT NOT NULL,             -- 'percentage' | 'fixed'
  "discountValue" DECIMAL(10,2) NOT NULL,
  "minOrderValue" DECIMAL(10,2),
  "maxDiscount"   DECIMAL(10,2),
  "validFrom"     TIMESTAMPTZ,
  "validUntil"    TIMESTAMPTZ,
  "maxUses"       INTEGER,
  "usedCount"     INTEGER NOT NULL DEFAULT 0,
  "isActive"      BOOLEAN NOT NULL DEFAULT TRUE
);
```

---

## 4. Notification Tables

```sql
CREATE TABLE "Notification" (
  "id"        SERIAL PRIMARY KEY,
  "userId"    INTEGER REFERENCES "User"("id") ON DELETE CASCADE,
  "type"      TEXT NOT NULL,
  "title"     TEXT NOT NULL,
  "body"      TEXT NOT NULL,
  "data"      JSONB,
  "isRead"    BOOLEAN NOT NULL DEFAULT FALSE,
  "readAt"    TIMESTAMPTZ,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notif_unread ON "Notification"("userId", "isRead") WHERE "isRead" = FALSE;

CREATE TABLE "PushSubscription" (
  "id"        SERIAL PRIMARY KEY,
  "userId"    INTEGER REFERENCES "User"("id") ON DELETE CASCADE,
  "endpoint"  TEXT NOT NULL UNIQUE,
  "p256dh"    TEXT NOT NULL,
  "auth"      TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

## 5. Audit Tables

```sql
CREATE TABLE "OrderStatusHistory" (
  "id"        SERIAL PRIMARY KEY,
  "orderId"   INTEGER REFERENCES "Order"("id") ON DELETE CASCADE,
  "status"    TEXT NOT NULL,
  "changedBy" INTEGER REFERENCES "User"("id"),
  "reason"    TEXT,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

## 6. Shopping Lists

```sql
CREATE TABLE "ShoppingList" (
  "id"          SERIAL PRIMARY KEY,
  "userId"      INTEGER REFERENCES "User"("id") ON DELETE CASCADE,
  "name"        TEXT NOT NULL,
  "targetBudget" DECIMAL(10,2),
  "isShared"    BOOLEAN NOT NULL DEFAULT FALSE,
  "shareToken"  TEXT UNIQUE,
  "createdAt"   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "ShoppingListItem" (
  "id"            SERIAL PRIMARY KEY,
  "shoppingListId" INTEGER REFERENCES "ShoppingList"("id") ON DELETE CASCADE,
  "productId"     INTEGER REFERENCES "Product"("id"),
  "productName"   TEXT NOT NULL,
  "targetPrice"   DECIMAL(10,2),
  "addedAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

## 7. Key Relationships Diagram

```
User ─────── Cart ─────── CartItem ─── Product
  │          (1:1)         (many)
  │
  ├──── Order ──── OrderItem ─── Product
  │     (many)     (many)
  │
  ├──── WalletTransaction (many)
  │
  ├──── Notification (many)
  │
  ├──── ShoppingList (many) ── ShoppingListItem (many) ── Product
  │
  └──── SmartIntentEngineResponse (many, via queryBy)
```
