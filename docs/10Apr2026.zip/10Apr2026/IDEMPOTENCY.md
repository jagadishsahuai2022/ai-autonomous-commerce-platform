# DelegateCart — Idempotency System

> **Round 30 — April 10, 2026**

---

## 1. What is Idempotency?

An operation is **idempotent** if executing it multiple times produces the same result as executing it once. Critical in distributed systems where:
- Network retries may send the same request twice
- Webhooks may deliver events more than once
- Users may double-click "Pay" buttons

---

## 2. Idempotency Points in DelegateCart

| Operation | Risk | Idempotency Mechanism |
|-----------|------|----------------------|
| Wallet debit | Double charge on retry | Redis key + DB unique constraint |
| Order creation | Duplicate orders | Client-generated idempotency key |
| Payment webhook (Stripe) | Duplicate fund credit | `paymentIntentId` as idempotency key |
| AI enrichment | Wasted tokens, duplicate audits | Per-record `enhancedByAI` flag check |
| Notification send | User receives duplicate alerts | Redis dedup key with 5-min TTL |

---

## 3. Redis-Based Idempotency

### Pattern
```typescript
// Before executing operation:
const key = `idempotency:${operationType}:${uniqueId}`;
const cached = await redis.get(key);
if (cached) return JSON.parse(cached); // Return cached result, skip re-execution

// Execute operation
const result = await performOperation();

// Store result (TTL = 24 hours for financial ops)
await redis.set(key, JSON.stringify(result), 'EX', 86400);
return result;
```

### Key Naming Conventions
```
idempotency:debit:{userId}:{orderId}         — wallet debit
idempotency:credit:{userId}:{paymentIntentId} — wallet credit from gateway
idempotency:notif:{userId}:{type}:{refId}    — notification dedup (5 min TTL)
idempotency:order:{userId}:{clientKey}       — order creation
```

---

## 4. Database-Level Idempotency

### WalletTransaction unique constraint
```sql
ALTER TABLE "WalletTransaction" ADD CONSTRAINT uniq_idempotency_key UNIQUE ("idempotencyKey");
```

### Order idempotency key
```sql
ALTER TABLE "Order" ADD COLUMN "clientIdempotencyKey" TEXT UNIQUE;
```

Race condition handling:
```typescript
try {
  await prisma.order.create({ data: { ..., clientIdempotencyKey: key } });
} catch (err) {
  if (err.code === 'P2002') { // Unique constraint violation
    // Order already exists — return existing order
    return await prisma.order.findFirst({ where: { clientIdempotencyKey: key } });
  }
  throw err;
}
```

---

## 5. Checkout Idempotency Flow

```
Client generates idempotency key:
  key = `${userId}-${cartHash}-${timestamp-minute-truncated}`
  (Truncated to minute so retries within 1 min reuse same key; new attempts after 1 min get new key)

POST /api/checkout/create { items, address, paymentMethod, idempotencyKey: key }
  → Check Redis: GET idempotency:order:key
  → If found: return { orderId: cachedOrderId, status: 'already_created' }
  → If not found:
    → DB transaction: create Order + WalletTransaction + OrderStatusHistory
    → Redis: SET idempotency:order:key {orderId} EX 3600
    → Return { orderId, status: 'created' }
```

---

## 6. AI Enrichment Idempotency

The learning dashboard's enrichment batch has built-in idempotency:
```typescript
// Pre-flight filter: only enrich records where enhancedByAI = false
const eligibleIds = selectedIds.filter(id => {
  const record = allRecords.find(r => r.id === id);
  return record?.isActive && !record?.enhancedByAI;
  // AND createdAt within last 30 days (recency filter)
});

// Even if admin accidentally clicks enrich twice:
// Second run: eligibleIds = [] (all already have enhancedByAI=true)
// → Toast: "0 records to enrich"
```

---

## 7. Frontend Request Deduplication

```typescript
// Prevent double-submit on payment forms
const [isSubmitting, setIsSubmitting] = useState(false);

async function handlePay() {
  if (isSubmitting) return; // Guard against double-click
  setIsSubmitting(true);
  try {
    await processPayment();
  } finally {
    setIsSubmitting(false);
  }
}
```

---

## 8. Observability

- All idempotency cache hits logged: `console.log('[idempotency] Cache hit for key:', key)`
- This allows monitoring of retry rates (high cache hit rate → system under stress)
- Redis `OBJECT encoding` can be used to track key sizes
