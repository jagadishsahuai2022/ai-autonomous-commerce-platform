# DelegateCart — Low Level Design (LLD)

> **Round 30 — April 10, 2026**

---

## 1. Smart Intent Engine — Function-Level Design

### `getSmartIntentRecords` (`apps/web/lib/db.ts`)

```typescript
type Condition = { sql: string; param?: unknown };

async function getSmartIntentRecords(
  limit = 50, offset = 0,
  search?: string, sortField = 'id', sortDir = 'desc',
  filterActive?: 'active' | 'inactive',
  filterAI?: 'enriched' | 'unenriched',
  filterQueryBy?: string,
  filterQueryText?: string,
): Promise<{ records: SmartIntentRecord[]; total: number }>
```

**Algorithm:**
1. Build `rawConditions: Condition[]` — each entry has a SQL fragment with `?` placeholder and an optional param value
2. Conditions added in order: global `search` on queryText, per-column `filterQueryBy`, per-column `filterQueryText`, `filterActive`, `filterAI`
3. Re-index for COUNT query: replace `?` with `$1`, `$2`, … → count query params array
4. Re-index for SELECT query: replace `?` with `$3`, `$4`, … (since `$1=limit`, `$2=offset`)
5. Execute COUNT query; if `rawConditions` is empty, use bare `SELECT COUNT(*)` (no WHERE)
6. Execute SELECT query; build ORDER BY from whitelisted `sortField`
7. Return `{ records, total }`

**Whitelist for `sortField`:**
```typescript
const ALLOWED_SORT_FIELDS = new Set(['id','queryBy','queryText','enhancedByAI','isActive','createdAt','updatedAt']);
if (!ALLOWED_SORT_FIELDS.has(sortField)) sortField = 'id';
```

---

## 2. Chat Session Grouping (`ShoppingChat.tsx`)

### `chatSessions` useMemo

```
Input: messages: Message[]
Output: Session[]

Session {
  id: string         // "session-{idx}"
  query: string      // first user message text
  messages: Message[]
  productCount: number  // count of assistant messages with products
}

Algorithm:
  sessions = []
  for each message in messages:
    if message.role === 'user':
      push new session { id, query: message.content, messages: [message] }
    else if sessions.length > 0:
      append message to last session
      if message has products: increment productCount
  return sessions
```

### Auto-collapse Effect

```
Trigger: chatSessions.length changes
If chatSessions.length > prevSessionCountRef.current:
  For each session except the last:
    add session.id to collapsedSessionIds
  prevSessionCountRef.current = chatSessions.length
```

### pendingQuery Consumption

```
Trigger: pendingQuery prop changes
If pendingQuery is truthy AND !== pendingQueryRef.current:
  pendingQueryRef.current = pendingQuery  // prevent re-fire
  onPendingQueryHandled?.()              // clear parent state immediately
  handleSendMessage(pendingQuery)        // fire and forget
```

---

## 3. Learning Dashboard Filter + Debounce (`app/admin/learning/page.tsx`)

```typescript
const fetchTimerRef = useRef<NodeJS.Timeout>();

// Only source of truth for fetch triggers:
useEffect(() => {
  if (!mounted || !isAdmin) return;
  if (fetchTimerRef.current) clearTimeout(fetchTimerRef.current);
  fetchTimerRef.current = setTimeout(() => fetchRecords(), 350);
  return () => clearTimeout(fetchTimerRef.current);
}, [mounted, isAdmin, fetchRecords]);  // fetchRecords is useCallback-memoized
```

`fetchRecords` builds URL params:
```typescript
const params = new URLSearchParams();
params.set('page', String(page));
params.set('limit', String(pageSize));
params.set('sort', sortField);
params.set('dir', sortDir);
if (search?.trim()) params.set('search', search.trim());
if (colFilters.queryBy?.trim()) params.set('filterQueryBy', colFilters.queryBy.trim());
if (colFilters.queryText?.trim()) params.set('filterQueryText', colFilters.queryText.trim());
// Merge toolbar filters with col filters
const effectiveActive = activeFilter || (colFilters.active === 'yes' ? 'active' : colFilters.active === 'no' ? 'inactive' : undefined);
if (effectiveActive) params.set('filterActive', effectiveActive);
```

---

## 4. Metrics Computation (`shopping-assistant/page.tsx`)

```typescript
// productsCount
const productsCount = liveProducts.length > 0 ? liveProducts.length : 
  (storedProducts?.length ?? 47);

// avgScore — weighted average of product.score (0–100)
const avgScore = liveProducts.length > 0
  ? Math.round(liveProducts.reduce((a, p) => a + (p.score ?? 0), 0) / liveProducts.length)
  : storedScore ?? 88;

// timeSaved — sum of liveTimeline step durations converted to human string
const totalMs = liveTimeline.reduce((a, s) => a + (s.duration ?? 0), 0);
const timeSaved = totalMs > 0
  ? totalMs >= 60000 ? `${Math.floor(totalMs/60000)}m ${Math.round((totalMs%60000)/1000)}s`
                     : `${Math.round(totalMs/1000)}s`
  : storedTime ?? '4m 12s';
```

**Persistence:**
```typescript
useEffect(() => {
  if (liveProducts.length > 0) localStorage.setItem('dc-metrics-products', JSON.stringify(liveProducts));
  if (liveTimeline.length > 0) localStorage.setItem('dc-metrics-timeline', JSON.stringify(liveTimeline));
  localStorage.setItem('dc-metrics-ts', new Date().toISOString());
}, [liveProducts, liveTimeline]);
```

---

## 5. API Route: `/api/admin/learning` (GET)

```
URL params → validated → passed to getSmartIntentRecords
Response: { records: SmartIntentRecord[], total: number, page: number, pageSize: number }
```

| Param | Validation | Default |
|-------|-----------|---------|
| `page` | parseInt, min 0 | 0 |
| `limit` | parseInt, clamp 1–200 | 50 |
| `sort` | whitelist | 'id' |
| `dir` | 'asc'\|'desc' | 'desc' |
| `search` | string, max 200 chars | undefined |
| `filterQueryBy` | string, max 200 chars | undefined |
| `filterQueryText` | string, max 200 chars | undefined |
| `filterActive` | 'active'\|'inactive' | undefined |
| `filterAI` | 'enriched'\|'unenriched' | undefined |

Security: Input passed directly to parameterized SQL — no string interpolation, no SQL injection risk.

---

## 6. Metric Detail Pages — Data Contract

### `/shopping-assistant/metrics/products`
```typescript
// Reads from localStorage
const raw = localStorage.getItem('dc-metrics-products');
const products: RankedProduct[] = raw ? JSON.parse(raw) : demoProducts;

// RankedProduct interface (from packages/types or inline)
interface RankedProduct {
  id: string; name: string; brand: string;
  price: number; originalPrice?: number;
  score: number; rating?: number;
  deliveryDays?: number; features?: string[];
  isExternal?: boolean;
  scoreBreakdown?: { budget: number; quality: number; brand: number; delivery: number; ratings: number };
}
```

### `/shopping-assistant/metrics/time-saved`
```typescript
interface TimelineStep { label: string; duration: number; }  // duration in ms
// Read from localStorage['dc-metrics-timeline']
// Traditional shopping time: hardcoded 78 min (research-backed)
// AI time: sum(timeline step durations)
// Saved: traditional - AI; Percent: saved/traditional * 100
```

---

## 7. Autopilot Checkout Engine Components

| Component | Purpose |
|-----------|---------|
| `AutopilotOrchestrator` | Top-level state machine — drives sequence |
| `DeliverySelector` | Finds and selects optimal delivery window via API |
| `CouponApplier` | Fetches available coupons, applies best by discount % |
| `AddressFiller` | Reads default address from user profile |
| `PaymentExecutor` | Processes payment via wallet or saved card |
| `WebSocketEmitter` | Broadcasts each step result to frontend |
| `IdempotencyGuard` | Checks Redis before executing any financial operation |
