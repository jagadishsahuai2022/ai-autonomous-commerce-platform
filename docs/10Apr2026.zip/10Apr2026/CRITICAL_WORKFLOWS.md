# DelegateCart — Critical Workflows

> **Round 30 — April 10, 2026**

---

## Workflow 1: Shortcut Chip → Chat Flow (NEW — Round 30)

```
┌─────────────┐   click    ┌───────────────────────────────────────┐
│ Chip Button │──────────▶ │ shopping-assistant/page.tsx            │
└─────────────┘             │  setPendingQuery(chipText)            │
                            └────────────────┬──────────────────────┘
                                             │ prop: pendingQuery
                                             ▼
                            ┌───────────────────────────────────────┐
                            │ ShoppingChat.tsx                       │
                            │  useEffect: pendingQuery !== prev ref  │
                            │  → pendingQueryRef.current = query     │
                            │  → onPendingQueryHandled()             │
                            │  → handleSendMessage(query)            │
                            └────────────────┬──────────────────────┘
                                             │
                                             ▼
                            ┌───────────────────────────────────────┐
                            │ handleSendMessage(text)                │
                            │  1. POST /api/ai/intent {query}        │
                            │  2. Intent engine returns questions    │
                            │  3. Questions rendered as choices      │
                            │  4. User picks answers                 │
                            │  5. Product ranking returned           │
                            │  6. New session panel created          │
                            │  7. Previous sessions auto-collapsed   │
                            └───────────────────────────────────────┘
```

**Key properties:**
- Ref guard `pendingQueryRef` prevents double-send if component re-renders
- `onPendingQueryHandled` clears parent's `pendingQuery` immediately on first render
- Full chat flow — identical to manual typing + Enter

---

## Workflow 2: Chat Session Lifecycle (NEW — Round 30)

```
Initial state: messages=[], chatSessions=[], collapsedIds={}

User sends query "best laptop under 50k"
  → messages = [{ role:'user', content:'best laptop...' }]
  → chatSessions = [Session{ id:'session-0', query:'best laptop...' }]
  → prevSessionCount 0→1, no collapse needed
  → Session-0 is EXPANDED by default

AI responds with questions
  → messages = [userMsg, assistantMsg]
  → Session-0 still has 1 session, no collapse

User sends second query "wireless headphones"
  → messages = [userMsg1, a1, a2, userMsg2]
  → chatSessions = [Session-0{query:'best laptop'}, Session-1{query:'wireless headphones'}]
  → prevSessionCount 1→2
  → Auto-collapse: collapsedIds = {'session-0'}
  → Session-1 is EXPANDED (latest)

User clicks Session-0 header
  → toggleSession('session-0')
  → collapsedIds = {} (session-0 re-expands)
```

---

## Workflow 3: DB-Side Learning Grid Filter (IMPROVED — Round 30)

```
Admin opens /admin/learning
  → fetchRecords() called (no filters) → SELECT * LIMIT 20 OFFSET 0
  → Grid shows first page

Admin types "john" in "Query By" column filter popup
  → setColFilter('queryBy', 'john')
  → setPage(0)
  → debounce timer starts (350ms)
  → timer fires → fetchRecords()
  → GET /api/admin/learning?filterQueryBy=john&page=0&limit=20&sort=id&dir=desc

API handler → getSmartIntentRecords(20, 0, ..., filterQueryBy='john')
  → rawConditions = [{ sql: '"queryBy" ILIKE ?', param: '%john%' }]
  → countSQL = 'SELECT COUNT(*) FROM ... WHERE "queryBy" ILIKE $1'  params=['%john%']
  → selectSQL = 'SELECT * FROM ... WHERE "queryBy" ILIKE $3 ORDER BY "id" DESC LIMIT $1 OFFSET $2' params=[20, 0, '%john%']
  → Returns { records: [...], total: 42 }

Grid updates: "42 total records", shows page 1 of 3
```

---

## Workflow 4: AI Enrichment Batch

```
Admin selects 5 records → chooses "gpt-4" model → clicks "Enrich"

Pre-flight checks:
  ✓ At least 1 record selected
  ✓ Model chosen
  ✓ Records: active=true, enhancedByAI=false, createdAt within 30 days

Enrichment loop (per record):
  POST /api/admin/learning/enrich { recordId, model }
  → Build prompt: "Given this shopping query: {queryText}\nIntentEngineResponse: {json}\n..."
  → Call LLM API (streaming disabled for batch)
  → Parse response as JSON
  → PATCH SmartIntentEngineResponse.aiEnrichedResponse + enhancedByAI=true
  → Append comment: { action: 'ai_enriched', model, timestamp }
  → Update progress bar UI (completedCount/total)

  On error: record error in per-record error state; continue next record

After all: refresh grid; show success toast with count; show error list if any
```

---

## Workflow 5: Autonomous Checkout

```
User triggers autopilot (from cart or shopping assistant)

AutopilotOrchestrator starts:
  1. INIT: Load cart items, check inventory
     WS event: { step: 'init', status: 'complete' }

  2. ADDRESS: Read default shipping address
     WS event: { step: 'address', value: '123 Main St...', status: 'complete' }

  3. COUPON: Fetch available coupons, apply best discount
     WS event: { step: 'coupon', value: 'SAVE20', discount: '₹200', status: 'complete' }

  4. DELIVERY: Select delivery method (speed vs. price preference)
     WS event: { step: 'delivery', value: 'Express 2-day', status: 'complete' }

  5. PAYMENT: IdempotencyGuard check → execute wallet/card payment
     WS event: { step: 'payment', status: 'processing' }
     WS event: { step: 'payment', status: 'complete', orderId: 'ORD-12345' }

  6. CONFIRM: Order placed, receipt generated
     WS event: { step: 'confirm', orderId: 'ORD-12345', status: 'complete' }

UI: Each WS event animates the step as complete; final step shows confetti + order link
```

---

## Workflow 6: Metrics → Detail Page Navigation (NEW — Round 30)

```
User completes a chat session:
  liveProducts updated → metrics computed → persisted to localStorage

User clicks "Products" metric tile:
  → Link href="/shopping-assistant/metrics/products"
  → Next.js navigates to ProductsMetricsPage
  → useEffect: reads localStorage['dc-metrics-products']
  → Renders product grid with all ranked products
  → Shows brand distribution, score breakdown bars
  → "Back to Shopping" link

User clicks "47 products" → sees full ranked list with deep score analysis
User clicks "88%" → sees 5-dimension score methodology + distribution chart
User clicks "4m 12s" → sees traditional vs AI timing comparison
```

---

## Workflow 7: Notification Delivery

```
System event triggers (e.g., order placed, price drop):
  → publisher.emit('notification.create', payload)
  → Kafka consumer (NotificationConsumer) receives message
  → Creates Notification record in DB
  → WebSocket gateway: emit to user's room if online
  → If push subscription registered: sends browser push
  → Bell icon badge count incremented via WS event
```
