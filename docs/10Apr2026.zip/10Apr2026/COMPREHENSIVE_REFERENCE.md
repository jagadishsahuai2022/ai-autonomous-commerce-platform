# DelegateCart — Comprehensive Documentation Reference (10 Apr 2026)

> Consolidated overview of all documentation created on 10 Apr 2026, including RBAC roles, subscriptions, metrics validation, and system architecture.

---

## Table of Contents

1. [RBAC Roles & Access Control](#1-rbac-roles--access-control)
2. [Subscription Tiers](#2-subscription-tiers)
3. [Metrics Validation & Trust Scoring](#3-metrics-validation--trust-scoring)
4. [System Architecture](#4-system-architecture)
5. [Agentic AI & LLM Integration](#5-agentic-ai--llm-integration)
6. [Smart Intent Engine](#6-smart-intent-engine)
7. [Self-Learning System](#7-self-learning-system)
8. [Observability & Monitoring](#8-observability--monitoring)
9. [Payment & Wallet System](#9-payment--wallet-system)
10. [Audit Logging & Idempotency](#10-audit-logging--idempotency)
11. [Notification System](#11-notification-system)
12. [Database Schema](#12-database-schema)
13. [Critical Workflows (SVG Diagrams)](#13-critical-workflows)
14. [Document Index](#14-document-index)

---

## 1. RBAC Roles & Access Control

**Source**: [RBAC_ROLES_AND_SUBSCRIPTIONS.md](../RBAC_ROLES_AND_SUBSCRIPTIONS.md)

### 7 Application Roles

| Role | Description | Blocked Paths | Cross-User Data |
|------|-------------|---------------|-----------------|
| **admin** | Full system access, user management, all analytics | None | All pages |
| **analytics** | All analytics pages, no admin dashboard | `/admin` | Validation, Learning, Observability |
| **aiplus** | AI+ features, shopping assistant, smart delegate | `/admin`, `/observability`, `/admin/learning` | None |
| **observability** | System monitoring, transaction tracking | `/admin` | Validation, Observability |
| **reinforced-learning** | Learning dashboard, feedback signals | `/admin`, `/observability` | Validation, Learning |
| **basic** | Core shopping features only | `/admin`, `/observability`, `/admin/learning`, `/ai-plus` | None |
| **customer** | Minimal access (unauthenticated) | Most pages | None |

### Cross-User Data Visibility Matrix

| Page | admin | analytics | observability | reinforced-learning | aiplus | basic |
|------|-------|-----------|---------------|---------------------|--------|-------|
| Metrics Validation | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| Self-Learning Dashboard | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| Observability Dashboard | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |

### Demo Users (MVP)

| Email | Role | Subscription |
|-------|------|-------------|
| admin@delegatecart.com | admin | AI_PLUS |
| admin@example.com | admin | AI_PLUS |
| analytics@delegatecart.com | analytics | BASIC |
| aiplusdemo@delegatecart.com | aiplus | AI_PLUS |
| observability@delegatecart.com | observability | BASIC |
| reenforcedlearning@delegatecart.com | reinforced-learning | BASIC |
| basicdemo@delegatecart.com | basic | BASIC |

**Password**: `Admin@DC2024!` (configurable via `NEXT_PUBLIC_ADMIN_PASSWORD`)

---

## 2. Subscription Tiers

### BASIC
- Core shopping assistant
- Shopping list management
- Standard cart & checkout
- Basic product search

### AI_PLUS
- All BASIC features
- AI+ enhanced search with LLM ranking
- Smart Delegate (autonomous shopping)
- Auto-checkout with wallet integration
- Advanced metrics & analytics
- Custom AI model preferences (GPT-4o, Claude 3, etc.)
- Higher monthly AI budget (up to ₹50,000)

---

## 3. Metrics Validation & Trust Scoring

**Source**: [METRICS_VALIDATION_TRUST_SCORING.md](../METRICS_VALIDATION_TRUST_SCORING.md)

### 7-Dimension Scoring Framework

1. **Budget Fit** — Product price vs. user's stated budget range
2. **Specification Match** — Feature count & richness from product catalog (replaces subjective "Quality")
3. **Warranty Coverage** — Warranty term parsed from product features text
4. **Manufacturer Profile** — Brand tier (Premium/Rising/Standard), country, reputation
5. **Brand Trust** — User preference alignment + brand reliability
6. **Delivery Performance** — Last 12-month on-time rate, avg delivery days
7. **Verified Ratings** — OTP-verified review estimate (42% of total reviews)

### Trust Level Classification

| Review Count | Trust Level | Weight in Scoring |
|-------------|-------------|-------------------|
| ≥ 5,000 | **Highly Trusted** | 100% |
| 500 – 4,999 | **Trusted** | 85% |
| < 500 | **Limited Data** | 60% |

### Enhanced Data Panels (R38)

Each product in the Metrics Validation page now shows:
- **Product Specifications**: Price, brand, rating, delivery, key features, 4 product images + video
- **Delivery Performance (12 months)**: On-time rate, avg delivery days, orders fulfilled, return rate, monthly trend chart
- **Ratings Analytics**: Star distribution, sentiment analysis (positive/neutral/negative), topic tags
- **Brand & Manufacturer Profile**: Country, trust score, market presence, service centers, certifications (ISO, BIS)
- **Warranty & Redemption**: Coverage, score, claim approval rate, resolution time, claim type breakdown
- **Spec Match vs Query**: Per-feature relevance scoring, matched/unmatched highlights
- **Smart Intent Feedback**: Speech-bubble style conversational feedback display with learning cycle info

### Validation Chips on Search Results

Products in Shopping Assistant and Smart Delegate show trust validation chips:
- Budget fit percentage
- Brand tier (Premium/Rising/Standard)
- Delivery speed
- Rating trust level

Visible to roles: admin, analytics, observability, reinforced-learning.

---

## 4. System Architecture

**Source**: [SYSTEM_ARCHITECTURE.md](SYSTEM_ARCHITECTURE.md), [HIGH_LEVEL_DESIGN.md](HIGH_LEVEL_DESIGN.md), [LOW_LEVEL_DESIGN.md](LOW_LEVEL_DESIGN.md)

### Technology Stack
- **Frontend**: Next.js 14 (App Router), TypeScript, Tailwind CSS, Framer Motion
- **Backend**: NestJS + Next.js API Routes
- **Database**: PostgreSQL with Prisma ORM
- **Cache**: Redis
- **Message Queue**: Kafka (event-driven architecture)
- **AI/ML**: Python FastAPI (ai-service), LLM integration
- **Infrastructure**: Docker, Kubernetes-ready

### Key Services
- `apps/web` — Next.js frontend + API routes
- `apps/api` — NestJS backend API
- `apps/ai-service` — Python AI/ML microservice
- `apps/autopilot-engine` — Autonomous checkout engine
- `apps/intent-parser` — Natural language intent parsing
- `apps/product-aggregator` — Multi-source product aggregation
- `apps/product-ranking-engine` — AI-powered product ranking

---

## 5. Agentic AI & LLM Integration

**Source**: [AGENTIC_AI_INTEGRATION.md](AGENTIC_AI_INTEGRATION.md), [AI_LLM_INTEGRATION.md](AI_LLM_INTEGRATION.md)

- Multi-model support: GPT-4o, GPT-4o-mini, Claude 3 Sonnet/Haiku, OpenRouter
- Agent Authorization Framework for autonomous actions
- LLM-powered product ranking with explainable scoring
- Conversational shopping assistant with context retention
- Auto-checkout agent with risk assessment

---

## 6. Smart Intent Engine

**Source**: [SMART_INTENT_ENGINE.md](SMART_INTENT_ENGINE.md)

- Natural language query understanding
- Multi-step intent clarification with feedback gathering
- Budget extraction, brand preference detection
- Feature requirement mapping
- Feedback signals drive learning loop: Intent → Search → Rank → Feedback → Learn → Improve

---

## 7. Self-Learning System

**Source**: [SELF_LEARNING_SYSTEM.md](SELF_LEARNING_SYSTEM.md)

- DB-side filtering with 7 filter types + 3 sort fields
- LLM model selector for batch AI enrichment
- Audit trail with 7 action types
- Row selection for batch operations + CSV export
- Cross-user data visible to: admin, analytics, reinforced-learning

---

## 8. Observability & Monitoring

**Source**: [OBSERVABILITY.md](OBSERVABILITY.md)

- Transaction state machine tracking
- Wallet transaction history with stuck transaction replay
- Audit log with 8 state colors
- Admin login gate with session management
- Cross-user data visible to: admin, analytics, observability

---

## 9. Payment & Wallet System

**Source**: [PAYMENT_WALLET.md](PAYMENT_WALLET.md)

- Wallet-based payment with auto-debit
- Transaction audit trail
- Risk-based approval thresholds
- EMI availability tracking

---

## 10. Audit Logging & Idempotency

**Source**: [AUDIT_LOGGING.md](AUDIT_LOGGING.md), [IDEMPOTENCY.md](IDEMPOTENCY.md)

- All state transitions logged with actor, timestamp, before/after states
- Idempotent API operations for retry safety
- Cryptographic audit trail integrity

---

## 11. Notification System

**Source**: [NOTIFICATION_API.md](NOTIFICATION_API.md)

- WhatsApp integration
- Email notifications
- In-app toast notifications
- Event-driven via Kafka

---

## 12. Database Schema

**Source**: [DB_SCHEMA.md](DB_SCHEMA.md)

Key tables: User, UserSession, Order, OrderItem, Product, Address, WalletTransaction, AuditLog, LearningRecord

---

## 13. Critical Workflows

SVG workflow diagrams available in this directory:

| Workflow | File |
|----------|------|
| AI Search | [WORKFLOW_AI_SEARCH.svg](WORKFLOW_AI_SEARCH.svg) |
| Approval & Decision | [WORKFLOW_APPROVAL_DECISION.svg](WORKFLOW_APPROVAL_DECISION.svg) |
| Auto Checkout | [WORKFLOW_AUTO_CHECKOUT.svg](WORKFLOW_AUTO_CHECKOUT.svg) |
| Cart & Wishlist | [WORKFLOW_CART_WISHLIST.svg](WORKFLOW_CART_WISHLIST.svg) |
| Metrics & Observability | [WORKFLOW_METRICS_OBSERVABILITY.svg](WORKFLOW_METRICS_OBSERVABILITY.svg) |
| Notification System | [WORKFLOW_NOTIFICATION_SYSTEM.svg](WORKFLOW_NOTIFICATION_SYSTEM.svg) |
| Product Detail & Compare | [WORKFLOW_PRODUCT_DETAIL_COMPARE.svg](WORKFLOW_PRODUCT_DETAIL_COMPARE.svg) |
| Product Search & Ranking | [WORKFLOW_PRODUCT_SEARCH_RANKING.svg](WORKFLOW_PRODUCT_SEARCH_RANKING.svg) |
| Self-Learning | [WORKFLOW_SELF_LEARNING.svg](WORKFLOW_SELF_LEARNING.svg) |
| Session State | [WORKFLOW_SESSION_STATE.svg](WORKFLOW_SESSION_STATE.svg) |
| Shopping List & Notification | [WORKFLOW_SHOPPING_LIST_NOTIFICATION.svg](WORKFLOW_SHOPPING_LIST_NOTIFICATION.svg) |
| User Auth | [WORKFLOW_USER_AUTH.svg](WORKFLOW_USER_AUTH.svg) |
| Wallet & Payment | [WORKFLOW_WALLET_PAYMENT.svg](WORKFLOW_WALLET_PAYMENT.svg) |
| Architecture Diagram | [ARCHITECTURE_DIAGRAM.svg](ARCHITECTURE_DIAGRAM.svg) |

---

## 14. Document Index

All documentation created on 10 Apr 2026:

| # | Document | Description |
|---|----------|-------------|
| 1 | AGENTIC_AI_INTEGRATION.md | Agentic AI framework & agent authorization |
| 2 | AI_LLM_INTEGRATION.md | LLM integration patterns & model selection |
| 3 | ARCHITECTURE_DIAGRAM.svg | System architecture visualization |
| 4 | AUDIT_LOGGING.md | Audit logging architecture |
| 5 | CRITICAL_WORKFLOWS.md | Critical business workflow documentation |
| 6 | DB_SCHEMA.md | Database schema reference |
| 7 | FUNCTIONAL_DOCUMENTATION.md | Functional requirements & specifications |
| 8 | HIGH_LEVEL_DESIGN.md | High-level system design |
| 9 | IDEMPOTENCY.md | Idempotent operations design |
| 10 | LOW_LEVEL_DESIGN.md | Low-level component design |
| 11 | NOTIFICATION_API.md | Notification system API reference |
| 12 | OBSERVABILITY.md | Observability & monitoring design |
| 13 | PAYMENT_WALLET.md | Payment & wallet system design |
| 14 | SELF_LEARNING_SYSTEM.md | Self-learning / reinforced learning system |
| 15 | SMART_INTENT_ENGINE.md | Smart intent engine architecture |
| 16 | SYSTEM_ARCHITECTURE.md | System architecture overview |
| 17 | TECHNICAL_KT.md | Technical knowledge transfer document |
| 18 | 14 SVG Workflow Diagrams | Visual workflow diagrams (listed in section 13) |
| 19 | **COMPREHENSIVE_REFERENCE.md** | This consolidated reference document |

---

*Generated as part of R38 documentation refresh. All data reflects the current state of the DelegateCart platform including RBAC enhancements, metrics validation improvements, and validation chips feature.*
