# DelegateCart — Self/Supervised/Reinforced Learning System

## Overview

The Self-Learning System captures every AI-assisted shopping query, allows human supervisors to correct classification, and enables LLM-based enrichment — creating a continuously improving intent classification model.

---

## Three Learning Tiers

| Tier | Mechanism | Who drives it | Effect |
|------|-----------|---------------|--------|
| Self-learning | Auto-capture query + intent classification | System (automatic) | Raw data accumulation |
| Supervised learning | Human supervisor edits `supervisedResponse` | Admin team | Ground-truth labels |
| Reinforced / AI enrichment | LLM rewrites `aiEnrichedResponse` | Batch API call | Better classification signals |

---

## Database Table: `SmartIntentEngineResponse`

```sql
CREATE TABLE "SmartIntentEngineResponse" (
  "id"                          SERIAL PRIMARY KEY,
  "userId"                      INTEGER REFERENCES "User"("id") ON DELETE SET NULL,
  "queryBy"                     TEXT NOT NULL,          -- user email or session id
  "queryText"                   TEXT NOT NULL,          -- raw query
  "initialProductSuggestionText" TEXT,                  -- first suggestion paragraph
  "intentEngineResponse"        JSONB NOT NULL DEFAULT '{}', -- parsed intent
  "supervisedResponse"          JSONB NOT NULL DEFAULT '{}', -- supervisor correction
  "aiEnrichedResponse"          JSONB,                  -- LLM enrichment (nullable)
  "enhancedByAI"                BOOLEAN NOT NULL DEFAULT FALSE,
  "isActive"                    BOOLEAN NOT NULL DEFAULT TRUE,
  "comments"                    JSONB NOT NULL DEFAULT '[]', -- audit trail
  "createdAt"                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"                   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indices for server-side filtering performance
CREATE INDEX idx_sie_active ON "SmartIntentEngineResponse" ("isActive");
CREATE INDEX idx_sie_enhanced ON "SmartIntentEngineResponse" ("enhancedByAI");
CREATE INDEX idx_sie_query ON "SmartIntentEngineResponse" USING GIN (to_tsvector('english', "queryText"));
CREATE INDEX idx_sie_created ON "SmartIntentEngineResponse" ("createdAt" DESC);
```

---

## DB-Side Paging/Sorting/Filtering (Round 30)

The `getSmartIntentRecords` function in `lib/db.ts` accepts:

| Parameter | Type | Maps to SQL |
|-----------|------|-------------|
| `limit` | number | `LIMIT $1` |
| `offset` | number | `OFFSET $2` |
| `sortField` | SortField | `ORDER BY "${field}"` (whitelisted) |
| `sortDir` | 'asc'\|'desc' | `ASC`\|`DESC` |
| `search` | string | `"queryText" ILIKE $n` |
| `filterQueryBy` | string | `"queryBy" ILIKE $n` (per-column) |
| `filterQueryText` | string | `"queryText" ILIKE $n` (per-column) |
| `filterActive` | 'active'\|'inactive' | `"isActive" = $n` |
| `filterAI` | 'enriched'\|'unenriched' | `"enhancedByAI" = true/false` |

**Key design**: All conditions are built in a single pass using a `Condition[]` array, then indexed correctly for count query ($1…) and record query ($3…). This eliminates the previous double-indexing bug.

---

## Frontend Grid Features

### Per-Column Filter Popups
- Filter icon button in each filterable column header
- Click → floating popup (fixed-position, outside-click closes)
- Text input for `queryBy` / `queryText`
- Select for `ai?` (yes/no) and `active?` (yes/no)
- Changes are sent to the API as `filterQueryBy`, `filterQueryText`, etc.
- Debounced: 350ms after last keystroke to avoid excessive DB calls
- "Clear col filters" toolbar button appears when any filter is active

### Pagination
- Server-side: `limit + offset` parameters
- Page size options: 10, 20, 30, 50, 100
- Page counter: `Page N of M` | `Prev` | `Next` | `First` | `Last`

### Sorting
- Click column header → `sortField` + `sortDir` change → new DB query
- Sort icon changes: neutral → `SortAsc` → `SortDesc`

### AI Enrichment Batch
- Select records (checkbox) → choose LLM model → click "Enrich"
- Pre-flight connectivity check (no DB changes if LLM is down)
- Enriches only active + unenriched records within last 30 days
- Progress shown; errors collected per-record

---

## Audit Trail

Each admin action appends a JSON entry to `comments`:
```json
{ "text": "Supervised response updated by admin", "timestamp": "2026-04-10T...", "userId": "admin@delegatecart.com", "action": "supervisor_edited" }
```

Action types: `created`, `duplicate_deactivated`, `supervisor_edited`, `ai_enriched`, `toggled_active`

---

## Access Control

Dashboard accessible to `LEARNING_EMAILS`:
- `admin@delegatecart.com`
- `supervisedlearning@delegatecart.com`
- `observability@delegatecart.com`

Every API route validates `x-user-email` against this list before any DB operation.
