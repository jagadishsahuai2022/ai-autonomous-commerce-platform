# DelegateCart — High Level Design (HLD)

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Last Updated** | April 2026 |
| **Audience** | Architects, Tech Leads, CTOs, Investors |
| **Scope** | System-wide architecture, service boundaries, data flow |

---

## 1. Executive Overview

DelegateCart is an AI-powered e-commerce platform that **delegates shopping decisions to AI**. Users describe their needs in natural language; the system autonomously searches, scores, and optionally purchases products — all with full transparency, human-in-the-loop approval, and wallet-based payment.

### Key Innovation
- **Agentic AI Checkout**: AI completes end-to-end purchase without user intervention
- **Multi-Source Aggregation**: Searches internal catalog + Amazon + Flipkart simultaneously
- **5-Factor Scoring**: Budget fit × Quality × Brand × Delivery × Ratings
- **HITL Approval**: High-value/risky decisions require human approval within 24h
- **AI Memory**: System learns user preferences over time for better recommendations

---

## 2. System Architecture

### 2.1 High-Level Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          CLIENT LAYER                                    │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │  Next.js 14 (React 18 + TypeScript)   Port: 3000               │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────────────────┐ │   │
│  │  │ Products  │ │ Shopping │ │  Wallet  │ │  AI Shopping       │ │   │
│  │  │ Catalog   │ │ Cart     │ │ Dashboard│ │  Assistant (Chat)  │ │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └────────────────────┘ │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────────────────┐ │   │
│  │  │ Checkout  │ │ Orders   │ │ Profile  │ │  Observability     │ │   │
│  │  │ Flow      │ │ History  │ │ & Auth   │ │  Dashboard (Admin) │ │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └────────────────────┘ │   │
│  └──────────────────────────────────────────────────────────────────┘   │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │ HTTP / WebSocket
┌────────────────────────────────▼────────────────────────────────────────┐
│                       API GATEWAY LAYER                                  │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │  Next.js API Routes (Serverless Edge)                            │   │
│  │  /api/auth  /api/products  /api/cart  /api/orders  /api/wallet  │   │
│  │  /api/chat  /api/intent    /api/search /api/notifications       │   │
│  └──────────────────────────────┬───────────────────────────────────┘   │
└─────────────────────────────────┼───────────────────────────────────────┘
                                  │ Internal HTTP
┌─────────────────────────────────▼───────────────────────────────────────┐
│                       BUSINESS LOGIC LAYER                               │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │  NestJS 10 API  Port: 3001                                       │   │
│  │  Modules: Auth, Product, Cart, Order, Wallet, Agent, AI-Chat,   │   │
│  │           AI-Memory, AI-Execution, Buy-Request, Seller-Copilot  │   │
│  │  Prisma 7.5 ORM → PostgreSQL                                    │   │
│  └──────────────────────────────┬───────────────────────────────────┘   │
└─────────────────────────────────┼───────────────────────────────────────┘
                                  │ Kafka Events
┌─────────────────────────────────▼───────────────────────────────────────┐
│                       AI MICROSERVICES LAYER                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐ │
│  │ AI Service    │  │ Intent       │  │ Product      │  │ Product    │ │
│  │ (FastAPI)     │  │ Parser       │  │ Aggregator   │  │ Ranking    │ │
│  │ Port: 8000    │  │ Port: 3002   │  │ Port: 3003   │  │ Engine     │ │
│  │               │  │ GPT-4 +      │  │ Amazon +     │  │ Port: 3004 │ │
│  │ Recommendations│ │ Claude 3     │  │ Flipkart     │  │ NumPy      │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
                                  │
┌─────────────────────────────────▼───────────────────────────────────────┐
│                       DATA & INFRASTRUCTURE LAYER                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐ │
│  │ PostgreSQL 16 │  │ Redis 7      │  │ Apache Kafka │  │ Zookeeper  │ │
│  │ Port: 5432    │  │ Port: 6379   │  │ Port: 9092   │  │ Port: 2181 │ │
│  │ Primary DB    │  │ Cache/PubSub │  │ Event Bus    │  │ Kafka Mgmt │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Service Boundaries

| Service | Responsibility | Scaling Strategy |
|---------|---------------|-----------------|
| **Web (Next.js)** | UI rendering, API routing, SSR | Horizontal (stateless) |
| **API (NestJS)** | Business logic, ORM, auth | Horizontal (stateless) |
| **AI Service** | Product recommendations, scoring | Horizontal (CPU-bound) |
| **Intent Parser** | NLP extraction via LLM | Vertical (GPU/API-bound) |
| **Product Aggregator** | External API calls, caching | Horizontal + Redis cache |
| **Ranking Engine** | Multi-factor scoring, personalization | Horizontal (CPU-bound) |

---

## 3. Data Architecture

### 3.1 Database Strategy

```
PostgreSQL 16
├── User Management (User, UserPreferences, BuyingPattern)
├── Commerce (Product, Cart, CartItem, Order, OrderItem)
├── Wallet System (Wallet, WalletTransaction, WalletAuthorization, WalletSpendingLimit)
├── AI Models (BuyRequest, ChatMessage, UserMemory, MemoryInsight)
├── Agentic (ApprovalRequest, AIDecisionLog, AutoDecisionLog)
└── Seller (Seller, SellerProduct, ListingTemplate, PriceHistory, DemandMetrics)
```

### 3.2 Caching Strategy

| Cache Layer | Tool | TTL | Purpose |
|------------|------|-----|---------|
| Product catalog | Redis | 5 min | Frequently accessed products |
| Search results | Redis | 10 min | External API aggregated results |
| User sessions | Redis | 24h | Authentication tokens |
| AI memory | PostgreSQL | Persistent | Long-term preference learning |
| Client state | Zustand + sessionStorage | Session | Cart, chat, filters |

### 3.3 Event Streaming

```
Buy Request Pipeline:
  API ──▸ buy_request.created ──▸ Intent Parser
  Intent Parser ──▸ intent.processed ──▸ Product Aggregator
  Product Aggregator ──▸ products.fetched ──▸ Ranking Engine
  Ranking Engine ──▸ products.ranked ──▸ API / Autopilot Engine
```

---

## 4. Security Architecture

### 4.1 Authentication Flow

```
User → NextAuth (JWT) → Session Token → API Routes → NestJS JWT Validation
```

| Layer | Mechanism |
|-------|-----------|
| Frontend auth | NextAuth 4 (email/password, magic link) |
| API auth | JWT tokens (access + refresh) |
| Admin auth | Role-based + email whitelist |
| Wallet auth | AI spending authorization with limits |
| Inter-service | Internal Docker network (no public exposure) |

### 4.2 Authorization Matrix

| Role | Products | Cart/Orders | Wallet | Admin | AI Features |
|------|----------|-------------|--------|-------|-------------|
| Guest | Read | — | — | — | — |
| Buyer | Read | Full | Full | — | Full |
| Seller | Read/Write own | — | — | — | Copilot |
| Admin | Full | View all | View all | Full | Full |

---

## 5. Integration Points

### 5.1 External APIs

| API | Purpose | Auth | Fallback |
|-----|---------|------|----------|
| OpenAI GPT-4 | Intent parsing, NLP | API Key | Anthropic Claude |
| Anthropic Claude 3 | Alternate LLM provider | API Key | OpenAI GPT-4 |
| Amazon Product API | Product aggregation | API Key | Cache / DB products |
| Flipkart Product API | Product aggregation | API Key | Cache / DB products |
| Razorpay | Payment processing | Key + Secret | Mock payment mode |

### 5.2 Internal Communication

| From | To | Protocol | Purpose |
|------|----|----------|---------|
| Web → API | HTTP REST | Business operations |
| Web → AI Service | HTTP REST | Recommendations |
| API → Kafka | Event publish | Async processing |
| Kafka → Microservices | Event consume | Pipeline processing |
| Web ↔ API | WebSocket (Socket.io) | Real-time updates |

---

## 6. Deployment Architecture

### 6.1 Docker Compose (Development/Demo)

```yaml
7 core containers:
  - postgres (Alpine, persistent volume)
  - redis (Alpine, persistent volume)
  - zookeeper (Confluent CP 7.5)
  - kafka (Confluent CP 7.5, depends on zookeeper)
  - api (NestJS, depends on postgres + redis + kafka)
  - ai-service (FastAPI, depends on postgres + redis)
  - web (Next.js, depends on api + ai-service)
```

### 6.2 Network Topology

```
Docker Network: ai-commerce-network (bridge)
  All services communicate via container names
  Only exposed ports: 3000 (web), 3001 (api), 8000 (ai), 5432 (db)
```

---

## 7. Non-Functional Requirements

| Attribute | Target | Mechanism |
|-----------|--------|-----------|
| **Availability** | 99.9% | Docker restart policies, health checks |
| **Latency** | < 200ms (API), < 2s (AI) | Redis cache, connection pooling |
| **Throughput** | 1000 req/s (API) | Horizontal scaling, Kafka buffering |
| **Data Integrity** | ACID for transactions | PostgreSQL transactions, idempotency keys |
| **Security** | OWASP Top 10 compliant | JWT, input validation, CORS, rate limiting |
| **Observability** | Full tracing | OpenTelemetry, Prometheus metrics, custom dashboard |

---

## 8. Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Monorepo (pnpm + Turborepo) | Shared types, unified builds, developer velocity |
| Kafka over RabbitMQ | Event replay, ordering guarantees, high throughput |
| Prisma over TypeORM | Type safety, auto-generated client, migration management |
| Zustand over Redux | Simpler API, less boilerplate, per-store isolation |
| sessionStorage for UI state | Data cleared on tab close (privacy), survives navigation |
| Dual LLM provider | Failover between OpenAI and Anthropic for reliability |
| HITL for high-value decisions | Trust + safety: AI doesn't auto-spend beyond thresholds |
