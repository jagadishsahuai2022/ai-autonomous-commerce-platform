# DelegateCart — Technical Knowledge Transfer (KT) Document

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 2.0 |
| **Last Updated** | April 2026 |
| **Platform** | AI-Powered E-Commerce |
| **Architecture** | Microservices + Event-Driven |
| **Status** | Production-Ready |

---

## 1. System Architecture Overview

DelegateCart is a full-stack AI-powered e-commerce platform built on a microservices architecture with event-driven communication. The system comprises:

- **Frontend**: Next.js 14 (React 18 + TypeScript) — 55+ routes
- **API Layer**: Next.js API Routes + NestJS 10 backend
- **AI Services**: FastAPI (Python) + custom scoring engines
- **Event Bus**: Apache Kafka + Zookeeper
- **Storage**: PostgreSQL 16 + Redis 7 + Client localStorage
- **DevOps**: Docker Compose, Playwright E2E, pnpm monorepo

### Architecture Diagram

See [ARCHITECTURE_DIAGRAM.svg](ARCHITECTURE_DIAGRAM.svg) for the complete visual.

---

## 2. Technology Stack

### 2.1 Frontend (apps/web)

| Technology | Version | Purpose |
|-----------|---------|---------|
| Next.js | 14.2.35 | SSR/SSG React framework |
| React | 18.x | UI component library |
| TypeScript | 5.x | Type-safe JavaScript |
| Tailwind CSS | 3.x | Utility-first CSS |
| Zustand | 4.x | Lightweight state management |
| Framer Motion | 11.x | Animation library |
| Recharts | 3.8.0 | Chart/graph visualization |
| React Query | — | Server state management |
| Lucide React | — | Icon library |

### 2.2 Backend (apps/api + apps/web/app/api)

| Technology | Version | Purpose |
|-----------|---------|---------|
| NestJS | 10.x | Enterprise Node.js framework |
| PostgreSQL | 16 | Primary relational database |
| Redis | 7 | Caching layer |
| JWT | — | Stateless authentication |
| bcrypt | — | Password hashing |
| pg (node-postgres) | — | PostgreSQL driver |

### 2.3 AI Services (Python)

| Technology | Version | Purpose |
|-----------|---------|---------|
| FastAPI | — | AI service HTTP framework |
| OpenAI GPT-4 | — | Intent parsing / NLP |
| Anthropic Claude 3 | — | Alternative LLM provider |
| Pydantic | — | Data validation |

### 2.4 Infrastructure

| Technology | Version | Purpose |
|-----------|---------|---------|
| Docker Compose | — | Container orchestration |
| Apache Kafka | 7.5.0 | Event streaming |
| Zookeeper | 7.5.0 | Kafka coordination |
| Playwright | 1.58.2 | E2E browser testing |
| pnpm | 9.0.0 | Package management |

---

## 3. Project Structure (Monorepo)

```
delegatecart/                         # Root (pnpm workspace)
├── apps/
│   ├── web/                          # Next.js 14 Frontend + API Routes
│   │   ├── app/                      # App Router (55+ pages)
│   │   │   ├── api/                  # Server-side API routes
│   │   │   │   ├── auth/             # register, login, me, logout
│   │   │   │   ├── chat/message/     # AI chat endpoint
│   │   │   │   ├── shopping-list/    # Shopping list submission
│   │   │   │   ├── orders/           # Order CRUD
│   │   │   │   ├── user/             # profile, addresses, behavior, preferences
│   │   │   │   ├── analytics/        # Analytics tracking + reporting
│   │   │   │   └── products/         # Product catalog
│   │   │   ├── shopping-list/        # Shopping list page
│   │   │   ├── smart-delegate/       # AI results viewer
│   │   │   ├── ai-assistant/         # AI chat pages
│   │   │   ├── cart/                 # Shopping cart
│   │   │   ├── checkout/             # 4-step checkout
│   │   │   ├── profile/              # User profile
│   │   │   ├── admin/analytics/      # Analytics dashboard
│   │   │   ├── products/             # Product browse/manage
│   │   │   ├── orders/               # Order history
│   │   │   └── ...                   # 40+ more pages
│   │   ├── components/               # Reusable UI components
│   │   ├── lib/                      # Shared utilities
│   │   │   ├── db.ts                 # PostgreSQL query layer
│   │   │   ├── ai-scoring.ts         # 5-factor AI scoring engine
│   │   │   ├── stores.ts             # Zustand state stores
│   │   │   └── utils.ts              # Tailwind cn() utility
│   │   ├── e2e/                      # Playwright E2E tests
│   │   │   ├── enterprise-features.spec.ts  # 43 enterprise tests
│   │   │   ├── global-setup.ts       # Page pre-warming
│   │   │   └── *.spec.ts             # Additional test suites
│   │   └── types/                    # TypeScript type definitions
│   ├── api/                          # NestJS Backend API
│   │   ├── src/
│   │   │   ├── auth/                 # Authentication module
│   │   │   ├── products/             # Product module
│   │   │   ├── orders/               # Order module
│   │   │   └── websocket/            # WebSocket gateway
│   ├── ai-service/                   # FastAPI GenAI Service
│   ├── intent-parser/                # NLP Intent Parser (Python)
│   ├── product-aggregator/           # Multi-source Search (Python)
│   ├── product-ranking-engine/       # Weighted Ranking (Python)
│   └── autopilot-engine/             # Auto-purchase Engine (NestJS)
├── packages/
│   └── ui/                           # Shared React component library
├── infra/docker/                     # Dockerfiles
├── docs/                             # Documentation
├── docker-compose.yml                # Full stack orchestration
├── pnpm-workspace.yaml               # Workspace config
└── package.json                      # Root package config
```

---

## 4. Database Schema

### 4.1 Core Tables

#### User
```sql
CREATE TABLE "User" (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(100),
  passwordHash VARCHAR(255),
  whatsappNumber VARCHAR(20),
  notificationEmail VARCHAR(255),
  avatarUrl VARCHAR(500),
  displayName VARCHAR(100),
  aliasName VARCHAR(100),
  subscriptionPlan VARCHAR(20) DEFAULT 'basic',
  aiModel VARCHAR(50) DEFAULT 'gpt-4o-mini',
  defaultShippingAddressId INT,
  autoPurchaseEnabled BOOLEAN DEFAULT false,
  autoPurchaseThreshold INT DEFAULT 5000,
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW()
);
```

#### UserSession
```sql
CREATE TABLE "UserSession" (
  userId INT REFERENCES "User"(id),
  token VARCHAR(500) PRIMARY KEY,
  email VARCHAR(255),
  expiresAt TIMESTAMP NOT NULL
);
```

#### Order & OrderItem
```sql
CREATE TABLE "Order" (
  id SERIAL PRIMARY KEY,
  userId INT REFERENCES "User"(id),
  total DECIMAL(12,2),
  status VARCHAR(30) DEFAULT 'processing',
  aiAssisted BOOLEAN DEFAULT false,
  orderNumber VARCHAR(50) UNIQUE,
  paymentMethod VARCHAR(30),
  shippingAddress JSONB,
  notes TEXT,
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW()
);

CREATE TABLE "OrderItem" (
  id SERIAL PRIMARY KEY,
  orderId INT REFERENCES "Order"(id),
  productId INT,
  productName VARCHAR(200),
  quantity INT DEFAULT 1,
  price DECIMAL(12,2),
  imageUrl VARCHAR(500)
);
```

#### ShoppingListSearch (Cache)
```sql
CREATE TABLE "ShoppingListSearch" (
  id SERIAL PRIMARY KEY,
  userId INT,
  searchHash VARCHAR(64),
  items JSONB,
  results JSONB,
  summary JSONB,
  createdAt TIMESTAMP DEFAULT NOW(),
  expiresAt TIMESTAMP  -- 5-hour TTL
);
```

### 4.2 User Data Tables

#### UserAddress
```sql
CREATE TABLE "UserAddress" (
  id SERIAL PRIMARY KEY,
  userId INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  line1 VARCHAR(200) NOT NULL,
  line2 VARCHAR(200),
  city VARCHAR(50) NOT NULL,
  state VARCHAR(50) NOT NULL,
  pincode VARCHAR(6) NOT NULL,
  isDefault BOOLEAN DEFAULT false,
  createdAt TIMESTAMP DEFAULT NOW()
);
-- Validation: pincode must be 6 digits, phone must be 10 digits
```

#### UserPreference
```sql
CREATE TABLE "UserPreference" (
  id SERIAL PRIMARY KEY,
  userId INT UNIQUE NOT NULL,
  preferredBrands JSONB DEFAULT '[]',
  budgetRange JSONB DEFAULT '{"min":0,"max":100000}',
  categories JSONB DEFAULT '[]',
  notifications JSONB DEFAULT '{"email":true,"whatsapp":false,"push":true}',
  updatedAt TIMESTAMP DEFAULT NOW()
);
```

#### UserBehavior
```sql
CREATE TABLE "UserBehavior" (
  id SERIAL PRIMARY KEY,
  userId INT,
  productId VARCHAR(100),
  action VARCHAR(30) NOT NULL,  -- click, add_to_cart, remove_from_cart, purchase, reject, search, view
  metadata JSONB DEFAULT '{}',
  createdAt TIMESTAMP DEFAULT NOW()
);
```

### 4.3 Analytics Tables

#### AnalyticsEvent
```sql
CREATE TABLE "AnalyticsEvent" (
  id SERIAL PRIMARY KEY,
  eventType VARCHAR(50) NOT NULL,
  userId INT,
  productId VARCHAR(100),
  metadata JSONB DEFAULT '{}',
  createdAt TIMESTAMP DEFAULT NOW()
);
-- Allowed eventTypes: page_view, search, add_to_cart, remove_from_cart, purchase, ai_recommendation, click, view
```

#### AiRecommendation
```sql
CREATE TABLE "AiRecommendation" (
  id SERIAL PRIMARY KEY,
  userId INT,
  productId VARCHAR(100),
  score DECIMAL(5,2),
  accepted BOOLEAN,
  createdAt TIMESTAMP DEFAULT NOW()
);
```

---

## 5. API Reference

### 5.1 Authentication APIs

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | No | Register new user |
| POST | `/api/auth/login` | No | Login (returns JWT token) |
| GET | `/api/auth/me` | Bearer | Get current user profile |
| POST | `/api/auth/logout` | Bearer | Invalidate session |

### 5.2 User APIs

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/user/profile` | Bearer | Get full user profile |
| PUT | `/api/user/profile` | Bearer | Update profile fields |
| GET | `/api/user/addresses` | Bearer | List all addresses |
| POST | `/api/user/addresses` | Bearer | Create new address |
| PUT | `/api/user/addresses` | Bearer | Update address |
| DELETE | `/api/user/addresses?id=N` | Bearer | Delete address |
| GET | `/api/user/preferences` | Bearer | Get user preferences |
| PUT | `/api/user/preferences` | Bearer | Update preferences |
| POST | `/api/user/behavior` | Optional | Track user behavior |
| GET | `/api/user/behavior` | Bearer | Get behavior history |
| GET | `/api/user/behavior?type=stats` | Bearer | Get behavior stats |

### 5.3 Commerce APIs

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/shopping-list` | Optional | Submit shopping list |
| POST | `/api/chat/message` | Optional | Send chat message |
| GET | `/api/orders` | Bearer | List user orders |
| POST | `/api/orders` | Bearer | Place new order |
| GET | `/api/orders/[id]` | Bearer | Get order details |
| GET | `/api/products` | No | Browse product catalog |

### 5.4 Analytics APIs

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/analytics?days=N` | Bearer | Get analytics summary |
| POST | `/api/analytics` | Bearer | Track analytics event |

### 5.5 Input Validation Rules

**Address fields:**
- `pincode`: Must be exactly 6 digits (`/^\d{6}$/`)
- `phone`: Must be 10 digits (after stripping spaces/hyphens)
- `name`: Max 100 characters
- `line1`: Max 200 characters
- `city`, `state`: Max 50 characters each

**Analytics events:**
- `eventType` must be one of: `page_view`, `search`, `add_to_cart`, `remove_from_cart`, `purchase`, `ai_recommendation`, `click`, `view`

**Behavior actions:**
- `action` must be one of: `click`, `add_to_cart`, `remove_from_cart`, `purchase`, `reject`, `search`, `view`

---

## 6. AI Scoring Engine

### 6.1 Algorithm Overview

The scoring engine rates every product match on a 0–100 scale using five weighted factors:

```
aiScore = (relevance × 0.30) + (preferenceMatch × 0.25) +
          (priceFit × 0.20) + (ratingScore × 0.15) + (aiConfidence × 0.10)
```

### 6.2 Factor Breakdown

| Factor | Weight | Range | Calculation |
|--------|--------|-------|-------------|
| **Relevance** | 30% | 0-100 | Name match (+50), brand match (+20), keyword overlap (+30) |
| **Preference Match** | 25% | 0-100 | Baseline 50 + brand history (+25), price range (+15), cart behavior (+10/-15) |
| **Price Fit** | 20% | 0-100 | ≤70% budget→90, ≤100%→100, ≤110%→70, ≤130%→40, >130%→10 |
| **Rating Score** | 15% | 0-100 | `(rating / 5) × 100` |
| **AI Confidence** | 10% | 0-100 | `matchScore × 1.05` (capped at 100) |

### 6.3 Explanation Generation

The engine produces human-readable explanations:
- "High relevance to '{query}'" — when relevance ≥ 70
- "Matches your preferences" — when preferenceMatch ≥ 70
- "Within your budget range" — when priceFit ≥ 80
- "Highly rated (4.5/5)" — when ratingScore ≥ 80
- "EMI available" — when emiAvailable is true

### 6.4 Source File

Located at `apps/web/lib/ai-scoring.ts`. Input: array of products + user context. Output: sorted `ScoredProduct[]` with aiScore, aiExplanation, aiConfidence, scoreBreakdown.

---

## 7. Authentication & Security

### 7.1 Auth Flow

1. **Registration**: POST `/api/auth/register` → password hashed with bcrypt → User row + UserSession row created → JWT token returned
2. **Login**: POST `/api/auth/login` → bcrypt.compare → new UserSession created → JWT token returned
3. **Session Validation**: Every protected API call → `validateSession(token)` → checks UserSession table → verifies expiration → returns `{userId, email}`
4. **Logout**: POST `/api/auth/logout` → deletes UserSession row

### 7.2 Security Measures Implemented

| Security Control | Implementation |
|-----------------|----------------|
| Password hashing | bcrypt with salt rounds |
| Session tokens | Cryptographically random, stored in DB |
| Auth header | `Authorization: Bearer <token>` |
| Input validation | Regex: pincode (6-digit), phone (10-digit), field length limits |
| SQL injection prevention | Parameterized queries ($1, $2 placeholders) |
| Mock payment safety | Toggle only visible in `NODE_ENV === 'development'`, defaults to OFF |
| Analytics auth | POST endpoint requires authentication (prevents spam) |
| Event type whitelist | Only allowed event types accepted |
| Behavior action whitelist | Only valid actions accepted |

### 7.3 Fixes Applied (This Session)

| Issue | Severity | Fix |
|-------|----------|-----|
| Mock payment bypass in production | CRITICAL | Toggle restricted to `NODE_ENV === 'development'` only, default `false` |
| Analytics POST unauthenticated | CRITICAL | Added auth check + event type whitelist |
| Tax precision error | HIGH | Changed from `Math.round(x * 0.18)` to `Math.round(x * 18) / 100` |
| `parseInt` missing radix | HIGH | Added radix 10 to all 12 parseInt calls |
| `Bearer null` auth headers | HIGH | Guarded with `if (!token)` early returns |
| Empty catch blocks | MEDIUM | Added `console.error` logging |
| Address validation missing | MEDIUM | Added pincode, phone, length validation |
| JSON.parse without try-catch | MEDIUM | Wrapped in try-catch with fallback |
| Mock payment env var exposed | MEDIUM | Changed docker-compose default to `false` |

---

## 8. Docker Deployment

### 8.1 Services

| Service | Image | Port | Health Check |
|---------|-------|------|-------------|
| postgres | postgres:16-alpine | 5432 | pg_isready |
| redis | redis:7-alpine | 6379 | redis-cli ping |
| zookeeper | confluentinc/cp-zookeeper:7.5.0 | 2181 | — |
| kafka | confluentinc/cp-kafka:7.5.0 | 9092 | — |
| api | Custom NestJS | 3001 | — |
| ai-service | Custom FastAPI | 8000 | — |
| web | Custom Next.js | 3000 | — |

### 8.2 Key Commands

```bash
# Start all services
docker-compose up -d

# Deploy file changes (hot-reload)
docker cp <local-path> ai-commerce-web:/app/<container-path>

# View logs
docker logs ai-commerce-web --tail 100 -f

# Execute commands in container
docker exec -it ai-commerce-web sh

# Database access
docker exec -it ai-commerce-postgres psql -U admin -d ai_commerce
```

### 8.3 Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DB_HOST` | postgres | Database hostname |
| `DB_PORT` | 5432 | Database port |
| `DB_USER` | admin | Database user |
| `DB_PASSWORD` | password | Database password |
| `DB_NAME` | ai_commerce | Database name |
| `JWT_SECRET` | (development key) | JWT signing secret |
| `KAFKA_BROKERS` | kafka:29092 | Kafka broker address |
| `REDIS_URL` | redis://redis:6379 | Redis connection URL |
| `ENABLE_MOCK_PAYMENT` | false | Enable mock payment toggle |

---

## 9. Testing Strategy

### 9.1 E2E Test Suite (Playwright)

**Configuration** (`playwright.config.ts`):
- Serial execution (`fullyParallel: false`)
- 1 worker, 1 retry, 120s timeout
- Global setup: pre-warms 18 pages
- Browser: Chromium headless

**Enterprise Features Test** (`enterprise-features.spec.ts`): 43 tests covering:

| Test Group | Count | Coverage |
|-----------|-------|----------|
| Profile Page Redesign | 10 | Sections, fields, plan selector, AI model |
| Address Management | 4 | Add form, fields, cancel |
| API Routes | 7 | Auth checks, CRUD responses |
| Shopping List AI | 3 | AI scoring fields, sorting |
| Cart External Handling | 4 | Badge, warning, disabled checkout |
| Checkout Address | 4 | Address loading, empty state |
| Analytics Dashboard | 5 | Metrics, charts, time range |
| Chat API | 3 | Message response, products |
| Smart Delegate | 2 | Page load, AI score display |

### 9.2 Test Helpers

```typescript
loginViaLocalStorage(page, email)  // Sets authToken + userEmail
goto(page, path)                    // Navigate with domcontentloaded
waitForProfileForm(page)            // Waits 40s for React Query retries
```

### 9.3 Test Results

```
43 passed (10.2m) — 0 failed, 0 flaky
```

---

## 10. Performance Considerations

| Area | Implementation |
|------|---------------|
| DB Connection Pool | Max 10 connections, 30s idle timeout |
| Redis Caching | Product search 1h TTL, shopping list 5h TTL |
| Client Caching | localStorage for cart, results (max 20 entries) |
| React Query | Automatic retry with exponential backoff |
| Image Optimization | Next.js Image component with lazy loading |
| Code Splitting | Next.js App Router automatic code splits |
| Bundle Size | Tree-shaking with Tailwind CSS purge |

---

## 11. Kafka Event Topics

| Topic | Producer | Consumer | Payload |
|-------|----------|----------|---------|
| `buy_request.created` | Shopping List API | Intent Parser | Shopping list items |
| `intent.processed` | Intent Parser | Product Aggregator | Normalized categories, keywords |
| `products.fetched` | Product Aggregator | Ranking Engine | Raw product results |
| `products.ranked` | Ranking Engine | Web/Autopilot | Scored + sorted products |
| `order.placed` | Checkout API | Notification Service | Order confirmation |
| `notification.send` | Various | Notification Service | WhatsApp/Email payload |

---

## 12. Known Limitations

1. **Mock Product Data**: Chat API and Shopping List API use simulated product catalogs for demo; production requires real API integrations (Amazon MWS, Flipkart Affiliate)
2. **WhatsApp Integration**: Requires Twilio/WhatsApp Business API setup for production
3. **Payment Gateway**: Razorpay integration keys needed; mock bypass only in development
4. **Python Services**: Require separate `pip install -r requirements.txt` setup
5. **Session Storage**: Database-backed sessions; consider Redis sessions for scale

---

## 13. Self-Learning & Reinforcement Learning System

The platform includes a self-learning mechanism that captures every user query and enables supervised corrections + automated AI enrichment. For full details, see [SELF_LEARNING_SYSTEM.md](SELF_LEARNING_SYSTEM.md).

### Key Components
- **SmartIntentEngineResponse** table (PostgreSQL) — stores all queries with engine output, supervised edits, and AI-enriched responses
- **Learning Lookup** (`findLearnedResponse`) — two-strategy matching (exact + word containment) with priority: AI > Supervised > Original
- **Admin Dashboard** (`/admin/learning`) — CRUD interface with inline editing, modal editor, and batch AI enrichment
- **Chat Integration** — both `/api/chat/message` and `/api/intent/analyze` capture queries and use learned responses
- **18 unit tests** covering all DB functions and learning pipeline

### Test Coverage (Total)
| Suite | Files | Tests |
|-------|-------|-------|
| Smart Intent Learning | 1 | 18 |
| Smart Intent Engine | 3 | 171 |
| Shopping List | 1 | 53 |
| Cart / Checkout | 2 | 53 |
| Product (API, Card, Store) | 3 | 58 |
| Sphere (3D) | 4 | 50 |
| Other (Auth, Error, Profile, etc.) | 9 | 107 |
| **Total** | **27** | **~510** |
