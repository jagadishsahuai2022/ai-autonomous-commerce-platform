# DelegateCart — Agentic AI Integration Documentation

## Document Metadata

| Field            | Value                                                                 |
| ---------------- | --------------------------------------------------------------------- |
| **Version**      | 1.0                                                                   |
| **Last Updated** | April 2026                                                            |
| **Scope**        | Agentic checkout, HITL workflows, AI decision-making, approval system |

---

## 1. Overview

DelegateCart implements **Agentic AI** — an AI system that can autonomously execute multi-step workflows (search → evaluate → purchase) on behalf of users, with configurable human-in-the-loop (HITL) checkpoints for safety.

### Key Principles

- **Autonomy with Guardrails**: AI acts independently within user-defined spending limits
- **Transparency**: Every AI decision is logged with reasoning and confidence scores
- **Reversibility**: Failed transactions auto-refund; approvals expire after 24 hours
- **Progressive Trust**: System learns user preferences and adjusts confidence thresholds

---

## 2. Architecture

```
┌─────────────────────────────────────────────────────┐
│                AGENTIC CHECKOUT ENGINE                │
│                                                       │
│  ┌───────────┐    ┌────────────┐    ┌─────────────┐ │
│  │ Decision   │───▸│ Risk       │───▸│ Execution   │ │
│  │ Engine     │    │ Assessment │    │ Engine      │ │
│  └───────────┘    └────────────┘    └─────────────┘ │
│       │                │                    │         │
│       ▼                ▼                    ▼         │
│  ┌───────────┐    ┌────────────┐    ┌─────────────┐ │
│  │ AI Memory │    │ Approval   │    │ Wallet      │ │
│  │ Service   │    │ Workflow   │    │ Transaction │ │
│  └───────────┘    └────────────┘    └─────────────┘ │
└─────────────────────────────────────────────────────┘
```

---

## 3. Decision Engine

### 3.1 Decision Flow

```
Input: Ranked products + User preferences + Wallet state
  │
  ▼
Calculate confidence score (0.0 – 1.0)
  │
  ▼ confidence >= 0.8 AND price <= aiSpendingLimit
  │         │
  │ Yes     │ No (low confidence OR high value)
  ▼         ▼
AUTO-EXECUTE   CREATE APPROVAL REQUEST
  │                    │
  ▼                    ▼
ExecuteOrder()   Notify user → 24h window
                       │
                  User approves? ──▸ ExecuteOrder()
                       │
                  User rejects? ──▸ Log + Archive
                       │
                  Expired (24h)? ──▸ Auto-reject
```

### 3.2 Confidence Calculation

```typescript
function calculateConfidence(product: Product, intent: BuyRequest, memory: UserMemory): number {
  let confidence = 0;

  // Price within budget (0-0.3)
  confidence += budgetFitScore(product.price, intent.budgetMin, intent.budgetMax) * 0.3;

  // Brand match (0-0.2)
  confidence += brandMatchScore(product.brand, intent.preferredBrands) * 0.2;

  // Quality score (0-0.2)
  confidence += (product.qualityScore / 100) * 0.2;

  // Historical preference match (0-0.2)
  confidence += memoryMatchScore(product, memory.currentPreferences) * 0.2;

  // Delivery timeline match (0-0.1)
  confidence += deliveryMatchScore(product.deliveryDays, intent.deliveryDate) * 0.1;

  return confidence;
}
```

### 3.3 Risk Assessment

| Risk Factor         | Weight | Criteria                          |
| ------------------- | ------ | --------------------------------- |
| Order amount        | 0.3    | > ₹5000 = high risk               |
| First-time category | 0.2    | Never bought this category before |
| Price anomaly       | 0.2    | > 30% above market average        |
| Brand unknown       | 0.15   | Brand not in user's history       |
| Delivery delay      | 0.15   | Delivery > requested date         |

---

## 4. Approval Workflow (HITL)

### 4.1 Database Model

```prisma
model ApprovalRequest {
  id            String   @id @default(uuid())
  userId        String
  reason        String          // Why approval is needed
  status        String          // pending | approved | rejected | expired
  orderAmount   Float
  aiReasoning   String          // AI's explanation for the recommendation
  riskScore     Float           // 0.0-1.0 risk assessment
  expiresAt     DateTime        // 24 hours from creation
  resolvedAt    DateTime?
  resolvedBy    String?         // 'user' | 'system' (auto-expire)
  userFeedback  String?         // Optional rejection reason
  productData   Json            // Snapshot of recommended product
  createdAt     DateTime @default(now())
}
```

### 4.2 Frontend Approval Panel

Located in `shopping-assistant/page.tsx` sidebar → "Approval" tab:

```
┌────────────────────────────┐
│ ⚠️ Approval Required       │
│                            │
│ Product: Sony WH-1000XM5  │
│ Price: ₹24,999             │
│ AI Confidence: 0.72        │
│ Risk: Medium               │
│                            │
│ AI Reasoning:              │
│ "Best match for your       │
│  budget and brand          │
│  preference, but price     │
│  is at the upper range"    │
│                            │
│ [✓ Approve] [✗ Reject]    │
│ Expires in: 23h 45m        │
└────────────────────────────┘
```

### 4.3 Approval Resolution

```typescript
// On approve
async function handleApprove(approvalId: string) {
  // 1. Update ApprovalRequest status → 'approved'
  // 2. Execute wallet debit (idempotent)
  // 3. Create order
  // 4. Log AIDecisionLog (decision: 'approved_by_user')
  // 5. Update AI memory (reinforce preference)
}

// On reject
async function handleReject(approvalId: string, feedback: string) {
  // 1. Update ApprovalRequest status → 'rejected'
  // 2. Log AIDecisionLog (decision: 'rejected_by_user')
  // 3. Update AI memory (negative reinforcement)
  // 4. Store user feedback for future calibration
}
```

---

## 5. AI Decision Logging

### 5.1 Database Model

```prisma
model AIDecisionLog {
  id           String   @id @default(uuid())
  userId       String
  traceId      String          // OpenTelemetry trace ID
  decisionType String          // 'auto_purchase' | 'approval_request' | 'recommendation'
  input        Json            // Buy request + context snapshot
  output       Json            // Decision result + product selected
  confidence   Float           // 0.0-1.0
  reasoning    String          // Human-readable explanation
  successful   Boolean?        // Post-execution outcome
  executionMs  Int?            // Total decision time
  createdAt    DateTime @default(now())
}
```

### 5.2 Tracing Integration

```
OpenTelemetry Trace:
  Span: agentic_checkout
    ├── Span: intent_parsing (LLM call)
    ├── Span: product_aggregation (Redis + APIs)
    ├── Span: product_ranking (scoring engine)
    ├── Span: decision_making (confidence + risk)
    ├── Span: approval_check (HITL gate)
    └── Span: order_execution (wallet + order creation)
```

---

## 6. Auto-Decision System

### 6.1 Auto-Decision Types

| Decision Type     | Trigger                          | Auto-Action                  |
| ----------------- | -------------------------------- | ---------------------------- |
| `auto_purchase`   | Score > threshold, within limits | Debit wallet + create order  |
| `auto_reorder`    | Repeat purchase detected         | Suggest reorder notification |
| `price_alert`     | Watched product price drops      | Notify user                  |
| `cart_suggestion` | AI predicts need                 | Add to cart suggestion       |

### 6.2 Auto-Decision Log

```prisma
model AutoDecisionLog {
  id           String   @id @default(uuid())
  userId       String
  decisionType String
  decision     String          // The action taken
  confidence   Float
  successful   Boolean?
  input        Json            // Context that triggered decision
  output       Json            // Result of decision
  createdAt    DateTime @default(now())
}
```

---

## 7. Safety Mechanisms

| Mechanism               | Implementation                                                  |
| ----------------------- | --------------------------------------------------------------- |
| Spending limits         | Daily, weekly, monthly, per-order limits in WalletSpendingLimit |
| AI authorization toggle | `Wallet.isAiAuthorized` flag must be true                       |
| AI spending cap         | `Wallet.aiSpendingLimit` — max per AI-initiated transaction     |
| Approval for high-value | Creates ApprovalRequest for orders above threshold              |
| 24-hour expiry          | Unapproved requests auto-expire and are logged                  |
| Idempotency             | Every transaction uses unique idempotency key                   |
| Refund on failure       | Failed auto-checkouts trigger automatic wallet refund           |
| Audit trail             | Every decision logged in AIDecisionLog with OpenTelemetry trace |
| User feedback loop      | Rejected approvals feed back into AI memory calibration         |

---

## 8. Configuration

| Setting                 | Location                | Default  |
| ----------------------- | ----------------------- | -------- |
| Auto-checkout enabled   | Shopping List UI toggle | false    |
| AI wallet authorization | Wallet settings         | false    |
| AI spending limit       | Wallet settings         | ₹5,000   |
| Confidence threshold    | Environment variable    | 0.8      |
| Approval expiry         | Hardcoded               | 24 hours |
| Max daily AI spend      | WalletSpendingLimit     | ₹10,000  |
