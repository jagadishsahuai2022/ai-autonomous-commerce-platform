# DelegateCart — Idempotency Patterns

> Comprehensive documentation of idempotency strategies across the platform.

---

## Table of Contents

1. [Overview](#overview)
2. [Database-Level Idempotency](#database-level-idempotency)
3. [API-Level Idempotency](#api-level-idempotency)
4. [Checkout & Payment Idempotency](#checkout--payment-idempotency)
5. [Message Queue Idempotency (Kafka)](#message-queue-idempotency-kafka)
6. [State Management Idempotency](#state-management-idempotency)
7. [Self-Learning System Idempotency](#self-learning-system-idempotency)

---

## Overview

Idempotency ensures that repeated operations produce the same result as a single execution. DelegateCart applies idempotency patterns at multiple layers to prevent duplicate operations during retries, race conditions, and network failures.

---

## Database-Level Idempotency

### Upsert Patterns (ON CONFLICT)
```sql
-- User creation with role assignment
INSERT INTO "User" (email, name, "passwordHash", "role", "updatedAt")
  VALUES ($1, $2, $3, $4, NOW())
  ON CONFLICT (email) DO UPDATE SET "role" = $4;

-- SmartIntentEngineResponse column migration
ALTER TABLE "SmartIntentEngineResponse"
  ADD COLUMN IF NOT EXISTS "isActive" BOOLEAN DEFAULT true;
```

### Unique Constraints
| Table | Constraint | Purpose |
|-------|-----------|---------|
| `User` | `User_email_key` | Prevents duplicate user registrations |
| `Product` | `Product_sku_key` | Prevents duplicate product SKUs |
| `WalletTransaction` | `idempotencyKey` column | Prevents duplicate wallet operations |

### Transactional Guarantees
- All wallet operations use `BEGIN`/`COMMIT` transactions
- Order creation + inventory deduction wrapped in a single transaction
- Cart operations use optimistic concurrency via `updatedAt` checks

---

## API-Level Idempotency

### Idempotency Key Pattern (Wallet Transactions)

```typescript
// Each wallet operation requires a unique idempotencyKey
POST /api/wallet/credit
{
  "userId": 1,
  "amount": 5000,
  "idempotencyKey": "credit-order-123-refund"
}
```

**How it works**:
1. Client generates a unique key per logical operation
2. Server checks if key exists in `WalletTransactionLog`
3. If found → returns the original result (no re-execution)
4. If not found → executes operation, stores key + result

### PATCH Operations (Learning System)

The learning system PATCH endpoint is naturally idempotent:
```
PATCH /api/admin/learning
{ "id": 42, "isActive": false }
```
Repeated calls with the same payload produce the same DB state.

---

## Checkout & Payment Idempotency

### Agentic Checkout Flow

| Step | Idempotency Pattern |
|------|-------------------|
| Cart validation | Read-only — always idempotent |
| Address selection | Last-write-wins with `updatedAt` |
| Payment authorization | `WalletAuthorization.id` prevents duplicate holds |
| Order creation | `orderId` generated before insert; ON CONFLICT skips |
| Wallet debit | `idempotencyKey = order-{orderId}-payment` |
| Confirmation email | Kafka consumer deduplicates by `orderId` |

### Race Condition Prevention
```
User clicks "Place Order" twice rapidly:
  Request 1 → acquires row-level lock on wallet
  Request 2 → blocks on lock, then finds balance insufficient → rejects
```

---

## Message Queue Idempotency (Kafka)

### Consumer Deduplication

Kafka consumers track processed message offsets:
```
Topic: order-events
├── Partition 0: consumer tracks last committed offset
├── Partition 1: at-least-once delivery → consumer deduplicates
└── Consumer group: ai-commerce-consumers
```

### Event Processing
- **Order events**: Deduplicated by `orderId` in the event payload
- **Notification events**: Deduplicated by `notificationId`
- **Analytics events**: Append-only — duplicates are acceptable (low-impact)

---

## State Management Idempotency

### Zustand Store Hydration

The products page uses session-persistent state with idempotent hydration:

```typescript
// product-page-store.ts
hydrate: () => {
  if (get().hasHydrated) return; // Idempotent guard
  const saved = loadFromSession();
  if (saved) set({ ...saved, hasHydrated: true });
  else set({ hasHydrated: true });
}
```

### Sphere Store Hydration
```typescript
// useSphereStore.ts — idempotent initialization
useEffect(() => {
  if (!initializedRef.current) {
    initializedRef.current = true; // Run once guard
    useSphereStore.getState().hydrate();
    // ... expansion/dock decision
  }
}, [categories.length]);
```

**Race condition fix**: `isHydrated` state gate prevents the `useInfiniteProducts` query from firing before session state is restored, eliminating the stale-empty-query race.

---

## Self-Learning System Idempotency

### Record Capture
- `insertSmartIntentRecord()` always creates a new record (no dedup needed — each query is unique)
- `updateSupervisedResponse()` and `updateAIEnrichedResponse()` are idempotent SET operations

### isActive Toggle
```typescript
// Optimistic UI update + server sync
handleToggleActive(id, currentValue) → PATCH { id, isActive: !currentValue }
// If network fails → toast error, local state not corrupted (not persisted)
// Retry → same result as first attempt
```

### AI Batch Enrichment
- `getUnenrichedRecords()` returns only records with `enhancedByAI = false`
- After enrichment, `updateAIEnrichedResponse()` sets `enhancedByAI = true`
- Re-running batch enrichment is safe — already-enriched records are skipped

---

## Key Takeaways

1. **Database constraints** are the ultimate idempotency guard (unique keys, upserts)
2. **Wallet operations** use explicit idempotency keys for financial safety
3. **UI state hydration** uses `hasHydrated` / `initializedRef` guards to prevent double-init
4. **Kafka consumers** deduplicate by business ID (orderId, notificationId)
5. **API endpoints** are designed to be safely retried without side effects
