# DelegateCart — AI Search, Decision & LLM Integration Documentation

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Last Updated** | April 2026 |
| **Scope** | AI search pipeline, product scoring, LLM integration, decision engine, AI memory |

---

## 1. AI-Powered Search Pipeline

### 1.1 End-to-End Flow

```
User Query (Natural Language)
  │
  ▼
┌──────────────────┐
│ Chat Interface    │  ShoppingChat.tsx → POST /api/chat/message
│ (Frontend)        │  OR POST /api/chat/stream (SSE)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Intent Analysis   │  Extract: product, budget, brands, features
│ (API Route)       │  Uses LLM or regex-based extraction
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Product Search    │  Query PostgreSQL: name ILIKE, category filter,
│ (Database)        │  price range, brand filter
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ AI Scoring        │  5-factor scoring: budget × quality × brand
│ (Scoring Engine)  │  × delivery × ratings = 0-100 score
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Personalization   │  Apply user preference weights from
│ (AI Memory)       │  RankingPersonalization table
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Response Format   │  Product cards with scores, reasoning,
│ (API Response)    │  add-to-cart actions
└──────────────────┘
```

### 1.2 Search Modes

| Mode | Endpoint | Input | Processing |
|------|----------|-------|-----------|
| **Text chat** | `/api/chat/message` | Natural language | LLM intent extraction |
| **Streaming chat** | `/api/chat/stream` | Natural language | SSE (Server-Sent Events) |
| **Product search** | `/api/search` | Keywords + filters | Direct DB query |
| **Image search** | `/api/search/image` | Image upload | Image → text → search |
| **Voice search** | `/api/search/voice` | Audio recording | Speech → text → search |

---

## 2. 5-Factor AI Scoring Engine

### 2.1 Scoring Formula

```
Product Score = Σ (weight_i × factor_i) × 100

Where:
  factor_1: Budget Fit     (0.0–1.0)  Weight: 0.30
  factor_2: Quality Score  (0.0–1.0)  Weight: 0.25
  factor_3: Brand Match    (0.0–1.0)  Weight: 0.20
  factor_4: Delivery Speed (0.0–1.0)  Weight: 0.15
  factor_5: User Ratings   (0.0–1.0)  Weight: 0.10
```

### 2.2 Factor Calculations

**Budget Fit** (weight: 0.30):
```python
def budget_fit(price, budget_min, budget_max):
    if price < budget_min:
        return 0.7  # Under budget (might be low quality)
    elif price <= budget_max:
        # Gaussian centered at budget midpoint
        mid = (budget_min + budget_max) / 2
        sigma = (budget_max - budget_min) / 4
        return exp(-0.5 * ((price - mid) / sigma) ** 2)
    else:
        # Over budget: rapid decay
        return max(0, 1 - (price - budget_max) / budget_max)
```

**Quality Score** (weight: 0.25):
```python
def quality_factor(product):
    return product.quality_score / 100  # Normalized 0-1
```

**Brand Match** (weight: 0.20):
```python
def brand_match(product_brand, preferred_brands):
    if not preferred_brands:
        return 0.5  # No preference = neutral
    if product_brand in preferred_brands:
        return 1.0  # Exact match
    return 0.3      # Non-preferred brand
```

**Delivery Speed** (weight: 0.15):
```python
def delivery_factor(delivery_days, requested_date):
    if not requested_date:
        return 0.5  # No preference
    days_remaining = (requested_date - today).days
    if delivery_days <= days_remaining:
        return 1.0  # On time
    else:
        delay = delivery_days - days_remaining
        return max(0, 1 - delay * 0.2)  # -20% per day late
```

**User Ratings** (weight: 0.10):
```python
def rating_factor(avg_rating, num_reviews):
    base = avg_rating / 5.0
    # Boost for more reviews (confidence)
    confidence = min(1, num_reviews / 100)
    return base * (0.7 + 0.3 * confidence)
```

### 2.3 Personalized Weight Override

```prisma
model RankingPersonalization {
  id               String @id @default(uuid())
  userId           String @unique
  categoryWeights  Json   // { "electronics": 1.2, "fashion": 0.8 }
  priceWeight      Float  @default(0.3)
  qualityWeight    Float  @default(0.25)
  brandWeight      Float  @default(0.2)
  deliveryWeight   Float  @default(0.15)
  ratingWeight     Float  @default(0.1)
}
```

Users with `RankingPersonalization` records get custom weights. New users get defaults.

---

## 3. LLM Integration

### 3.1 Provider Architecture

```
┌───────────────────────────────────────────┐
│            LLM Router                      │
│                                             │
│  ┌─────────────┐    ┌─────────────────┐   │
│  │  OpenAI      │    │  Anthropic       │   │
│  │  GPT-4       │    │  Claude 3 Opus   │   │
│  │  (Primary)   │    │  (Fallback)      │   │
│  └──────┬──────┘    └────────┬────────┘   │
│         │                     │             │
│         └──────┬──────────────┘             │
│                ▼                             │
│  ┌─────────────────────────────────────┐   │
│  │  Rule-Based Fallback (No LLM)       │   │
│  │  Regex extraction for basic intents  │   │
│  └─────────────────────────────────────┘   │
└───────────────────────────────────────────┘
```

### 3.2 LLM Usage Points

| Feature | Module | LLM Use | Model |
|---------|--------|---------|-------|
| Chat responses | AI Chat Service | Conversational AI, product Q&A | GPT-4 / Claude |
| Intent extraction | Intent Parser | Structured intent from NL | GPT-4 / Claude |
| Listing generation | Seller Copilot | Product descriptions | GPT-4 |
| Demand prediction | Seller Copilot | Trend analysis | GPT-4 |
| Answer questions | Intent API | Product-specific Q&A | Claude |

### 3.3 Prompt Templates

**Chat Response**:
```
System: You are an AI shopping assistant for DelegateCart.
        Help users find products by understanding their needs.
        Respond with product recommendations when possible.
        Always include price in ₹ (Indian Rupees).

User: {user_message}
Context: {user_preferences}, {recent_searches}, {cart_items}
```

**Intent Extraction**:
```
System: Extract a structured purchase intent from the user's request.
        Return JSON with: product, budgetMin, budgetMax, qualityScore,
        preferredBrands[], deliveryDate, category, features[], quantity.
        Use INR for currency. Be precise with budget extraction.

Input: {raw_text}
```

**Product Description (Seller Copilot)**:
```
System: Generate an SEO-optimized product listing.
        Tone: {seller_tone_preference}
        Include: title, description, key features (bullets), specifications.
        Category: {category}
        
Product: {base_title}
Price: ₹{price}
```

### 3.4 Cost & Rate Limits

| Provider | Model | Cost (approx) | Rate Limit |
|----------|-------|---------------|------------|
| OpenAI | GPT-4 | $0.03/1K tokens | 500 RPM |
| Anthropic | Claude 3 Opus | $0.015/1K tokens | 50 RPM |
| Fallback | Rule-based | Free | Unlimited |

---

## 4. AI Memory System

### 4.1 Memory Architecture

```
┌─────────────────────────────────────────┐
│              AI MEMORY                    │
│                                           │
│  UserPreferences → What user likes        │
│  BuyingPattern → How user shops           │
│  UserMemory → AI's working memory         │
│  MemoryInsight → AI's analysis            │
│  RankingPersonalization → Custom weights  │
└─────────────────────────────────────────┘
```

### 4.2 Preference Learning

```
User action:
  View product → Update UserMemory.viewedProducts
  Search query → Update UserMemory.lastSearchQueries
  Purchase → Update BuyingPattern (avgPurchasesPerMonth, topCategories)
  Rate product → Update UserPreferences (preferredBrands, pricePreference)
  
Every N interactions → Generate MemoryInsight:
  - Purchase probability (0-1)
  - Churn risk (0-1)
  - Auto-decision confidence (0-1)
  - Top insights (text array)
```

### 4.3 Auto-Decision Pipeline

```
Trigger: AI identifies potential purchase opportunity
  │
  ▼
Load user memory (UserMemory + preferences + patterns)
  │
  ▼
Calculate decision confidence:
  - Product match score (from scoring engine)
  - Historical success rate (from AutoDecisionLog)
  - Preference alignment (from MemoryInsight)
  │
  ▼
confidence >= 0.8 AND wallet authorized?
  │         │
  │ Yes     │ No
  ▼         ▼
Execute     Request approval (HITL)
  │
  ▼
Log: AutoDecisionLog + AIDecisionLog
  │
  ▼
Track: UserMemoryInteraction (wasSuccessful?)
  │
  ▼
Update: MemoryInsight (recalculate confidence)
```

---

## 5. Product Aggregation

### 5.1 Multi-Source Architecture

```
Processed Intent (from Intent Parser)
  │
  ▼
Product Aggregator (Port 3003)
  │
  ├── Internal DB (PostgreSQL) ← Always queried
  ├── Amazon Product API ← If AMAZON_API_URL configured
  └── Flipkart Product API ← If FLIPKART_API_URL configured
  │
  ▼
Deduplicate by name similarity
  │
  ▼
Cache in Redis (TTL: 10 min, key: hash of intent)
  │
  ▼
Publish to Kafka: products.fetched
```

### 5.2 Caching Strategy

```python
# Redis cache for aggregated results
cache_key = f"agg:{hashlib.md5(json.dumps(intent, sort_keys=True)).hexdigest()}"
cached = redis.get(cache_key)
if cached:
    return json.loads(cached)  # Cache hit

results = await aggregate_from_all_sources(intent)
redis.setex(cache_key, REDIS_TTL, json.dumps(results))  # Cache miss → store
```

### 5.3 Deduplication

```python
def deduplicate(products: List[Product]) -> List[Product]:
    seen = {}
    for product in products:
        # Normalize name for comparison
        key = normalize_name(product.name)
        if key in seen:
            # Keep the one with more data / lower price
            seen[key] = merge_product_data(seen[key], product)
        else:
            seen[key] = product
    return list(seen.values())
```

---

## 6. Business Metrics Integration

### 6.1 Product Business Metrics

```prisma
model ProductBusinessMetrics {
  id               String  @id @default(uuid())
  productId        String  @unique
  marginPercentage Float   @default(0)
  inventoryCount   Int     @default(0)
  salesVelocity    Float   @default(0)
  conversionRate   Float   @default(0)
  returnRate       Float   @default(0)
}
```

### 6.2 Multi-Objective Ranking

Beyond the 5-factor user-facing score, business metrics influence ranking:

```
Final Rank = User Score × 0.7 + Business Score × 0.3

Business Score = (margin × 0.3 + inventory × 0.2 + velocity × 0.2 
                + conversion × 0.2 - returnRate × 0.1)
```

This ensures profitable, well-stocked products rank higher when user scores are similar, while maintaining user-first experience.

---

## 7. Debug & Testing

### 7.1 Debug Endpoint

```
GET /api/debug/business-ranking?productId={id}

Response:
{
  "productId": "...",
  "userScore": 85,
  "businessScore": 72,
  "finalRank": 81.1,
  "factors": {
    "budgetFit": 0.95,
    "quality": 0.80,
    "brand": 1.00,
    "delivery": 0.70,
    "ratings": 0.85
  },
  "businessFactors": {
    "margin": 0.45,
    "inventory": 200,
    "velocity": 12.5,
    "conversion": 0.08,
    "returnRate": 0.02
  }
}
```

### 7.2 Search Scenario Testing

```typescript
// scripts/generate-search-scenarios.ts
// Generates diverse test scenarios for AI search validation
const scenarios = [
  { query: "budget laptop under 30000", expected: { category: "electronics", budgetMax: 30000 } },
  { query: "birthday gift for mom", expected: { category: "gifts", budgetMax: null } },
  { query: "Sony headphones noise canceling", expected: { brand: "Sony", features: ["noise-canceling"] } },
];
```
