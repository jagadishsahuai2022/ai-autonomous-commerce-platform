# DelegateCart — Database Schema Documentation

> **Provider**: PostgreSQL | **ORM**: Prisma  
> **Schema File**: `apps/api/prisma/schema.prisma`  
> **Direct SQL**: `apps/web/lib/db.ts`

---

## Table of Contents

1. [Entity Relationship Overview](#entity-relationship-overview)
2. [User Management](#user-management)
3. [Product & Inventory](#product--inventory)
4. [Shopping & Orders](#shopping--orders)
5. [Wallet & Payment System](#wallet--payment-system)
6. [AI & Chat](#ai--chat)
7. [AI Memory System](#ai-memory-system)
8. [Agentic Checkout](#agentic-checkout)
9. [Direct SQL Tables](#direct-sql-tables)
10. [Indexes & Constraints](#indexes--constraints)

---

## Entity Relationship Overview

```
User ──┬── Order ──── OrderItem ──── Product
       ├── Cart ───── CartItem ───── Product
       ├── Wallet ─── WalletTransaction
       │              WalletAuthorization
       │              WalletSpendingLimit
       │              WalletAuditLog
       ├── ChatMessage
       ├── UserPreferences
       ├── UserMemory
       ├── BuyingPattern
       ├── MemoryInsight
       ├── BuyRequest
       ├── ActivityLog
       └── Seller ─── SellerProduct
                      ListingTemplate
                      PriceHistory
                      DemandMetrics
                      SellerAiAnalytics
```

---

## User Management

### User

| Column     | Type     | Constraints    | Description               |
| ---------- | -------- | -------------- | ------------------------- |
| id         | String   | PK, cuid       | Unique user identifier    |
| email      | String   | Unique         | User email                |
| password   | String   |                | Hashed password           |
| name       | String?  |                | Display name              |
| phone      | String?  |                | Phone number              |
| avatar     | String?  |                | Avatar URL                |
| role       | UserRole | Default: USER  | USER, SELLER, ADMIN       |
| isVerified | Boolean  | Default: false | Email verification status |
| createdAt  | DateTime | Default: now() | Account creation          |
| updatedAt  | DateTime | @updatedAt     | Last update               |

**Relations**: orders, cart, chatMessages, preferences, memory, buyingPatterns, memoryInsights, activityLogs, wallet, buyRequests, approvalRequests

### Seller

| Column            | Type    | Constraints       | Description                |
| ----------------- | ------- | ----------------- | -------------------------- |
| id                | String  | PK, cuid          | Seller identifier          |
| userId            | String  | FK → User, Unique | Associated user            |
| storeName         | String  |                   | Store display name         |
| storeDescription  | String? |                   | Store description          |
| gstin             | String? |                   | GST identification (India) |
| panNumber         | String? |                   | PAN number (India)         |
| bankAccountNumber | String? |                   | Bank account               |
| ifscCode          | String? |                   | IFSC code                  |
| isApproved        | Boolean | Default: false    | Admin approval status      |
| performanceScore  | Float?  |                   | Seller performance metric  |
| aiSettings        | Json?   |                   | Seller AI configuration    |

**Relations**: products (SellerProduct[]), listings, priceHistory, demandMetrics, aiAnalytics

---

## Product & Inventory

### Product

| Column      | Type     | Constraints    | Description         |
| ----------- | -------- | -------------- | ------------------- |
| id          | String   | PK, cuid       | Product identifier  |
| name        | String   |                | Product name        |
| description | String   |                | Product description |
| price       | Float    |                | Current price       |
| category    | String   |                | Product category    |
| image       | String?  |                | Primary image URL   |
| featured    | Boolean  | Default: false | Featured flag       |
| createdAt   | DateTime | Default: now() | Created timestamp   |
| updatedAt   | DateTime | @updatedAt     | Updated timestamp   |

**Relations**: cartItems, orderItems, sellerProducts

### SellerProduct

| Column              | Type    | Constraints   | Description              |
| ------------------- | ------- | ------------- | ------------------------ |
| id                  | String  | PK, cuid      | Listing identifier       |
| sellerId            | String  | FK → Seller   | Seller reference         |
| productId           | String? | FK → Product  | Base product reference   |
| title               | String  |               | Listing title            |
| description         | String  |               | Listing description      |
| price               | Float   |               | Seller price             |
| mrp                 | Float?  |               | Maximum retail price     |
| stock               | Int     | Default: 0    | Inventory count          |
| sku                 | String? | Unique        | Stock keeping unit       |
| category            | String  |               | Category                 |
| subcategory         | String? |               | Subcategory              |
| brand               | String? |               | Brand name               |
| images              | Json?   |               | Array of image URLs      |
| specifications      | Json?   |               | Product specifications   |
| listingQualityScore | Float?  |               | AI listing quality score |
| isActive            | Boolean | Default: true | Active listing flag      |

### PriceHistory

| Column         | Type    | Constraints    | Description              |
| -------------- | ------- | -------------- | ------------------------ |
| id             | String  | PK, cuid       | Record identifier        |
| sellerId       | String  | FK → Seller    | Seller reference         |
| productId      | String  |                | Product reference        |
| oldPrice       | Float   |                | Previous price           |
| newPrice       | Float   |                | Updated price            |
| reason         | String? |                | Price change reason      |
| aiSuggested    | Boolean | Default: false | AI-suggested change      |
| competitorData | Json?   |                | Competitor analysis data |

### DemandMetrics

| Column          | Type   | Constraints | Description                 |
| --------------- | ------ | ----------- | --------------------------- |
| id              | String | PK, cuid    | Record identifier           |
| sellerId        | String | FK → Seller | Seller reference            |
| category        | String |             | Product category            |
| predictedDemand | Float  |             | AI predicted demand         |
| actualDemand    | Float? |             | Actual demand (post-period) |
| confidence      | Float  |             | Prediction confidence       |
| period          | String |             | Time period                 |

---

## Shopping & Orders

### Cart

| Column    | Type     | Constraints       | Description     |
| --------- | -------- | ----------------- | --------------- |
| id        | String   | PK, cuid          | Cart identifier |
| userId    | String   | FK → User, Unique | Cart owner      |
| createdAt | DateTime | Default: now()    | Created         |
| updatedAt | DateTime | @updatedAt        | Updated         |

**Relations**: items (CartItem[])

### CartItem

| Column    | Type   | Constraints  | Description       |
| --------- | ------ | ------------ | ----------------- |
| id        | String | PK, cuid     | Item identifier   |
| cartId    | String | FK → Cart    | Parent cart       |
| productId | String | FK → Product | Product reference |
| quantity  | Int    | Default: 1   | Item quantity     |

**Unique**: [cartId, productId]

### Order

| Column          | Type        | Constraints      | Description                                       |
| --------------- | ----------- | ---------------- | ------------------------------------------------- |
| id              | String      | PK, cuid         | Order identifier                                  |
| userId          | String      | FK → User        | Order owner                                       |
| total           | Float       |                  | Order total amount                                |
| status          | OrderStatus | Default: PENDING | PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED |
| shippingAddress | Json?       |                  | Delivery address                                  |
| paymentMethod   | String?     |                  | Payment method used                               |
| createdAt       | DateTime    | Default: now()   | Order placed time                                 |
| updatedAt       | DateTime    | @updatedAt       | Last status update                                |

**Relations**: items (OrderItem[])

### OrderItem

| Column       | Type    | Constraints  | Description                  |
| ------------ | ------- | ------------ | ---------------------------- |
| id           | String  | PK, cuid     | Item identifier              |
| orderId      | String  | FK → Order   | Parent order                 |
| productId    | Int?    | FK → Product | Product reference            |
| productSlug  | String? |              | Product slug for URL linking |
| productName  | String  |              | Product name snapshot        |
| productImage | String? |              | Product image URL snapshot   |
| quantity     | Int     |              | Quantity ordered             |
| price        | Float   |              | Price at time of order       |

### BuyRequest

| Column            | Type             | Constraints      | Description               |
| ----------------- | ---------------- | ---------------- | ------------------------- |
| id                | String           | PK, cuid         | Request identifier        |
| userId            | String           | FK → User        | Requester                 |
| query             | String           |                  | Natural language request  |
| budget            | Float?           |                  | Budget limit              |
| qualityPreference | String?          |                  | Quality preference        |
| autoExecute       | Boolean          | Default: false   | Auto-execute if confident |
| status            | BuyRequestStatus | Default: PENDING | Request status            |
| matchedProducts   | Json?            |                  | AI-matched products       |
| selectedProduct   | Json?            |                  | User-selected product     |

---

## Wallet & Payment System

### Wallet

| Column       | Type    | Constraints       | Description               |
| ------------ | ------- | ----------------- | ------------------------- |
| id           | String  | PK, cuid          | Wallet identifier         |
| userId       | String  | FK → User, Unique | Wallet owner              |
| balance      | Float   | Default: 0        | Current balance           |
| currency     | String  | Default: "INR"    | Currency code             |
| isActive     | Boolean | Default: true     | Wallet active status      |
| dailyLimit   | Float?  |                   | Daily spending limit      |
| monthlyLimit | Float?  |                   | Monthly spending limit    |
| aiAuthorized | Boolean | Default: false    | AI spending authorization |
| aiMaxAmount  | Float?  |                   | Max AI auto-spend amount  |

**Relations**: transactions, authorizations, spendingLimits, auditLogs

### WalletTransaction

| Column      | Type            | Constraints    | Description                         |
| ----------- | --------------- | -------------- | ----------------------------------- |
| id          | String          | PK, cuid       | Transaction ID                      |
| walletId    | String          | FK → Wallet    | Wallet reference                    |
| type        | TransactionType |                | TOPUP, DEBIT, REFUND, HOLD, RELEASE |
| amount      | Float           |                | Transaction amount                  |
| balance     | Float           |                | Balance after transaction           |
| description | String?         |                | Transaction description             |
| reference   | String?         |                | External reference ID               |
| metadata    | Json?           |                | Additional metadata                 |
| createdAt   | DateTime        | Default: now() | Transaction time                    |

### WalletSpendingLimit

| Column       | Type              | Constraints   | Description                       |
| ------------ | ----------------- | ------------- | --------------------------------- |
| id           | String            | PK, cuid      | Limit ID                          |
| walletId     | String            | FK → Wallet   | Wallet reference                  |
| type         | SpendingLimitType |               | DAILY, WEEKLY, MONTHLY, PER_ORDER |
| amount       | Float             |               | Limit amount                      |
| currentSpent | Float             | Default: 0    | Current period spent              |
| resetAt      | DateTime?         |               | Next reset time                   |
| isActive     | Boolean           | Default: true | Limit active                      |

### WalletAuditLog

| Column      | Type    | Constraints | Description            |
| ----------- | ------- | ----------- | ---------------------- |
| id          | String  | PK, cuid    | Log ID                 |
| walletId    | String  | FK → Wallet | Wallet reference       |
| action      | String  |             | Action performed       |
| details     | Json    |             | Action details         |
| performedBy | String  |             | User/system identifier |
| ipAddress   | String? |             | Client IP              |
| userAgent   | String? |             | Client user agent      |

---

## AI & Chat

### ChatMessage

| Column    | Type        | Constraints    | Description             |
| --------- | ----------- | -------------- | ----------------------- |
| id        | String      | PK, cuid       | Message ID              |
| userId    | String      | FK → User      | Message owner           |
| role      | MessageRole |                | USER, ASSISTANT, SYSTEM |
| content   | String      |                | Message content         |
| intent    | String?     |                | Detected intent         |
| keywords  | Json?       |                | Extracted keywords      |
| metadata  | Json?       |                | Additional metadata     |
| createdAt | DateTime    | Default: now() | Sent time               |

### ActivityLog

| Column    | Type         | Constraints    | Description                                |
| --------- | ------------ | -------------- | ------------------------------------------ |
| id        | String       | PK, cuid       | Log ID                                     |
| userId    | String       | FK → User      | User reference                             |
| type      | ActivityType |                | CHAT, PRODUCT_VIEW, PURCHASE, SEARCH, etc. |
| data      | Json?        |                | Activity data                              |
| createdAt | DateTime     | Default: now() | Activity time                              |

### FeatureFlag

| Column            | Type    | Constraints    | Description       |
| ----------------- | ------- | -------------- | ----------------- |
| id                | String  | PK, cuid       | Flag ID           |
| name              | String  | Unique         | Flag name         |
| description       | String? |                | Flag description  |
| isEnabled         | Boolean | Default: false | Global enabled    |
| rolloutPercentage | Float   | Default: 0     | Gradual rollout % |
| targetedUsers     | Json?   |                | Targeted user IDs |

---

## AI Memory System

### UserPreferences

| Column                | Type    | Constraints    | Description          |
| --------------------- | ------- | -------------- | -------------------- |
| id                    | String  | PK, cuid       | Preference ID        |
| userId                | String  | FK → User      | User reference       |
| categories            | Json    |                | Preferred categories |
| priceRange            | Json    |                | Min/max price range  |
| brands                | Json    |                | Preferred brands     |
| autoDecisionEnabled   | Boolean | Default: false | Auto-buy enabled     |
| autoDecisionThreshold | Float   | Default: 0.8   | Confidence threshold |

### UserMemory

| Column     | Type       | Constraints  | Description                   |
| ---------- | ---------- | ------------ | ----------------------------- |
| id         | String     | PK, cuid     | Memory ID                     |
| userId     | String     | FK → User    | User reference                |
| type       | MemoryType |              | PREFERENCE, BEHAVIOR, HISTORY |
| data       | Json       |              | Memory data snapshot          |
| confidence | Float      | Default: 0.5 | Data confidence               |
| expiresAt  | DateTime?  |              | Optional expiry               |

### BuyingPattern

| Column        | Type    | Constraints    | Description        |
| ------------- | ------- | -------------- | ------------------ |
| id            | String  | PK, cuid       | Pattern ID         |
| userId        | String  | FK → User      | User reference     |
| category      | String  |                | Pattern category   |
| frequency     | String  |                | Purchase frequency |
| seasonal      | Boolean | Default: false | Seasonal pattern   |
| priceBehavior | String? |                | Price sensitivity  |
| patterns      | Json?   |                | Detailed patterns  |

### MemoryInsight

| Column     | Type        | Constraints | Description                       |
| ---------- | ----------- | ----------- | --------------------------------- |
| id         | String      | PK, cuid    | Insight ID                        |
| userId     | String      | FK → User   | User reference                    |
| type       | InsightType |             | RECOMMENDATION, TREND, PREDICTION |
| content    | String      |             | Insight text                      |
| confidence | Float       |             | Insight confidence                |
| accuracy   | Float?      |             | Measured accuracy                 |
| metadata   | Json?       |             | Additional data                   |

### RankingPersonalization

| Column      | Type     | Constraints       | Description                  |
| ----------- | -------- | ----------------- | ---------------------------- |
| id          | String   | PK, cuid          | Record ID                    |
| userId      | String   | FK → User, Unique | User reference               |
| weights     | Json     |                   | Personalized ranking weights |
| lastUpdated | DateTime | @updatedAt        | Cache timestamp              |

---

## Agentic Checkout

### ApprovalRequest

| Column      | Type           | Constraints      | Description                          |
| ----------- | -------------- | ---------------- | ------------------------------------ |
| id          | String         | PK, cuid         | Request ID                           |
| userId      | String         | FK → User        | User reference                       |
| orderId     | String?        |                  | Associated order                     |
| amount      | Float          |                  | Request amount                       |
| reason      | String         |                  | AI reason for request                |
| confidence  | Float          |                  | AI confidence level                  |
| status      | ApprovalStatus | Default: PENDING | PENDING, APPROVED, REJECTED, EXPIRED |
| expiresAt   | DateTime       |                  | Approval window expiry               |
| reviewedAt  | DateTime?      |                  | Review timestamp                     |
| reviewNotes | String?        |                  | Reviewer notes                       |

### AIDecisionLog

| Column        | Type    | Constraints | Description            |
| ------------- | ------- | ----------- | ---------------------- |
| id            | String  | PK, cuid    | Log ID                 |
| userId        | String  |             | User reference         |
| action        | String  |             | Decision action        |
| input         | Json    |             | Decision input data    |
| output        | Json    |             | Decision output        |
| confidence    | Float   |             | Decision confidence    |
| traceId       | String? |             | OpenTelemetry trace ID |
| spanId        | String? |             | OpenTelemetry span ID  |
| correlationId | String? |             | Request correlation ID |
| latencyMs     | Int?    |             | Decision latency       |

### AutoDecisionLog

| Column     | Type    | Constraints | Description      |
| ---------- | ------- | ----------- | ---------------- |
| id         | String  | PK, cuid    | Log ID           |
| userId     | String  | FK → User   | User reference   |
| decision   | String  |             | Decision made    |
| confidence | Float   |             | Confidence level |
| outcome    | String? |             | Decision outcome |
| metadata   | Json?   |             | Additional data  |

---

## Direct SQL Tables

These tables are managed via direct SQL in `apps/web/lib/db.ts`:

### "User" (PostgreSQL)

```sql
CREATE TABLE IF NOT EXISTS "User" (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) DEFAULT 'User',
    role VARCHAR(50) DEFAULT 'user',
    "walletBalance" DECIMAL(12,2) DEFAULT 10000.00,
    "createdAt" TIMESTAMP DEFAULT NOW()
);
```

### "Order" (PostgreSQL)

```sql
CREATE TABLE IF NOT EXISTS "Order" (
    id SERIAL PRIMARY KEY,
    "userId" INTEGER REFERENCES "User"(id),
    total DECIMAL(12,2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    "shippingAddress" TEXT,
    "paymentMethod" VARCHAR(50),
    "createdAt" TIMESTAMP DEFAULT NOW()
);
```

### "OrderItem" (PostgreSQL)

```sql
CREATE TABLE IF NOT EXISTS "OrderItem" (
    id SERIAL PRIMARY KEY,
    "orderId" INTEGER REFERENCES "Order"(id),
    "productId" INTEGER,
    "productSlug" TEXT,          -- Added for URL-friendly product linking
    "productName" VARCHAR(255) NOT NULL,
    "productImage" TEXT,
    quantity INTEGER DEFAULT 1,
    price DECIMAL(12,2) NOT NULL
);
```

> **Note**: `productSlug` column added via idempotent migration:
>
> ```sql
> ALTER TABLE "OrderItem" ADD COLUMN IF NOT EXISTS "productSlug" TEXT;
> ```

---

## Indexes & Constraints

### Unique Constraints

- `User.email` — unique
- `Seller.userId` — unique (one seller per user)
- `Cart.userId` — unique (one cart per user)
- `Wallet.userId` — unique (one wallet per user)
- `CartItem.[cartId, productId]` — composite unique
- `SellerProduct.sku` — unique
- `FeatureFlag.name` — unique
- `RankingPersonalization.userId` — unique

### Foreign Key Cascades

- `CartItem` → `Cart` (CASCADE on delete)
- `OrderItem` → `Order` (CASCADE on delete)
- Most other relations use SET NULL or RESTRICT on delete

### Enums

- `UserRole`: USER, SELLER, ADMIN
- `OrderStatus`: PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED
- `TransactionType`: TOPUP, DEBIT, REFUND, HOLD, RELEASE
- `SpendingLimitType`: DAILY, WEEKLY, MONTHLY, PER_ORDER
- `MessageRole`: USER, ASSISTANT, SYSTEM
- `ActivityType`: CHAT, PRODUCT_VIEW, PURCHASE, SEARCH, RECOMMENDATION, etc.
- `MemoryType`: PREFERENCE, BEHAVIOR, HISTORY
- `InsightType`: RECOMMENDATION, TREND, PREDICTION
- `ApprovalStatus`: PENDING, APPROVED, REJECTED, EXPIRED
- `BuyRequestStatus`: PENDING, MATCHING, MATCHED, PURCHASED, CANCELLED

---

_Last updated: 2025-05-30_
