# DelegateCart — Role-Based Access Control (RBAC)

> Documentation of the role-based user system and page-level access controls.

---

## Overview

DelegateCart implements a lightweight role-based access control system for admin and support dashboards. Roles are stored in the `User` table and checked client-side via `lib/admin-auth.ts` and server-side via request header validation.

---

## Roles

| Role | Description | Assigned To |
|------|-------------|-------------|
| `admin` | Full platform access — all admin pages, all API endpoints | admin@delegatecart.com |
| `learning-support` | Self-learning dashboard access only | supervisedLearning@delegatecart.com |
| `observability-support` | Learning dashboard + observability monitoring | observability@delegatecart.com |
| `customer` | Standard user — no admin access | All other users (default) |

---

## Database Schema

```sql
ALTER TABLE "User" ADD COLUMN "role" VARCHAR(50) DEFAULT 'customer';
```

| User | Role | Password |
|------|------|----------|
| admin@delegatecart.com | admin | Admin@DC2024! |
| supervisedLearning@delegatecart.com | learning-support | Admin@DC2024! |
| observability@delegatecart.com | observability-support | Admin@DC2024! |

---

## Access Matrix

| Page Path | admin | learning-support | observability-support | customer |
|-----------|:-----:|:-----------------:|:--------------------:|:--------:|
| `/admin/learning` | ✅ | ✅ | ✅ | ❌ |
| `/observability` | ✅ | ❌ | ✅ | ❌ |
| All other admin | ✅ | ❌ | ❌ | ❌ |
| Public pages | ✅ | ✅ | ✅ | ✅ |

---

## Implementation

### Client-Side Auth (`lib/admin-auth.ts`)

```typescript
// Role → allowed page paths
const ROLE_ACCESS: Record<string, string[]> = {
  admin: ['*'],
  'learning-support': ['/admin/learning'],
  'observability-support': ['/admin/learning', '/observability'],
};

// Check if current user can access a page
export function hasPageAccess(pagePath: string): boolean;

// Check if user is any elevated role
export function isElevatedUser(): boolean;

// Get role from email
export function getUserRole(email: string): string;
```

### Server-Side Auth (API Routes)

```typescript
// apps/web/app/api/admin/learning/route.ts
const LEARNING_EMAILS = [
  'admin@delegatecart.com', 'admin@example.com',
  'supervisedlearning@delegatecart.com',
  'observability@delegatecart.com',
];

function isAdmin(request: NextRequest): boolean {
  const email = request.headers.get('x-user-email') || '';
  return LEARNING_EMAILS.includes(email.toLowerCase());
}
```

### Page-Level Guard

```typescript
// In admin/learning/page.tsx
useEffect(() => {
  setIsAdmin(isAdminUser() || hasPageAccess('/admin/learning'));
  setMounted(true);
}, []);
```

---

## Session Management

### Admin Session Object
```typescript
interface AdminSession {
  email: string;
  isAdmin: boolean;
  role: string;         // NEW: stored role for quick access
  loginTime: number;
  expiresAt: number;    // 8-hour TTL
}
```

Stored in `sessionStorage` under key `dc-admin-session`.

### Login Flow
1. User enters email + password on admin login page
2. `authenticateAdmin(email, password)` validates against `ELEVATED_EMAILS` list
3. Session created with role from `getUserRole(email)`
4. Session stored in `sessionStorage` (auto-expires after 8 hours)
5. `localStorage.userEmail` set for API header injection

---

## Future Enhancements

- Database-driven role assignment (remove hardcoded email lists)
- JWT token with role claims from NestJS API
- Granular permissions (read-only learning, write learning, admin)
- Role management UI for super-admins
