# DelegateCart — Backend API Reference

> **Web API**: Next.js 14 App Router (Edge routes) at port 3000  
> **Backend API**: NestJS (business logic) at port 3001  
> **Database**: PostgreSQL at port 5432

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Authentication](#authentication)
3. [Products API](#products-api)
4. [Shopping & Cart API](#shopping--cart-api)
5. [Orders API](#orders-api)
6. [Wallet & Payments API](#wallet--payments-api)
7. [User Management API](#user-management-api)
8. [AI & Recommendations API](#ai--recommendations-api)
9. [Analytics & Monitoring API](#analytics--monitoring-api)
10. [NestJS Backend Modules](#nestjs-backend-modules)
11. [Error Handling](#error-handling)
12. [Retry & Resilience](#retry--resilience)

---

## Architecture Overview

```
┌──────────────┐    ┌──────────────────────────────┐    ┌───────────────┐
│   Browser     │───▸│  Next.js API Routes (3000)   │───▸│  PostgreSQL   │
│   (React)     │    │  (Edge/Serverless Functions)  │    │  (5432)       │
└──────────────┘    └───────────┬──────────────────┘    └───────────────┘
                                │
                    ┌───────────▼──────────────────┐
                    │  NestJS API (3001)            │
                    │  (Business Logic, Prisma ORM) │
                    │  ┌─────────┐ ┌────────────┐  │
                    │  │ Modules │ │   Kafka    │  │
                    │  └─────────┘ └────────────┘  │
                    └──────────────────────────────┘
```

### Request Flow

1. Browser → Next.js API route
2. Route validates session via `validateSession()`
3. Route attempts NestJS backend (port 3001)
4. Falls back to direct PostgreSQL queries if backend unavailable
5. Mock product catalog serves test data when no real products exist

---

## Authentication

### POST `/api/auth/register`

Register a new user account.

**Request Body:**

```json
{
  "email": "user@example.com",
  "password": "securepassword",
  "name": "John Doe"
}
```

**Response:** `201 Created`

```json
{
  "user": { "id": 1, "email": "user@example.com", "name": "John Doe" },
  "token": "jwt-token-here"
}
```

### POST `/api/auth/login`

Authenticate user and receive session token.

**Request Body:**

```json
{
  "email": "user@example.com",
  "password": "securepassword"
}
```

**Response:** `200 OK`

```json
{
  "user": { "id": 1, "email": "user@example.com", "name": "John Doe", "walletBalance": 10000.0 },
  "token": "jwt-token-here"
}
```

### POST `/api/auth/logout`

Invalidate session.

**Headers:** `Authorization: Bearer <token>`  
**Response:** `200 OK`

### GET `/api/auth/session`

Get current session information.

**Headers:** `Authorization: Bearer <token>`  
**Response:** `200 OK` — Returns user object or `401 Unauthorized`

### GET `/api/magic-link`

Magic link authentication flow.

---

## Products API

### GET `/api/products`

List products with filtering, pagination, and sorting.

**Query Parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page | number | 1 | Page number |
| limit | number | 20 | Items per page |
| search | string | - | Search term |
| category | string | - | Category filter |
| minPrice | number | - | Minimum price |
| maxPrice | number | - | Maximum price |
| sort | string | "relevance" | Sort: relevance, price_asc, price_desc, rating, newest |
| brand | string | - | Brand filter |
| inStock | boolean | - | Stock filter |

**Response:** `200 OK`

```json
{
  "products": [
    {
      "id": "mock-1",
      "name": "Premium Wireless Earbuds",
      "price": 2499,
      "originalPrice": 4999,
      "rating": 4.5,
      "reviews": 1250,
      "image": "https://images.unsplash.com/...",
      "category": "Electronics",
      "brand": "SoundTech",
      "inStock": true,
      "delivery": { "daysMin": 1, "daysMax": 3, "free": true },
      "codAvailable": true,
      "hasEMI": true,
      "trustScore": 92,
      "priceTrend": "down",
      "priceTrendPct": 15,
      "aiRecommended": true,
      "aiConfidence": 88
    }
  ],
  "total": 21000,
  "page": 1,
  "limit": 20,
  "totalPages": 1050
}
```

### GET `/api/products/[id]`

Get single product details.

**Response:** `200 OK`

```json
{
  "product": {
    "id": "mock-1",
    "name": "Premium Wireless Earbuds",
    "description": "Detailed description...",
    "price": 2499,
    "originalPrice": 4999,
    "images": ["url1", "url2", "url3", "url4"],
    "specifications": { "Battery": "30 hours", "Bluetooth": "5.3" },
    "highlights": ["Active noise cancellation", "IPX5 water resistant"],
    "seller": { "name": "SoundTech Official", "rating": 4.7 },
    "reviews": [ { "user": "...", "rating": 5, "comment": "..." } ],
    ...allProductFields
  }
}
```

**Error:** `404` — Product not found

---

## Shopping & Cart API

### GET `/api/shopping-list`

Retrieve user's shopping lists.

**Headers:** `Authorization: Bearer <token>`  
**Response:** `200 OK` — Array of shopping lists

### POST `/api/shopping-list`

Create or process a shopping list with AI product matching.

**Headers:** `Authorization: Bearer <token>`  
**Request Body:**

```json
{
  "items": ["wireless earbuds", "phone case", "laptop stand"],
  "budget": 15000,
  "preferences": { "quality": "premium", "brand": "any" }
}
```

### POST `/api/shopping-assistant`

Rank products with personalization (falls back to main API when shopping service unavailable).

**Request Body:**

```json
{
  "query": "best headphones under 5000",
  "userId": "user-id",
  "context": { "category": "Electronics" }
}
```

### GET `/api/ai-shopping-list`

Get AI-generated shopping list recommendations.

### POST `/api/ai-shopping-list`

Create an AI-powered shopping list from natural language.

---

## Orders API

### GET `/api/orders`

Get all orders for the authenticated user.

**Headers:** `Authorization: Bearer <token>`  
**Response:** `200 OK`

```json
{
  "orders": [
    {
      "id": 1,
      "total": 5998.0,
      "status": "confirmed",
      "createdAt": "2025-05-28T10:30:00Z",
      "items": [
        {
          "id": 1,
          "productId": null,
          "productSlug": "mock-5",
          "productName": "Wireless Earbuds",
          "productImage": "https://...",
          "quantity": 2,
          "price": 2999.0
        }
      ]
    }
  ]
}
```

### POST `/api/orders`

Create a new order.

**Headers:** `Authorization: Bearer <token>`  
**Request Body:**

```json
{
  "items": [
    {
      "productId": 5,
      "productSlug": "mock-5",
      "productName": "Wireless Earbuds",
      "productImage": "https://...",
      "quantity": 2,
      "price": 2999.0
    }
  ],
  "shippingAddress": "123 Main St, City 12345",
  "paymentMethod": "wallet",
  "total": 5998.0
}
```

**Response:** `201 Created`

```json
{
  "orderId": 15,
  "status": "confirmed",
  "total": 5998.0
}
```

### GET `/api/orders/[id]`

Get order details by ID.

**Headers:** `Authorization: Bearer <token>`  
**Response:** `200 OK` — Full order with items, status, timestamps

---

## Wallet & Payments API

### GET `/api/wallet`

Get wallet balance and recent transactions.

**Headers:** `Authorization: Bearer <token>`  
**Response:** `200 OK`

```json
{
  "balance": 10000.0,
  "currency": "INR",
  "transactions": [
    {
      "id": 1,
      "type": "topup",
      "amount": 5000.0,
      "description": "Initial balance",
      "createdAt": "2025-05-28T09:00:00Z"
    }
  ]
}
```

### POST `/api/wallet`

Manage wallet operations.

**Request Body (Add Funds):**

```json
{
  "action": "topup",
  "amount": 5000.0
}
```

**Request Body (Debit/Purchase):**

```json
{
  "action": "debit",
  "amount": 2999.0,
  "description": "Order #15"
}
```

### GET `/api/wallet/transactions`

Get paginated wallet transaction history.

**Query Parameters:** `page`, `limit`, `type` (filter by transaction type)

---

## User Management API

### GET `/api/user/profile`

Get authenticated user profile.

### PUT `/api/user/profile`

Update user profile (name, phone, avatar).

### GET `/api/user/preferences`

Get user's AI and shopping preferences.

### PUT `/api/user/preferences`

Update preferences.

```json
{
  "categories": ["Electronics", "Fashion"],
  "priceRange": { "min": 500, "max": 50000 },
  "brands": ["Sony", "Samsung"],
  "autoDecisionEnabled": true,
  "autoDecisionThreshold": 0.85
}
```

### POST `/api/user/addresses`

Add a new delivery address.

### GET `/api/user/addresses`

Get all saved addresses.

### PUT `/api/user/addresses`

Update an existing address.

### DELETE `/api/user/addresses`

Delete an address.

### GET `/api/user/wishlist`

Get wishlist items.

### POST `/api/user/wishlist`

Add product to wishlist.

### DELETE `/api/user/wishlist`

Remove product from wishlist.

### POST `/api/user/behavior`

Track user behavior event.

```json
{
  "type": "product_view",
  "data": { "productId": "mock-5", "category": "Electronics", "duration": 45 }
}
```

### GET `/api/user/behavior`

Get behavior statistics and patterns.

### GET `/api/user/search-history`

Get user's search history.

---

## AI & Recommendations API

### POST `/api/intent/analyze`

Analyze user intent from natural language input.

**Request Body:**

```json
{
  "text": "I need headphones for running under 3000",
  "context": { "previousMessages": [] }
}
```

**Response:**

```json
{
  "intent": "product_search",
  "entities": { "category": "headphones", "use_case": "running", "maxPrice": 3000 },
  "confidence": 0.92,
  "suggestedAction": "search_products"
}
```

### POST `/api/intent/answer-question`

Answer user questions with product recommendations.

### POST `/api/chat/message`

Send a chat message to the AI assistant. Tracks behavior, scores products, generates AI response.

**Headers:** `Authorization: Bearer <token>`  
**Request Body:**

```json
{
  "message": "Find me the best laptop under 50000",
  "conversationId": "conv-123"
}
```

**Response:**

```json
{
  "reply": "Based on your preferences, here are the top laptops...",
  "products": [...],
  "intent": "product_search",
  "confidence": 0.95
}
```

### POST `/api/chat/stream`

Stream chat responses for real-time display.

---

## Analytics & Monitoring API

### GET `/api/analytics`

Get analytics data (admin).

### POST `/api/analytics`

Track analytics events.

### GET `/api/feature-flags`

Get feature flags for the current user.

### GET `/api/checkout-failures`

Get checkout failure data for debugging.

---

## NestJS Backend Modules

The NestJS backend (`apps/api/`) provides the core business logic:

| Module            | Description                              |
| ----------------- | ---------------------------------------- |
| `auth/`           | JWT authentication, session management   |
| `orders/`         | Order lifecycle, status management       |
| `payments/`       | Payment processing, Razorpay integration |
| `checkout/`       | Checkout workflow orchestration          |
| `shopping/`       | Shopping service, product search         |
| `product/`        | Product CRUD, catalog management         |
| `wallet/`         | Wallet balance, transactions, limits     |
| `cart/`           | Cart management                          |
| `buy-request/`    | AI buy request handling                  |
| `ai-memory/`      | User memory, preferences, patterns       |
| `ai-execution/`   | AI decision execution engine             |
| `ai-chat/`        | AI chat processing, intent analysis      |
| `seller-copilot/` | Seller AI assistance tools               |
| `feature-flag/`   | Feature flag management                  |
| `acp/`            | Agentic Checkout Protocol                |
| `addresses/`      | Address management                       |
| `websocket/`      | Real-time WebSocket connections          |
| `kafka/`          | Kafka event streaming                    |

---

## Error Handling

### Standard Error Response Format

```json
{
  "statusCode": 400,
  "code": "VALIDATION_FAILED",
  "message": "Validation failed",
  "timestamp": "2025-05-28T10:30:00.000Z",
  "path": "/api/products",
  "method": "GET"
}
```

### Error Codes

| Code             | HTTP | Description                    |
| ---------------- | ---- | ------------------------------ |
| NETWORK_ERROR    | -    | Network connectivity issue     |
| UNAUTHORIZED     | 401  | Invalid/missing authentication |
| FORBIDDEN        | 403  | Insufficient permissions       |
| NOT_FOUND        | 404  | Resource not found             |
| RATE_LIMITED     | 429  | Too many requests              |
| VALIDATION_ERROR | 400  | Input validation failed        |
| SERVER_ERROR     | 500  | Internal server error          |
| OUT_OF_STOCK     | 422  | Product out of stock           |

### Authentication Errors

- `401` — Missing or invalid Bearer token
- `403` — Valid token but insufficient role
- Token passed via `Authorization: Bearer <token>` header or `auth_token` cookie

---

## Retry & Resilience

### Exponential Backoff with Jitter

All critical API calls use retry with exponential backoff:

```
delay = min(baseMs × 2^attempt + random(0, baseMs), 10000ms)
```

**Configuration** (`lib/safe-api.ts`):

- Default retries: 2
- Base delay: 1000ms
- Max delay cap: 10000ms
- No retry on 4xx errors (client errors)
- Retry on 5xx errors and network failures

### Fallback Chain

```
Shopping Service (3001) → Main API → Mock Data → Error
```

### Debounce

- Search input: 350ms debounce via `useDebounce` hook
- Prevents excessive API calls during typing

---

_Last updated: 2025-05-30_
