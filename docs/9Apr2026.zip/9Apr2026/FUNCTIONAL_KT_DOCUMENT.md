# DelegateCart — Functional Knowledge Transfer (KT) Document

## Document Metadata

| Field            | Value                                                   |
| ---------------- | ------------------------------------------------------- |
| **Version**      | 2.0                                                     |
| **Last Updated** | April 2026                                              |
| **Audience**     | Product Managers, QA, Business Analysts, New Developers |
| **Platform**     | AI-Powered E-Commerce                                   |

---

## 1. Product Overview

**DelegateCart** is an AI-powered e-commerce platform that acts as a personal shopping assistant. Instead of manually browsing hundreds of products, users **delegate** their shopping needs to AI, which searches, compares, scores, and optionally auto-purchases the best products.

### Core Value Proposition

1. **AI-Assisted Shopping**: Natural language chat to find products
2. **Multi-Source Search**: Searches internal catalog + Amazon + Flipkart simultaneously
3. **Intelligent Scoring**: 5-factor AI scoring rates every product 0-100
4. **Auto-Checkout**: Configurable rules for autonomous purchasing
5. **Smart Notifications**: WhatsApp + Email alerts for search results and orders
6. **Budget Intelligence**: Spending tracking, budget limits, purchase predictions

---

## 2. User Roles

| Role       | Description                         | Key Pages                                           |
| ---------- | ----------------------------------- | --------------------------------------------------- |
| **Buyer**  | Primary consumer who shops products | Shopping List, Cart, Checkout, Orders, AI Assistant |
| **Seller** | Merchant listing products           | Seller Dashboard, Create Listing, Seller Profile    |
| **Admin**  | Platform administrator              | Admin Dashboard, Analytics                          |

---

## 3. Functional Modules

### 3.1 Shopping List (Multi-Item AI Search)

**Page**: `/shopping-list`

**What it does**: Users create a list of products they want to buy. Each item can specify product name, brand preference, budget, quantity, delivery timeframe, payment method, and EMI preference. The AI searches all sources simultaneously.

**Fields per item**:
| Field | Required | Validation |
|-------|----------|------------|
| Product Name | Yes | Alphanumeric, 1-100 chars |
| Brand | No | Alphanumeric |
| Budget (₹) | No | Numeric > 0 |
| Quantity | Yes | Min 1, Max 99 |
| Delivery Days | No | Numeric |
| Payment Method | No | UPI, Card, COD, EMI |
| EMI Only | No | Boolean |

**Process**:

1. User fills items → clicks "Search All Items"
2. System checks cache (5-hour TTL) for identical searches
3. If fresh, AI searches internal DB + external sources
4. Results are scored by 5-factor AI engine
5. Results saved to localStorage and displayed
6. If WhatsApp number configured, sends results via WhatsApp
7. If auto-checkout enabled and price under threshold → auto-purchases

### 3.2 AI Assistant Chat

**Page**: `/ai-assistant/chat`

**What it does**: A conversational shopping interface. Users describe what they want in natural language, and the AI responds with product recommendations, comparisons, and shopping advice.

**Capabilities**:

- **Product Discovery**: "Find me a laptop under ₹80,000"
- **Comparison**: "Compare Samsung S24 vs iPhone 15"
- **Recommendations**: "Best headphones for music"
- **Budget Advice**: "Affordable watches under ₹5,000"
- **Category Expertise**: 13+ product categories (laptops, phones, headphones, TVs, cameras, watches, speakers, tablets, stationery, washing machines, refrigerators, ACs, etc.)

**Each product recommendation shows**:

- Name, brand, price
- Star rating
- AI confidence score (0-100%)
- Why AI recommended it
- COD/EMI availability
- Link to purchase

### 3.3 Smart Delegate (AI Results Viewer)

**Page**: `/smart-delegate`

**What it does**: Displays all previous shopping list search results with full AI scoring breakdown. Think of it as a "search history with intelligence".

**Each result card shows**:

- Submission date/time
- Product matches per searched item
- **AI Score** (0-100) — composite of five factors
- **Score Breakdown**: Relevance, Preference Match, Price Fit, Rating, Confidence
- **AI Explanation**: Human-readable reason for the score
- Source badge: INTERNAL (our catalog) vs EXTERNAL (Amazon/Flipkart)
- Add to Cart button

**Requires**: Authentication (redirects to sign-in if not logged in)

### 3.4 Cart (Dual-Source System)

**Page**: `/cart`

**What it does**: Shopping cart with a unique split between INTERNAL and EXTERNAL products.

**INTERNAL products** (from our catalog):

- Full checkout support
- Quantity management (+/- buttons)
- Tax calculation (18% GST)
- Can proceed to checkout

**EXTERNAL products** (from Amazon/Flipkart):

- Displayed with "External" badge and warning banner
- **Cannot be checked out** on DelegateCart
- User must click external URL to buy on original site
- If cart has ONLY external items → checkout button is disabled

**Cart calculations**:

- Subtotal = sum(price × quantity) for INTERNAL items only
- Tax = 18% GST (rounded to nearest paisa)
- Total = Subtotal + Tax + Shipping

### 3.5 Checkout (4-Step Flow)

**Page**: `/checkout`

**Step 1 — Address**:

- Loads saved addresses from API
- Auto-selects user's default shipping address
- "Add New Address" form with validation (pincode: 6 digits, phone: 10 digits)

**Step 2 — Shipping**:

- Standard: 5-7 days, Free
- Express: 2-3 days, ₹99
- Overnight: Next day, ₹299

**Step 3 — Payment**:

- UPI / PhonePe / GPay
- Credit / Debit Card (number, expiry, CVV, name)
- Net Banking (bank selection)
- Cash on Delivery
- EMI (3/6/12 month tenure selection)

**Step 4 — Review & Place Order**:

- Summary of cart items, address, shipping, payment totals
- "Place Order" button → saves to localStorage immediately + async DB write
- Success confirmation with order number (ORD-XXXXXXXX)

### 3.6 User Profile & Preferences

**Page**: `/profile`

**Four grouped sections**:

1. **Personal Information**: Display name, alias name, email, phone, avatar
2. **Communication**: WhatsApp number, notification email, notification preferences (email/WhatsApp/push toggles)
3. **Addresses**: Full CRUD — add, edit, delete, set default
4. **AI & Subscription**:
   - Subscription Plan: Basic (GPT-4o Mini) or AI Plus (GPT-4o)
   - AI Model selection
   - Auto-purchase toggle + threshold (₹)

### 3.7 Analytics Dashboard

**Page**: `/admin/analytics`

**Metrics displayed**:

- Total events, unique users, add-to-cart count
- Purchase count, search count
- Conversion rate (purchases / cart adds)
- AI recommendation success rate

**Visualizations (Recharts)**:

- Daily trend line chart
- Top products bar chart
- AI stats (recommendations, accepted, rejected)
- Time range selector (7/30/90/365 days)

### 3.8 Products & Orders

**Browse Products** (`/products`): Catalog with search, filters, pagination
**Product Detail** (`/products/[id]`): Full product page with images, specs, reviews
**Order History** (`/orders`): List of all placed orders with status
**Order Detail** (`/orders/[id]`): Individual order tracking, items, status timeline

### 3.9 Seller Portal

**Dashboard** (`/sellers/dashboard`): Sales overview, revenue, order count
**Create Listing** (`/sellers/create-listing`): Add product to catalog
**Seller Profile** (`/sellers/profile`): Business settings

### 3.10 Additional Features

| Feature            | Page                  | Description                                             |
| ------------------ | --------------------- | ------------------------------------------------------- |
| Budget Tracker     | `/budget-tracker`     | Set monthly spending limits, track progress             |
| Price Alerts       | `/price-alerts`       | Get notified when products hit target price             |
| Purchase Predictor | `/purchase-predictor` | ML-based prediction of when user will need to buy again |
| Wishlist           | `/wishlist`           | Save products for later                                 |
| Spending Insights  | `/spending`           | Charts showing spending trends by category              |
| Order Insights     | `/order-insights`     | Analysis of ordering patterns                           |
| AI Memory          | `/memory`             | View/manage AI's learned preferences about you          |

---

## 4. User Journeys

### Journey 1: First-Time Shopping List Search

```
User visits /shopping-list
    → Adds items (e.g., "Laptop, budget ₹80K" + "Mouse, budget ₹2K")
    → Clicks "Search All Items"
    → Loading spinner while AI searches
    → Results appear with AI scores
    → User clicks "Add to Cart" on top-scored items
    → Navigates to /cart
    → Sees items with prices + AI badges
    → Clicks "Proceed to Checkout"
    → Selects address → shipping → payment → reviews
    → Places order
    → Gets order confirmation with ORD-number
```

### Journey 2: AI Chat Shopping

```
User visits /ai-assistant/chat
    → Types "Find me wireless headphones under 5000"
    → AI responds with 4+ recommendations
    → Each has confidence score + explanation
    → User asks "Compare Sony vs Apple"
    → AI gives side-by-side comparison
    → User says "Add Sony to cart"
    → Product added to cart
    → User proceeds to checkout
```

### Journey 3: Returning User — Auto-Checkout

```
User configures auto-purchase on /profile:
    - Enabled: true
    - Threshold: ₹5,000
    → Submits shopping list with budget under ₹5K
    → System finds best match under budget
    → Auto-checkout triggered
    → Order placed without manual checkout
    → WhatsApp notification sent with order details
```

### Journey 4: Review Previous AI Results

```
User visits /smart-delegate (requires login)
    → Sees list of all previous shopping list submissions
    → Expands a submission to see product matches
    → Each product shows:
        - AI Score: 87/100
        - Breakdown: Relevance 85, Preference 70, Price 100...
        - Explanation: "High relevance to washing machine..."
    → Clicks "Add to Cart" on any product
    → Item appears in cart with source badge
```

---

## 5. Notification System

### 5.1 WhatsApp Notifications

**Trigger**: After shopping list search completes
**Content**: Search results summary with top matches, prices, AI scores
**Setup**: User enters WhatsApp number in Profile → Communication section

### 5.2 Email Notifications

**Trigger**: Order confirmation, search results, price alerts
**Content**: Formatted HTML email with order/product details
**Setup**: User configures notification email in Profile

### 5.3 Push Notifications

**Trigger**: Order status updates, price drops
**Setup**: Toggle in Profile → Communication → Push notifications

---

## 6. Business Rules

### 6.1 Pricing

| Rule          | Description                                                 |
| ------------- | ----------------------------------------------------------- |
| GST           | 18% on all products (India)                                 |
| Tax Precision | Rounded to nearest paisa: `Math.round(subtotal * 18) / 100` |
| Shipping      | Standard: Free, Express: ₹99, Overnight: ₹299               |
| EMI           | No-cost EMI available for products > ₹10,000                |

### 6.2 Cart Rules

| Rule              | Description                                      |
| ----------------- | ------------------------------------------------ |
| External products | Cannot be checked out; must buy on original site |
| Cart max          | No hard limit; localStorage constrained (~5MB)   |
| Results cache     | Max 20 shopping list results stored              |
| Search cache      | 5-hour TTL for identical searches                |

### 6.3 Auto-Purchase Rules

| Rule      | Description                                          |
| --------- | ---------------------------------------------------- |
| Threshold | User-configurable max amount (default ₹5,000)        |
| Enable    | Must be explicitly turned on in Profile              |
| Scoring   | Only auto-purchases top-scored items (AI score > 80) |
| Safety    | Won't exceed daily/monthly spend limits              |

### 6.4 AI Scoring Thresholds

| Score Range | Label         | Meaning                             |
| ----------- | ------------- | ----------------------------------- |
| 90-100      | Excellent     | Near-perfect match for user's needs |
| 70-89       | Good          | Strong match, minor trade-offs      |
| 50-69       | Fair          | Decent option, some compromises     |
| 30-49       | Below Average | Significant gaps                    |
| 0-29        | Poor          | Not recommended                     |

---

## 7. Data Flow Summary

```
User Input → Shopping List / Chat / Browse
     ↓
API Layer (validation, auth, caching)
     ↓
AI Services (intent parsing, product search, ranking)
     ↓
Scoring Engine (5-factor weighted algorithm)
     ↓
Ranked Results → Frontend Display
     ↓
User Action: Add to Cart / Auto-Checkout
     ↓
Cart → Checkout (4-step) → Order
     ↓
Notifications (WhatsApp / Email)
```

---

## 8. Test Coverage Summary

**43 E2E tests** validate every major feature:

- ✅ Profile page loads all 4 sections with correct fields
- ✅ Address management (add, cancel, form fields)
- ✅ All API routes respond correctly (auth, CRUD)
- ✅ Shopping list AI scoring fields present
- ✅ Cart external product handling (badge, warning, disabled checkout)
- ✅ Checkout address loading and empty states
- ✅ Analytics dashboard metrics and charts
- ✅ Chat API responds with product recommendations
- ✅ Smart delegate page loads and displays AI scores

**All 43 tests passing** — 0 failures, 0 flaky tests.
