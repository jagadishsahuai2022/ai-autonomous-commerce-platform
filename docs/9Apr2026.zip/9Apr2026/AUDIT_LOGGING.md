# DelegateCart — Audit, Logging & Compliance Documentation

## Document Metadata

| Field            | Value                                                                      |
| ---------------- | -------------------------------------------------------------------------- |
| **Version**      | 1.0                                                                        |
| **Last Updated** | April 2026                                                                 |
| **Scope**        | Audit trails, logging architecture, compliance mechanisms, data governance |

---

## 1. Audit Architecture Overview

DelegateCart maintains comprehensive audit trails across three layers:

```
┌─────────────────────────────────────────────────┐
│              AUDIT LAYERS                        │
│                                                   │
│  Layer 1: Transaction Audit (Financial)           │
│  └── WalletTransaction, WalletAuditLog           │
│                                                   │
│  Layer 2: AI Decision Audit (Intelligence)        │
│  └── AIDecisionLog, AutoDecisionLog              │
│                                                   │
│  Layer 3: User Activity Audit (Behavioral)        │
│  └── ActivityLog, UserMemoryInteraction          │
└─────────────────────────────────────────────────┘
```

---

## 2. Financial Audit Trail

### 2.1 Wallet Transaction Log

Every wallet operation creates an immutable transaction record:

```prisma
model WalletTransaction {
  id              String   @id @default(uuid())
  walletId        String
  type            String          // topup | debit | refund | hold | release
  amount          Float
  status          String          // pending | completed | failed | reversed
  description     String?
  referenceId     String?         // External order/payment ID
  idempotencyKey  String? @unique // Prevents duplicate processing
  balanceBefore   Float
  balanceAfter    Float
  metadata        Json?           // Additional context
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt
}
```

**Audit Guarantees:**

- `balanceBefore` and `balanceAfter` recorded on every transaction
- `idempotencyKey` prevents duplicate charges (unique constraint)
- `status` transitions are logged (pending → completed/failed)
- Failed debits trigger automatic refund with linked `referenceId`

### 2.2 Wallet Audit Log

Detailed change tracking for wallet state modifications:

```prisma
model WalletAuditLog {
  id            String   @id @default(uuid())
  walletId      String
  action        String          // settings_changed | limit_updated | ai_auth_toggled
  performer     String          // 'user' | 'ai' | 'system' | 'admin'
  changesBefore Json            // Snapshot before change
  changesAfter  Json            // Snapshot after change
  ipAddress     String?
  userAgent     String?
  createdAt     DateTime @default(now())
}
```

**Tracked Actions:**
| Action | Trigger | Performer |
|--------|---------|-----------|
| `balance_topup` | User adds funds | user |
| `balance_debit` | Purchase payment | user/ai |
| `balance_refund` | Failed order refund | system |
| `settings_changed` | Wallet settings update | user |
| `limit_updated` | Spending limit change | user |
| `ai_auth_toggled` | AI authorization enabled/disabled | user |
| `wallet_locked` | Security lockout | system/admin |

---

## 3. AI Decision Audit Trail

### 3.1 AI Decision Log

Every AI-initiated action is recorded with full context:

```prisma
model AIDecisionLog {
  id           String   @id @default(uuid())
  userId       String
  traceId      String          // OpenTelemetry trace ID for distributed tracing
  decisionType String          // auto_purchase | approval_request | recommendation
  input        Json            // Full input context (buy request, preferences, products)
  output       Json            // Decision result (product selected, action taken)
  confidence   Float           // 0.0-1.0 confidence score
  reasoning    String          // Human-readable explanation
  successful   Boolean?        // Post-execution outcome
  executionMs  Int?            // Total decision time in milliseconds
  createdAt    DateTime @default(now())
}
```

### 3.2 Auto-Decision Log

Tracks autonomous AI decisions for pattern analysis:

```prisma
model AutoDecisionLog {
  id           String   @id @default(uuid())
  userId       String
  decisionType String          // auto_purchase | cart_suggestion | price_alert | reorder
  decision     String          // The specific action taken
  confidence   Float
  successful   Boolean?
  input        Json            // Context that triggered the decision
  output       Json            // Result of the decision
  createdAt    DateTime @default(now())
}
```

### 3.3 Memory Interaction Log

Tracks how AI memory influenced decisions:

```prisma
model UserMemoryInteraction {
  id               String   @id @default(uuid())
  userMemoryId     String
  interactionType  String          // search | recommendation | auto_decision
  confidence       Float
  userFeedback     String?         // positive | negative | neutral
  wasSuccessful    Boolean
  createdAt        DateTime @default(now())
}
```

---

## 4. User Activity Logging

### 4.1 Activity Log

General-purpose event tracking:

```prisma
model ActivityLog {
  id        String   @id @default(uuid())
  userId    String?
  action    String          // page_view | product_click | add_to_cart | search | purchase
  metadata  Json?           // Event-specific data
  createdAt DateTime @default(now())
}
```

### 4.2 Kafka Event Tracking

All user actions are published to Kafka for async processing:

| Topic             | Event Types                                                                                                     |
| ----------------- | --------------------------------------------------------------------------------------------------------------- |
| `user-behavior`   | `user.registered`, `user.updated`                                                                               |
| `product-events`  | `product.viewed`, `product.created`, `product.updated`                                                          |
| `commerce-events` | `cart.item_added`, `cart.item_removed`, `cart.abandoned`, `order.created`, `order.completed`, `order.cancelled` |
| `analytics`       | Aggregated metrics, funnel events                                                                               |

### 4.3 Frontend Event Tracking

```typescript
// apps/web/app/api/track/event/route.ts
POST /api/track/event
{
  "event": "product_view",
  "properties": {
    "productId": "...",
    "source": "search" | "recommendation" | "direct",
    "timestamp": "ISO8601"
  }
}
```

---

## 5. Logging Architecture

### 5.1 Service Logging

| Service          | Logger                  | Format | Destination     |
| ---------------- | ----------------------- | ------ | --------------- |
| Web (Next.js)    | `console` + custom      | JSON   | stdout → Docker |
| API (NestJS)     | NestJS Logger           | JSON   | stdout → Docker |
| AI Service       | Python `logging`        | JSON   | stdout → Docker |
| Intent Parser    | Python `logging` + Pino | JSON   | stdout → Docker |
| Autopilot Engine | Pino                    | JSON   | stdout → Docker |

### 5.2 Log Levels

| Level   | Usage                                     |
| ------- | ----------------------------------------- |
| `error` | Unrecoverable failures, exceptions        |
| `warn`  | Degraded performance, fallback activated  |
| `info`  | Business events, API calls, state changes |
| `debug` | Detailed execution flow (dev only)        |

### 5.3 Structured Log Format

```json
{
  "timestamp": "2026-04-15T10:30:00.000Z",
  "level": "info",
  "service": "api",
  "traceId": "abc123...",
  "message": "Order created",
  "metadata": {
    "userId": "usr_...",
    "orderId": "ord_...",
    "amount": 2499.0,
    "paymentMethod": "wallet"
  }
}
```

---

## 6. Compliance Considerations

### 6.1 Data Retention

| Data Type           | Retention              | Reason                        |
| ------------------- | ---------------------- | ----------------------------- |
| Wallet transactions | Indefinite             | Financial compliance          |
| AI decision logs    | 2 years                | Audit + model improvement     |
| Activity logs       | 1 year                 | Analytics + behavior analysis |
| Chat messages       | 6 months               | Context + support             |
| User preferences    | Until account deletion | Personalization               |

### 6.2 Data Privacy

| Requirement     | Implementation                                          |
| --------------- | ------------------------------------------------------- |
| User consent    | Explicit opt-in for AI features                         |
| Data access     | `/api/user/profile` returns all user data               |
| Data deletion   | Account deletion cascades to all linked records         |
| Anonymization   | Activity logs retain behavior without PII for analytics |
| AI transparency | Every AI decision includes human-readable `reasoning`   |

### 6.3 Security Audit Points

| Checkpoint        | Mechanism                                               |
| ----------------- | ------------------------------------------------------- |
| Authentication    | JWT token validation on every API call                  |
| Authorization     | Role-based access (buyer/seller/admin)                  |
| Admin access      | Email whitelist + password + session expiry (8h)        |
| Wallet operations | Idempotency keys + spending limits + balance validation |
| AI spending       | Wallet.isAiAuthorized flag + aiSpendingLimit cap        |
| Data encryption   | HTTPS in transit, passwords hashed (bcrypt)             |
