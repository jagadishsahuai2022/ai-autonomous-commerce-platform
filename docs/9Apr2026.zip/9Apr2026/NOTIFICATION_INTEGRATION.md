# DelegateCart — Notification & Communication Integration

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Last Updated** | April 2026 |
| **Scope** | Multi-channel notifications, API integrations, notification workflows |

---

## 1. Overview

DelegateCart implements a multi-channel notification system that keeps users informed about:
- Order status changes (confirmed, shipped, delivered, failed)
- AI search results and product recommendations
- Approval requests for agentic checkout
- Price alerts and reorder suggestions
- Wallet transactions and balance updates

### Channels

| Channel | Provider | Status | Use Cases |
|---------|----------|--------|-----------|
| **In-App Toast** | react-hot-toast | Active | All real-time notifications |
| **Email** | SendGrid API | Configured | Order confirmations, receipts |
| **WhatsApp** | Twilio API | Configured | Search results, approval requests |
| **Push** | Web Push API | Planned | Price alerts, delivery updates |
| **WebSocket** | Socket.io | Active | Live updates (order status, chat) |

---

## 2. Notification Service Architecture

### 2.1 Service Module (notifications.ts)

```typescript
// apps/web/lib/notifications.ts (157 lines)

interface NotificationPayload {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, any>;
  channels: Channel[];
}

type NotificationType =
  | 'order_confirmed'
  | 'order_failed'
  | 'order_shipped'
  | 'search_results'
  | 'approval_required'
  | 'price_alert'
  | 'wallet_transaction'
  | 'reorder_suggestion';

type Channel = 'toast' | 'email' | 'whatsapp' | 'push' | 'websocket';
```

### 2.2 Notification Functions

```typescript
// Order lifecycle
sendOrderConfirmation(userId, orderId): Promise<void>
  → Channels: toast + email + whatsapp

notifyOrderFailed(userId, orderId, reason): Promise<void>
  → Channels: toast + email
  → Triggers: Auto-refund workflow

sendOrderShipped(userId, orderId, trackingUrl): Promise<void>
  → Channels: toast + email + whatsapp + push

// AI features
sendSearchResults(userId, products[]): Promise<void>
  → Channels: toast + whatsapp (if AI search)

sendApprovalRequest(userId, approvalId): Promise<void>
  → Channels: toast + email + whatsapp + push
  → Contains: Approve/Reject deep links

// Wallet
sendWalletNotification(userId, txType, amount): Promise<void>
  → Channels: toast + email (for large amounts)

// Price alerts
sendPriceAlert(userId, productId, oldPrice, newPrice): Promise<void>
  → Channels: toast + push + email
```

---

## 3. API Integration Details

### 3.1 SendGrid (Email)

```
Endpoint: https://api.sendgrid.com/v3/mail/send
Auth: Bearer API_KEY
Method: POST

Environment Variables:
  SENDGRID_API_KEY          # API key for authentication
  SENDGRID_FROM_EMAIL       # Sender email (noreply@delegatecart.com)
  SENDGRID_FROM_NAME        # Sender name ("DelegateCart AI")

Templates:
  - Order Confirmation (dynamic template with order details)
  - Order Failed (includes refund info)
  - Search Results (product cards with images)
  - Approval Request (approve/reject buttons)
  - Wallet Receipt (transaction details)
```

### 3.2 Twilio WhatsApp

```
Endpoint: https://api.twilio.com/2010-04-01/Accounts/{SID}/Messages.json
Auth: Basic (Account SID : Auth Token)
Method: POST

Environment Variables:
  TWILIO_ACCOUNT_SID        # Twilio account identifier
  TWILIO_AUTH_TOKEN          # Authentication token
  TWILIO_WHATSAPP_FROM      # WhatsApp sender number (whatsapp:+14155238886)

Message Format:
  To: whatsapp:+91{userPhone}
  From: whatsapp:+14155238886
  Body: Template-based messages

Templates:
  - "🛒 Your order #{orderId} has been confirmed! Total: ₹{amount}"
  - "🔍 AI found {count} products for '{query}'. Best match: {productName} at ₹{price}"
  - "⚠️ Approval needed: AI wants to purchase {product} for ₹{price}. Reply YES/NO"
```

### 3.3 WebSocket (Real-time)

```typescript
// apps/api/src/modules/product/product.gateway.ts
@WebSocketGateway({ cors: true })
export class ProductGateway {
  @WebSocketServer() server: Server;

  // Events emitted to clients:
  emitOrderUpdate(userId: string, order: Order)     // 'order:update'
  emitChatMessage(userId: string, message: Message)  // 'chat:message'
  emitApproval(userId: string, approval: Approval)   // 'approval:new'
  emitPriceChange(productId: string, price: number)  // 'price:change'
}

// Frontend consumption (Socket.io client):
const socket = io(NEXT_PUBLIC_API_URL);
socket.on('order:update', (data) => { /* update UI */ });
socket.on('approval:new', (data) => { /* show approval panel */ });
```

---

## 4. Notification Workflows

### 4.1 Order Confirmation

```
Order created successfully
  │
  ├── In-app toast: "Order #{id} confirmed! ₹{amount}"
  ├── Email (SendGrid): Order confirmation template
  ├── WhatsApp (Twilio): Order summary message
  └── WebSocket: Real-time order status update
```

### 4.2 Order Failed

```
Order/checkout fails
  │
  ├── notifyOrderFailed(userId, orderId, reason)
  │     ├── In-app toast (error): "Order failed: {reason}"
  │     └── Email: Failure notification + refund details
  │
  ├── wallet-transactions.executeRefund(originalTxId)
  │     └── Automatic wallet refund
  │
  └── WebSocket: Real-time failure notification
```

### 4.3 AI Approval Required

```
AI creates ApprovalRequest (high-value or low confidence)
  │
  ├── sendApprovalRequest(userId, approvalId)
  │     ├── In-app toast: "AI needs your approval for ₹{amount} purchase"
  │     ├── Email: Detailed product info + approve/reject links
  │     ├── WhatsApp: Quick summary + reply YES/NO
  │     └── Push: "Approval needed — ₹{amount}"
  │
  └── Timer: 24 hours
        │
        └── If not resolved → Auto-expire + notify + release hold
```

### 4.4 Shopping List Search Results

```
AI completes product search for shopping list item
  │
  ├── sendSearchResults(userId, rankedProducts)
  │     ├── In-app: Product cards in shopping-assistant UI
  │     ├── WhatsApp: Top 3 products with prices
  │     └── Email: Full results with comparison table
  │
  └── If autoCheckout enabled → Skip notification, proceed to purchase
```

---

## 5. API Keys Required for Production

| Service | Key Name | Purpose | Required |
|---------|----------|---------|----------|
| **SendGrid** | `SENDGRID_API_KEY` | Email delivery | Yes (production) |
| **Twilio** | `TWILIO_ACCOUNT_SID` | WhatsApp sender ID | Yes (production) |
| **Twilio** | `TWILIO_AUTH_TOKEN` | WhatsApp auth | Yes (production) |
| **OpenAI** | `OPENAI_API_KEY` | GPT-4 intent parsing | Yes (AI features) |
| **Anthropic** | `ANTHROPIC_API_KEY` | Claude 3 fallback LLM | Optional (failover) |
| **Razorpay** | `RAZORPAY_KEY_ID` | Payment gateway | Yes (real payments) |
| **Razorpay** | `RAZORPAY_KEY_SECRET` | Payment auth | Yes (real payments) |

### Demo/Development Mode
- **Mock payment**: `NEXT_PUBLIC_ENABLE_MOCK_PAYMENT=true` — no real charges
- **LLM fallback**: Uses hardcoded intent extraction when no API key
- **Email/WhatsApp**: Logs to console instead of sending when keys absent

---

## 6. Error Handling & Retries

| Scenario | Strategy |
|----------|----------|
| SendGrid API down | Retry 3× with exponential backoff, then log failure |
| Twilio API down | Retry 3×, fallback to email-only |
| WebSocket disconnect | Auto-reconnect with Socket.io built-in retry |
| Invalid phone number | Skip WhatsApp, send other channels |
| Rate limited | Queue notifications, process with delay |
| Template error | Fallback to plain text message |
