# Self-Learning & Reinforcement Learning System

## Overview

The Self-Learning System enhances the Smart Intent Engine through supervised learning (admin corrections) and AI reinforcement learning (automated enrichment). Every user query is captured in the `SmartIntentEngineResponse` database table, creating a feedback loop that progressively improves the quality of clarifying questions and product responses.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER CHAT FLOW                          │
│                                                                 │
│  User Query ──► Smart Intent v2 Engine ──► Response             │
│                      │                         │                │
│                      ▼                         ▼                │
│               findLearnedResponse()    insertSmartIntentRecord()│
│                      │                         │                │
│          ┌───────────┴──────────┐              │                │
│          │ Priority Lookup:     │              │                │
│          │ 1. aiEnrichedResponse│              │                │
│          │ 2. supervisedResponse│              ▼                │
│          │ 3. original engine   │    ┌─────────────────┐        │
│          └──────────────────────┘    │SmartIntentEngine │        │
│                                      │Response (DB)    │        │
│                                      └─────────────────┘        │
└─────────────────────────────────────────────────────────────────┘

┌───────────────────────────────────────────────────────────────┐
│                    ADMIN LEARNING FLOW                        │
│                                                               │
│  Admin Dashboard ──► View Records ──► Edit Supervised Response│
│                                               │               │
│                 ┌─────────────────────────────┘               │
│                 ▼                                              │
│  AI Batch Enrich Button ──► enrichWithAI() ──► Rule-Based     │
│         │                                      Fallback       │
│         ▼                                                     │
│  External AI Service (if available)                           │
│  /api/v1/enrich-intent                                        │
└───────────────────────────────────────────────────────────────┘
```

---

## Database Schema

### Table: `SmartIntentEngineResponse`

| Column | Type | Description |
|--------|------|-------------|
| `id` | SERIAL PRIMARY KEY | Auto-increment ID |
| `userId` | INTEGER | User who made the query (nullable) |
| `queryBy` | VARCHAR(255) | User email or identifier |
| `queryText` | TEXT | The original search query |
| `initialProductSuggestionText` | TEXT | First product suggestions (first 500 chars) |
| `intentEngineResponse` | JSONB | Full engine output (intent, questions, products, processing_time) |
| `supervisedResponse` | JSONB | Admin-edited response (defaults to intentEngineResponse) |
| `aiEnrichedResponse` | JSONB | AI-enhanced response with improved questions |
| `enhancedByAI` | BOOLEAN DEFAULT FALSE | Whether AI enrichment has been applied |
| `isActive` | BOOLEAN DEFAULT TRUE | Whether this learned record is active for lookup (toggle via admin UI) |
| `createdAt` | TIMESTAMPTZ | Record creation time |
| `updatedAt` | TIMESTAMPTZ | Last modification time |

### Indexes
- `idx_sir_querytext_gin` — GIN trigram index on `queryText` for fast search
- `idx_sir_userid` — B-tree on `userId` for user-specific lookups
- `idx_sir_enhanced` — B-tree on `enhancedByAI` for batch processing
- `idx_sir_created` — B-tree on `createdAt` for chronological ordering

---

## Key Files

| File | Purpose |
|------|---------|
| `apps/web/lib/db.ts` | DB functions: `insertSmartIntentRecord`, `findLearnedResponse`, `getSmartIntentRecords`, `updateSupervisedResponse`, `updateAIEnrichedResponse`, `deleteSmartIntentRecord`, `getUnenrichedRecords`, `toggleSmartIntentActive` |
| `apps/web/app/api/admin/learning/route.ts` | Admin CRUD API: GET (paginated), PATCH (update), DELETE, POST (batch enrich) |
| `apps/web/app/api/chat/message/route.ts` | Chat streaming — captures queries + uses learned responses |
| `apps/web/app/api/intent/analyze/route.ts` | Intent analysis — captures queries + overrides questions from learned data |
| `apps/web/app/admin/learning/page.tsx` | Admin dashboard UI with table, inline edit, modal editor, batch AI enrichment |
| `scripts/smart-intent-learning-migration.sql` | Database migration SQL |
| `apps/web/test/unit/smart-intent-learning.test.ts` | 18 unit tests covering all DB functions and features |

---

## Learning Lookup Strategy

When a user query arrives, `findLearnedResponse(queryText)` executes a two-strategy search:

1. **Exact Match**: `LOWER(queryText) = LOWER($1)` — checks for identical past queries
2. **Word Containment**: If no exact match, splits query into words and checks if ALL words appear in any previous query via LIKE patterns

### Response Priority
When learned data exists:
1. **`aiEnrichedResponse`** (source: `'ai'`) — AI-enhanced questions are used first
2. **`supervisedResponse`** (source: `'supervised'`) — Admin corrections used as fallback
3. **Original engine response** — Used when no learned data exists

> **Note**: Only records with `isActive = true` are returned by `findLearnedResponse()`. Deactivated records are ignored during lookup but remain in the DB for audit purposes.

The learned response overrides the `questions` array in the engine result. If the learned data contains response text, it also overrides the display text.

---

## Admin Dashboard Features

### URL: `/admin/learning`

1. **Paginated Table**: Shows all captured queries with search, 20 records per page
2. **Inline Edit**: Click edit icon to modify SupervisedResponse JSON directly in the table cell
3. **Modal Edit**: Full-screen modal with read-only IntentEngineResponse view and editable SupervisedResponse textarea
4. **AI Enriched Response Viewer**: Dedicated read-only modal to inspect the full AI-enriched JSON (triggered from "View AI JSON" link in the table)
5. **isActive Toggle**: Checkbox toggle in "Active?" column — instantly toggles record's `isActive` flag in the DB with optimistic UI update and toast feedback
6. **Batch AI Enrichment**: "AI Batch Enrich (10)" button processes up to 10 unenriched records
7. **Delete**: Remove individual records with confirmation
8. **Search**: Filter records by query text
9. **Role-Based Access**: Accessible to admin, learning-support, and observability-support roles

### Role-Based Access Control (RBAC)

| Role | Email | Accessible Pages |
|------|-------|-----------------|
| `admin` | admin@delegatecart.com | All admin pages |
| `learning-support` | supervisedLearning@delegatecart.com | `/admin/learning` only |
| `observability-support` | observability@delegatecart.com | `/admin/learning`, `/observability` |
| `customer` | (all others) | No admin access |

**Password for all elevated users**: `Admin@DC2024!`

### Auth Mechanism
- **Client-side**: `hasPageAccess(path)` from `lib/admin-auth.ts` checks session role against allowed page paths
- **API-side**: `x-user-email` header checked against `LEARNING_EMAILS` whitelist (includes all elevated users)

---

## AI Enrichment Pipeline

When the admin clicks "AI Batch Enrich":

1. `POST /api/admin/learning` with `{ action: 'enrich-batch', batchSize: 10 }`
2. Fetches up to 10 records where `enhancedByAI = false`
3. For each record, tries:
   - **External AI Service**: `AI_SERVICE_URL/api/v1/enrich-intent` with the original query + intent response
   - **Rule-Based Fallback** (`enrichWithRules()`): Adds contextual budget + brand options based on detected category
4. Updates each record with `aiEnrichedResponse` and sets `enhancedByAI = true`

### Rule-Based Enrichment Categories
- **Electronics**: ₹5K–₹2L budget, Samsung/Apple/Sony/OnePlus etc.
- **Clothing**: ₹500–₹20K budget, Nike/Adidas/Levi's/Zara etc.
- **Home**: ₹1K–₹1L budget, IKEA/Godrej/Prestige etc.
- **Default**: ₹1K–₹50K budget, generic well-known brands

---

## Test Coverage

18 unit tests in `test/unit/smart-intent-learning.test.ts`:

| Suite | Tests | Coverage |
|-------|-------|----------|
| DB Functions | 10 | INSERT, SELECT, UPDATE, DELETE, findLearned (exact + word), getUnenriched |
| Admin API Validation | 2 | Auth email check, batch size bounds |
| Observability Seeding | 4 | Demo transaction seeding, idempotency, stuck/audit data |
| UnifiedLoader | 1 | Component export verification |
| User Isolation | 1 | Dynamic userId in buy-requests |

---

## Integration Points

### Chat Flow (`/api/chat/message`)
```
POST /api/chat/message { message, userId, conversationId }
  ├── processQuery(message) → IntentEngineResult
  ├── findLearnedResponse(message) → override questions/text
  ├── insertSmartIntentRecord({...}) → fire-and-forget capture
  └── Stream response to client (word-by-word, 25ms delay)
```

### Intent Flow (`/api/intent/analyze`)
```
POST /api/intent/analyze { query, userId }
  ├── processQuery(query) → IntentEngineResult  
  ├── findLearnedResponse(query) → override clarifying_questions
  ├── insertSmartIntentRecord({...}) → fire-and-forget capture
  └── Return JSON { intent, clarifying_questions, products, confidence }
```

---

## Future Enhancements

1. **Feedback Loop**: Capture which products users actually clicked/purchased after seeing suggestions
2. **A/B Testing**: Compare original vs. enriched response effectiveness
3. **Confidence Scoring**: Track whether learned responses improve user satisfaction metrics
4. **Embedding-Based Matching**: Replace word-containment with vector similarity for better fuzzy matching
5. **Auto-Supervised Learning**: Automatically promote frequently-used supervised responses to AI-enriched tier
