# DelegateCart — Low Level Design (LLD)

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Last Updated** | April 2026 |
| **Audience** | Developers, Code Reviewers, QA Engineers |
| **Scope** | Module-level design, class diagrams, data flows, API contracts |

---

## 1. Frontend Module Design

### 1.1 State Management Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Zustand Stores                      │
│  ┌────────────┐ ┌────────────┐ ┌─────────────────┐ │
│  │ cart-store  │ │ chat-store │ │ product-page-   │ │
│  │             │ │            │ │ store            │ │
│  │ DB write-   │ │ session    │ │ session          │ │
│  │ through     │ │ Storage    │ │ Storage          │ │
│  └────────────┘ └────────────┘ └─────────────────┘ │
└─────────────────────────────────────────────────────┘
```

**cart-store.ts** — Cart state with DB write-through
- `items: CartItem[]` — Current cart items
- `addItem(product)` → POST /api/cart + local update
- `removeItem(id)` → DELETE /api/cart + local update
- Individual primitive selectors for React optimization

**chat-store.ts** — AI Shopping Assistant session persistence
- `messages: ChatStoreMessage[]` — Chat history (role + content + timestamp)
- `timelineSteps: TimelineStepState[]` — Pipeline progress steps
- `approval: ApprovalState | null` — Pending approval data
- `activeTab: string` — Current sidebar tab
- `liveProducts: any[]` — Recommended products
- Persists to `sessionStorage` key `dc-chat-store`
- `hydrate()` — Reads from sessionStorage on mount
- `clearAll()` — Resets all state

**product-page-store.ts** — Product page filter/scroll persistence
- `searchQuery: string` — Active search text
- `sortBy: string` — Sort option (relevance/price/rating)
- `filterState: Record<string, any>` — Active filters (generic type)
- `scrollY: number` — Scroll position for restoration
- `sphereCategory: string` — Active 3D category sphere
- Persists to `sessionStorage` key `dc-product-page`

### 1.2 Component Hierarchy (Key Pages)

```
app/layout.tsx
├── LayoutClient (layout-client.tsx)
│   ├── Header
│   │   ├── Logo (components/ui/Logo.tsx)
│   │   ├── Navigation Links
│   │   ├── Search Bar
│   │   └── Cart Icon + Auth
│   ├── Main Content (children)
│   └── Footer
│       └── FooterLogo

app/products/page.tsx
├── CategorySphereWrapper (3D scene)
├── SearchBar + SortDropdown
├── ProductFilters (sidebar)
├── ProductGrid (virtualized)
│   └── ProductCard × N
└── Pagination

app/shopping-assistant/page.tsx
├── ShoppingChat (main chat panel)
│   ├── Sticky Header
│   ├── Scrollable Messages
│   ├── Quick Actions
│   └── Input Bar
└── Sidebar (lg:sticky, scrollable)
    ├── Pipeline Tab (TimelineSteps)
    ├── Decision Tab (AI Reasoning)
    └── Approval Tab (HITL controls)

app/shopping-list/page.tsx
├── ShoppingListTable
│   └── Row × N (name, budget, status, actions)
├── AutoCheckout Toggle
├── NotifyOrderFailed handler
└── WalletPayment integration

app/observability/page.tsx
├── AdminLoginGate
│   ├── Login Form (email + password)
│   └── ObservabilityContent
│       ├── MetricsGrid (4 cards)
│       ├── ResponseTimeChart
│       ├── ErrorRateChart
│       └── ActiveAgentsList
```

### 1.3 API Route Handlers

Each Next.js API route follows this pattern:

```typescript
// apps/web/app/api/[resource]/route.ts
export async function GET(request: Request) {
  // 1. Parse query params / auth headers
  // 2. Call NestJS backend OR direct DB query
  // 3. Transform response
  // 4. Return NextResponse.json()
}

export async function POST(request: Request) {
  // 1. Parse body (await request.json())
  // 2. Validate required fields
  // 3. Forward to NestJS OR execute business logic
  // 4. Return NextResponse.json() with status
}
```

---

## 2. Backend Module Design

### 2.1 NestJS Module Structure

```
apps/api/src/
├── main.ts                    # Bootstrap, Swagger, CORS, globals
├── app.module.ts              # Root module, imports all feature modules
└── modules/
    ├── auth/
    │   ├── auth.module.ts
    │   ├── auth.controller.ts   # POST /auth/register, /auth/login
    │   ├── auth.service.ts      # JWT generation, password hashing
    │   └── jwt.strategy.ts      # Passport JWT strategy
    ├── product/
    │   ├── product.module.ts
    │   ├── product.controller.ts # GET /products, GET /products/:id
    │   ├── product.service.ts    # CRUD + Kafka event emission
    │   └── product.gateway.ts    # WebSocket for real-time updates
    ├── cart/
    │   ├── cart.controller.ts    # GET/POST/DELETE /cart
    │   └── cart.service.ts       # Cart operations with CartItem upsert
    ├── order/
    │   ├── order.controller.ts   # POST /orders, GET /orders/:userId
    │   └── order.service.ts      # Order creation, status updates
    ├── wallet/
    │   ├── wallet.controller.ts  # GET/POST /wallet, /wallet/transactions
    │   └── wallet.service.ts     # Balance ops, authorization, limits
    ├── agent/
    │   ├── agent.controller.ts   # Agentic checkout orchestration
    │   └── agent.service.ts      # HITL approval workflow
    ├── ai-chat/
    │   ├── ai-chat.controller.ts # POST /chat/message, /chat/stream
    │   └── ai-chat.service.ts    # AI response generation
    ├── ai-memory/
    │   ├── memory.service.ts     # Preference tracking, insights
    │   ├── auto-decision.service.ts # Autonomous decision making
    │   └── ranking.service.ts    # Personalized product ranking
    ├── ai-execution/
    │   └── execution.service.ts  # AI action execution (add to cart, order)
    ├── buy-request/
    │   ├── buy-request.controller.ts # POST /buy-requests
    │   └── buy-request.service.ts    # Create + emit Kafka event
    ├── seller-copilot/
    │   ├── seller.controller.ts  # Seller dashboard APIs
    │   └── seller.service.ts     # AI listing, pricing, demand
    └── feature-flag/
        └── feature-flag.service.ts # Feature toggle system
```

### 2.2 Prisma Schema Key Relationships

```
User (1) ────── (N) Order
User (1) ────── (1) Cart ────── (N) CartItem ────── (1) Product
User (1) ────── (1) Wallet ────── (N) WalletTransaction
User (1) ────── (N) BuyRequest
User (1) ────── (N) ChatMessage
User (1) ────── (1) UserPreferences ────── (N) MemoryInsight
User (1) ────── (1) UserMemory ────── (N) UserMemoryInteraction
User (1) ────── (1) BuyingPattern
User (1) ────── (N) ApprovalRequest
User (1) ────── (N) AIDecisionLog
Product (1) ────── (1) ProductBusinessMetrics
Seller (1) ────── (N) SellerProduct ────── (N) PriceHistory
```

### 2.3 Transaction Patterns

**Wallet Transaction (Atomic)**:
```
BEGIN TRANSACTION
  1. Lock wallet row (SELECT FOR UPDATE)
  2. Validate balance >= amount
  3. Create WalletTransaction (status: pending)
  4. Deduct wallet balance
  5. Update transaction (status: completed, balanceAfter)
  6. Create WalletAuditLog
COMMIT
ON ERROR → ROLLBACK + Create failed transaction record
```

**Idempotent Order Creation**:
```
1. Check idempotencyKey in recent transactions
2. If exists → return cached result
3. If not → execute transaction
4. Store result with idempotencyKey
```

---

## 3. AI Microservices Design

### 3.1 Intent Parser (Port 3002)

```python
# main.py
@app.post("/parse")
async def parse_intent(request: ParseRequest):
    # 1. Receive raw user text from Kafka consumer
    # 2. Call LLM (OpenAI GPT-4 or Anthropic Claude 3)
    # 3. Extract: product_name, budget_min/max, quality_score,
    #            preferred_brands, delivery_requirements
    # 4. Publish structured intent to Kafka: intent.processed
```

**LLM Provider Pattern**:
```python
class LLMProvider:
    def __init__(self):
        self.primary = config.LLM_PROVIDER  # 'openai' or 'anthropic'

    async def extract_intent(self, text: str) -> Intent:
        try:
            return await self._call_primary(text)
        except Exception:
            return await self._call_fallback(text)  # Auto-failover
```

### 3.2 Product Aggregator (Port 3003)

```python
# main.py
@app.post("/aggregate")
async def aggregate_products(intent: ProcessedIntent):
    # 1. Check Redis cache (key: f"agg:{hash(intent)}")
    # 2. If cached → return immediately
    # 3. Parallel fetch from:
    #    - Internal DB (PostgreSQL)
    #    - Amazon Product API
    #    - Flipkart Product API
    # 4. Deduplicate by product name similarity
    # 5. Cache results in Redis (TTL: 10 min)
    # 6. Publish to Kafka: products.fetched
```

### 3.3 Product Ranking Engine (Port 3004)

```python
# Scoring formula
def score_product(product, intent, user_preferences):
    budget_fit = gaussian(product.price, intent.budget_mid, intent.budget_range)
    quality    = product.quality_score / 100
    brand      = 1.0 if product.brand in intent.preferred_brands else 0.5
    delivery   = delivery_score(product.delivery_days, intent.delivery_date)
    ratings    = product.avg_rating / 5.0

    weights = user_preferences.ranking_weights or DEFAULT_WEIGHTS
    # DEFAULT_WEIGHTS: budget=0.3, quality=0.25, brand=0.2, delivery=0.15, ratings=0.1

    return (weights.budget * budget_fit +
            weights.quality * quality +
            weights.brand * brand +
            weights.delivery * delivery +
            weights.ratings * ratings) * 100
```

---

## 4. Frontend Library Modules

### 4.1 wallet-transactions.ts (477 lines)

Enterprise-grade transaction orchestration:

```typescript
interface TransactionOrchestrator {
  executeDebit(walletId, amount, orderId, idempotencyKey): Promise<TransactionResult>
  executeRefund(originalTxId): Promise<TransactionResult>
  executeHold(walletId, amount, purpose): Promise<HoldResult>
  releaseHold(holdId): Promise<void>
  replayFailedTransaction(txId): Promise<TransactionResult>
}
```

Key features:
- Idempotency via unique keys (prevents duplicate charges)
- Automatic refund on checkout failure
- Hold/release pattern for pending approvals
- Full audit trail (balanceBefore, balanceAfter)
- Retry with exponential backoff

### 4.2 product-images.ts (329 lines)

Brand-specific image mapping (no database storage):

```typescript
function getProductImage(productName: string, category: string): string {
  // 1. Extract brand from product name
  // 2. Match against brand-specific Unsplash/CDN image map
  // 3. Fallback: category-based generic image
  // Returns: URL string (external CDN, not stored in DB)
}
```

### 4.3 notifications.ts (157 lines)

Multi-channel notification service:

```typescript
interface NotificationService {
  sendOrderConfirmation(userId, orderId): Promise<void>
  sendSearchResults(userId, products): Promise<void>
  notifyOrderFailed(userId, orderId, reason): Promise<void>
  sendApprovalRequest(userId, approvalId): Promise<void>
}
// Channels: In-app toast, Email (SendGrid), WhatsApp (Twilio)
```

### 4.4 admin-auth.ts

Admin authentication for observability dashboard:

```typescript
const ADMIN_CREDENTIALS = {
  emails: ['admin@delegatecart.com', 'admin@example.com'],
  password: 'Admin@DC2024!'
}

function authenticateAdmin(email: string, password: string): boolean
function isAdminUser(): boolean      // Check sessionStorage
function clearAdminSession(): void
function getAdminSession(): AdminSession | null  // 8-hour expiry
```

---

## 5. Error Handling Strategy

### Frontend
```
API calls → try/catch → toast notification (react-hot-toast)
            ↓ on 401
            redirect to /auth/login
            ↓ on network error
            retry with exponential backoff (3 attempts)
```

### Backend (NestJS)
```
Controller → Service → Prisma
             ↓ on error
             NestJS Exception Filters
             ↓
             Standardized error response:
             { statusCode, message, error, timestamp }
```

### AI Services (FastAPI)
```
Endpoint → LLM call → tenacity retry (3 attempts, exponential)
           ↓ on all retries failed
           Fallback LLM provider
           ↓ on fallback failed
           Return graceful degradation response
```

---

## 6. Data Flow Diagrams

### 6.1 Product Search Flow

```
User types "wireless earbuds under ₹3000"
  │
  ▼
ShoppingChat.tsx → POST /api/chat/message
  │
  ▼
API Route → Extract intent (product: earbuds, budget: ≤3000)
  │
  ▼
Query Products (Prisma) → Filter by name ILIKE '%earbuds%' AND price <= 3000
  │
  ▼
AI Scoring Engine → Score each product (5 factors)
  │
  ▼
Return sorted results → ShoppingChat renders product cards
  │
  ▼
User clicks "Add to Cart" → cart-store.addItem() → POST /api/cart
```

### 6.2 Auto-Checkout Flow

```
Shopping List item with autoCheckout=true
  │
  ▼
User clicks "Search & Buy" → POST /api/ai-shopping-list
  │
  ▼
AI finds best product → Score > threshold?
  │            │
  │ Yes        │ No → Notify user, manual selection
  ▼
Check wallet: balance >= price AND isAiAuthorized?
  │            │
  │ Yes        │ No → Create ApprovalRequest
  ▼
wallet-transactions.executeDebit(walletId, price, idempotencyKey)
  │
  ▼
Create Order → Update shopping list status → Notify user
  │
  ▼ On failure
wallet-transactions.executeRefund() → notifyOrderFailed()
```

### 6.3 Kafka Pipeline Flow

```
BuyRequest created (API)
  │
  ▼ Kafka: buy_request.created
Intent Parser (Python)
  │ LLM: GPT-4 / Claude 3
  ▼ Kafka: intent.processed
Product Aggregator (Python)
  │ Redis cache + Amazon + Flipkart APIs
  ▼ Kafka: products.fetched
Ranking Engine (Python)
  │ NumPy scoring: budget × quality × brand × delivery × ratings
  ▼ Kafka: products.ranked
API / Autopilot Engine ← consumes ranked results
  │
  ▼ If autoExecute → Wallet debit + Order creation
  ▼ If manual → Notification to user
```
