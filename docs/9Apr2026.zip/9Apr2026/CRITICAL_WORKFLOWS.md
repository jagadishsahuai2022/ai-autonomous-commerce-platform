# DelegateCart — Critical Workflow Documentation

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 2.0 |
| **Last Updated** | April 2026 |
| **Scope** | All critical user-facing and system workflows |

---

## Table of Contents

1. [AI-Assisted Search Workflow](#1-ai-assisted-search-workflow)
2. [Auto-Checkout Workflow](#2-auto-checkout-workflow)
3. [Shopping List Product Search & Notification Workflow](#3-shopping-list-product-search--notification-workflow)
4. [User Authentication Workflow](#4-user-authentication-workflow)
5. [Cart & External Product Workflow](#5-cart--external-product-workflow)
6. [AI Scoring Pipeline](#6-ai-scoring-pipeline)
7. [Order Lifecycle Workflow](#7-order-lifecycle-workflow)
8. [Analytics Tracking Workflow](#8-analytics-tracking-workflow)

---

## 1. AI-Assisted Search Workflow

### Overview
The AI Assistant provides a conversational interface for product discovery. Users describe their needs in natural language, and the system returns scored product recommendations.

### Sequence Diagram

```
┌──────┐     ┌────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────┐
│ User │     │ Chat UI    │    │ /api/chat/   │    │ AI Scoring   │    │ Behavior │
│      │     │ (React)    │    │ message      │    │ Engine       │    │ Tracker  │
└──┬───┘     └─────┬──────┘    └──────┬───────┘    └──────┬───────┘    └────┬─────┘
   │                │                  │                    │                 │
   │ Types message  │                  │                    │                 │
   │───────────────>│                  │                    │                 │
   │                │                  │                    │                 │
   │                │  POST /api/chat/ │                    │                 │
   │                │  message         │                    │                 │
   │                │ {message, userId}│                    │                 │
   │                │─────────────────>│                    │                 │
   │                │                  │                    │                 │
   │                │                  │ Parse message      │                 │
   │                │                  │ category keywords  │                 │
   │                │                  │                    │                 │
   │                │                  │ Match product      │                 │
   │                │                  │ catalog             │                 │
   │                │                  │                    │                 │
   │                │                  │ If products found: │                 │
   │                │                  │───────────────────>│                 │
   │                │                  │                    │ scoreProducts() │
   │                │                  │                    │ 5-factor calc   │
   │                │                  │<───────────────────│                 │
   │                │                  │                    │                 │
   │                │                  │ Track behavior     │                 │
   │                │                  │ (search event)     │                 │
   │                │                  │────────────────────────────────────>│
   │                │                  │                    │                 │
   │                │  Response:       │                    │                 │
   │                │  {reply, products│                    │                 │
   │                │   with aiScore}  │                    │                 │
   │                │<─────────────────│                    │                 │
   │                │                  │                    │                 │
   │  Display recs  │                  │                    │                 │
   │  with scores   │                  │                    │                 │
   │<───────────────│                  │                    │                 │
```

### Step-by-Step

| Step | Component | Action |
|------|-----------|--------|
| 1 | User | Types natural language query (e.g., "Best laptop under 80K") |
| 2 | Chat UI | Sends POST to `/api/chat/message` with `{message, userId}` |
| 3 | API | Extracts auth token, validates session (optional — works for anonymous) |
| 4 | API | Parses message against 13+ product category keyword maps |
| 5 | API | Extracts product entries in "Brand Model (₹XX,XXX)" format |
| 6 | API | For each extracted product: calls `parseProductEntry()` → validates price |
| 7 | Scoring | `scoreProducts()` calculates 5-factor score per product |
| 8 | API | Tracks behavior: `{action: 'search', metadata: {query}}` |
| 9 | API | If authenticated: loads user preferences for preference-match scoring |
| 10 | API | Returns `{reply, products: ScoredProduct[]}` sorted by aiScore desc |
| 11 | Chat UI | Renders product cards with AI score, explanation, add-to-cart button |

### Error Handling

| Scenario | Behavior |
|----------|----------|
| Empty message | 400 error: "Message is required" |
| No category match | Generic helpful response with suggestions |
| Invalid product format | Silently filtered out (returns null) |
| Price ≤ 0 | Product entry skipped |
| Auth failure | Chat still works (anonymous mode) |

---

## 2. Auto-Checkout Workflow

### Overview
Users can configure DelegateCart to automatically purchase products that meet specific criteria (score threshold + budget limit), eliminating the manual checkout flow.

### Sequence Diagram

```
┌──────┐    ┌──────────────┐    ┌───────────┐    ┌─────────────┐    ┌───────────┐
│ User │    │ Shopping List │    │ /api/      │    │ Autopilot   │    │ Notifier  │
│      │    │ Page         │    │ shopping-  │    │ Engine      │    │ (WhatsApp)│
└──┬───┘    └──────┬───────┘    │ list       │    └──────┬──────┘    └─────┬─────┘
   │               │            └──────┬──────┘           │                 │
   │ Enable auto-  │                   │                  │                 │
   │ purchase on   │                   │                  │                 │
   │ /profile      │                   │                  │                 │
   │ (threshold:   │                   │                  │                 │
   │  ₹5000)       │                   │                  │                 │
   │               │                   │                  │                 │
   │ Submit list   │                   │                  │                 │
   │ with auto=true│                   │                  │                 │
   │──────────────>│                   │                  │                 │
   │               │ POST {items,      │                  │                 │
   │               │  autoCheckout:true│                  │                 │
   │               │  whatsapp: "+91.."│                  │                 │
   │               │──────────────────>│                  │                 │
   │               │                   │                  │                 │
   │               │                   │ Search + Score   │                 │
   │               │                   │ products         │                 │
   │               │                   │                  │                 │
   │               │                   │ Check conditions:│                 │
   │               │                   │ aiScore > 80?    │                 │
   │               │                   │ price ≤ threshold?│                │
   │               │                   │                  │                 │
   │               │                   │ If YES:          │                 │
   │               │                   │─────────────────>│                 │
   │               │                   │                  │ Create order    │
   │               │                   │                  │ Apply rules:    │
   │               │                   │                  │  - brand check  │
   │               │                   │                  │  - spend limit  │
   │               │                   │                  │  - anomaly det. │
   │               │                   │<─────────────────│                 │
   │               │                   │                  │                 │
   │               │                   │ Send notification│                 │
   │               │                   │─────────────────────────────────>│
   │               │                   │                  │                 │
   │               │ {results,         │                  │ WhatsApp msg:   │
   │               │  autoPlaced: true}│                  │ "Order placed!" │
   │               │<──────────────────│                  │────────────────>│ User
   │               │                   │                  │                 │
   │ Show success  │                   │                  │                 │
   │<──────────────│                   │                  │                 │
```

### Configuration

| Setting | Location | Default |
|---------|----------|---------|
| `autoPurchaseEnabled` | Profile → AI & Subscription | `false` |
| `autoPurchaseThreshold` | Profile → AI & Subscription | ₹5,000 |
| `autoCheckout` flag | Shopping List "Auto-buy" toggle | `false` |

### Safety Layer (Autopilot Engine)

| Check | Description |
|-------|-------------|
| Budget Limit | Price must be ≤ user's `autoPurchaseThreshold` |
| AI Score Threshold | Product must have aiScore ≥ 80 |
| Daily Spend Limit | Prevents runaway auto-purchases |
| Anomaly Detection | Flags unusual purchase patterns |
| Brand Rules | Optional brand whitelist/blacklist |
| Time-Based Rules | Can restrict to business hours |
| Approval Workflow | High-value items require manual confirmation |

---

## 3. Shopping List Product Search & Notification Workflow

### Overview
The most complex workflow — a multi-item shopping list triggers AI-powered multi-source search, scoring, caching, and multi-channel notifications.

### Complete Flow Diagram

```
┌──────┐    ┌─────────────┐    ┌────────────┐    ┌───────────┐    ┌──────────────┐
│ User │    │ Shopping     │    │ /api/      │    │ Product   │    │ Notification │
│      │    │ List Page    │    │ shopping-  │    │ Aggregator│    │ Service      │
└──┬───┘    └──────┬──────┘    │ list       │    │ + Ranking │    └──────┬───────┘
   │               │           └──────┬─────┘    └─────┬─────┘           │
   │               │                  │                 │                 │
   │ Add items:    │                  │                 │                 │
   │ - Laptop 80K  │                  │                 │                 │
   │ - Mouse 2K    │                  │                 │                 │
   │──────────────>│                  │                 │                 │
   │               │                  │                 │                 │
   │ Click Search  │                  │                 │                 │
   │──────────────>│                  │                 │                 │
   │               │                  │                 │                 │
   │               │ POST /api/       │                 │                 │
   │               │ shopping-list    │                 │                 │
   │               │ {items, whatsapp,│                 │                 │
   │               │  forceFresh}     │                 │                 │
   │               │─────────────────>│                 │                 │
   │               │                  │                 │                 │
   │               │                  │─── Check Cache ─┐                │
   │               │                  │  (5h TTL)       │                │
   │               │                  │<── Cache HIT ───┘                │
   │               │                  │    Return cached                 │
   │               │                  │                                  │
   │               │                  │─── Cache MISS ──┐                │
   │               │                  │                 │                │
   │               │                  │                 ▼                │
   │               │                  │         Search Sources:          │
   │               │                  │         1. Internal DB           │
   │               │                  │         2. Amazon API            │
   │               │                  │         3. Flipkart API          │
   │               │                  │                 │                │
   │               │                  │         Score Products           │
   │               │                  │         (5-factor engine)        │
   │               │                  │                 │                │
   │               │                  │         Sort by aiScore          │
   │               │                  │<────────────────┘                │
   │               │                  │                                  │
   │               │                  │── Save to Cache ──>              │
   │               │                  │                                  │
   │               │                  │ If whatsapp provided:            │
   │               │                  │──────────────────────────────────>│
   │               │                  │                                  │
   │               │                  │                    Send WhatsApp │
   │               │                  │                    with results  │
   │               │                  │                    summary       │
   │               │                  │                                  │ → User Phone
   │               │                  │                                  │
   │               │                  │ If email configured:             │
   │               │                  │──────────────────────────────────>│
   │               │                  │                    Send Email    │
   │               │                  │                    with details  │
   │               │                  │                                  │ → User Email
   │               │                  │                                  │
   │               │ Response:        │                                  │
   │               │ {results, summary│                                  │
   │               │  whatsappSent,   │                                  │
   │               │  emailSent,      │                                  │
   │               │  fromCache}      │                                  │
   │               │<─────────────────│                                  │
   │               │                  │                                  │
   │               │ Save to          │                                  │
   │               │ localStorage     │                                  │
   │               │ (max 20 results) │                                  │
   │               │                  │                                  │
   │ Display       │                  │                                  │
   │ results with  │                  │                                  │
   │ AI scores     │                  │                                  │
   │<──────────────│                  │                                  │
```

### API Request Format

```json
POST /api/shopping-list
{
  "items": [
    {
      "name": "Laptop",
      "brand": "Dell",
      "budget": "80000",
      "quantity": 1,
      "deliveryDays": 5,
      "paymentMethod": "emi",
      "emiOnly": true
    }
  ],
  "whatsappNumber": "+919876543210",
  "forceFresh": false,
  "autoCheckout": false,
  "authToken": "bearer-token-here"
}
```

### API Response Format

```json
{
  "listId": "sl-1712000000000",
  "results": [
    {
      "productName": "Laptop",
      "preferredBrand": "Dell",
      "budget": 80000,
      "quantity": 1,
      "matches": [
        {
          "name": "Dell XPS 15",
          "brand": "Dell",
          "price": 89990,
          "rating": 4.6,
          "matchScore": 92,
          "estimatedDelivery": "3-5 days",
          "emiAvailable": true,
          "url": "https://...",
          "source": "INTERNAL",
          "aiScore": 87,
          "aiExplanation": "High relevance to 'Laptop'. Matches your preferences. Highly rated (4.6/5). EMI available.",
          "aiConfidence": 92,
          "scoreBreakdown": {
            "relevance": 85,
            "preferenceMatch": 78,
            "priceFit": 70,
            "ratingScore": 92,
            "aiConfidence": 97
          }
        }
      ]
    }
  ],
  "summary": {
    "totalItems": 1,
    "totalMatches": 4,
    "estimatedSavings": "₹5,000"
  },
  "whatsappSent": true,
  "emailSent": false,
  "fromCache": false
}
```

### Cache Strategy

| Parameter | Value |
|-----------|-------|
| Cache Key | SHA-256 hash of normalized items array |
| TTL | 5 hours |
| Storage | PostgreSQL `ShoppingListSearch` table |
| Force Refresh | `forceFresh: true` bypasses cache |
| Client Cache | localStorage `shoppingListResults` (max 20) |

### Notification Triggers

| Channel | Trigger | Content |
|---------|---------|---------|
| WhatsApp | Shopping list completion + number provided | Results summary: top matches, prices, AI scores |
| Email | Shopping list completion + email configured | Formatted HTML with product details |
| WhatsApp | Auto-checkout completion | "Order placed: [Product] at ₹[Price]" |
| Email | Order confirmation | Order details, items, total, delivery estimate |

---

## 4. User Authentication Workflow

### Registration Flow

```
User → POST /api/auth/register {email, password, name}
  → Validate: email format, password min 6 chars
  → Check: email not already registered
  → Hash password: bcrypt(password, 10 rounds)
  → INSERT User row
  → Create session: INSERT UserSession {token, userId, email, expiresAt: +7d}
  → Return {token, user: {id, email, name}}
  → Client stores: localStorage.authToken + localStorage.userEmail
```

### Login Flow

```
User → POST /api/auth/login {email, password}
  → Find user by email
  → bcrypt.compare(password, storedHash)
  → If match: Create new UserSession
  → Return {token, user: {id, email, name}}
  → Client stores in localStorage
```

### Session Validation (Every Protected API Call)

```
Request headers: Authorization: Bearer <token>
  → Extract token from header (or cookie fallback)
  → SELECT * FROM UserSession WHERE token = $1
  → Check: expiresAt > NOW()
  → If valid: return {userId, email}
  → If invalid: return 401 Unauthorized
```

---

## 5. Cart & External Product Workflow

```
User adds product from AI results
    │
    ├── Product has source: "INTERNAL"
    │   └── Added to cart normally
    │       └── Can checkout ✓
    │
    └── Product has source: "EXTERNAL"
        └── Added to cart with source: "EXTERNAL"
            └── Cart page shows:
                ├── "External" badge (orange)
                ├── Warning: "Cannot be purchased here"
                └── External link to buy on original site
            └── Checkout:
                ├── EXTERNAL items filtered OUT
                ├── Only INTERNAL items proceed
                └── If all items are EXTERNAL:
                    └── "Proceed to Checkout" button DISABLED
```

---

## 6. AI Scoring Pipeline

### Processing Steps

```
Input: ProductMatch[] + UserPreference + SearchQuery + Budget
                    │
     ┌──────────────┴──────────────┐
     │  For each product:          │
     │                             │
     │  1. computeRelevance()      │ ← Name match, brand match, keyword overlap
     │     Weight: 30%             │
     │                             │
     │  2. computePreference()     │ ← Brand history, behavior (cart/purchase/reject)
     │     Weight: 25%             │
     │                             │
     │  3. computePriceFit()       │ ← Budget comparison (≤70%→90, ≤100%→100, etc.)
     │     Weight: 20%             │
     │                             │
     │  4. computeRating()         │ ← (rating / 5) × 100
     │     Weight: 15%             │
     │                             │
     │  5. computeConfidence()     │ ← matchScore × 1.05 (capped at 100)
     │     Weight: 10%             │
     │                             │
     │  aiScore = weighted sum     │
     │  generateExplanation()      │
     └──────────────┬──────────────┘
                    │
     Sort by aiScore descending
                    │
     Output: ScoredProduct[] with aiScore, aiExplanation, scoreBreakdown
```

---

## 7. Order Lifecycle Workflow

```
Cart Items Selected
     │
     ▼
Checkout Step 1: Select/Add Address
     │  Validation: pincode (6 digits), phone (10 digits)
     ▼
Checkout Step 2: Choose Shipping
     │  Standard (free) / Express (₹99) / Overnight (₹299)
     ▼
Checkout Step 3: Select Payment
     │  UPI / Card / Net Banking / COD / EMI
     ▼
Checkout Step 4: Review & Confirm
     │  Cart total = subtotal + GST(18%) + shipping
     ▼
Place Order
     │
     ├── Immediate: Save to localStorage (instant feedback)
     │
     ├── Async: POST /api/orders → DB write
     │   └── Returns: orderNumber (ORD-XXXXXXXX-XXXX)
     │
     ├── Clear cart (localStorage)
     │
     └── Show success page with order ID
           │
           ▼
     Order Status: processing → confirmed → shipped → delivered
```

---

## 8. Analytics Tracking Workflow

### Event Flow

```
User Action (page view, search, add to cart, purchase)
     │
     ├── Client-side: behavior tracked via POST /api/user/behavior
     │   {action: "add_to_cart", productId: "xyz", metadata: {...}}
     │
     └── Server-side: POST /api/analytics (requires auth)
         {eventType: "purchase", productId: "xyz", metadata: {...}}
              │
              ▼
         PostgreSQL AnalyticsEvent table
              │
              ▼
         Admin Dashboard (/admin/analytics)
         GET /api/analytics?days=30
              │
              ▼
         Metrics: total events, unique users, conversion rate,
                  AI recommendation success rate, top products,
                  daily trend chart
```

### Allowed Event Types

| Event Type | Description | Requires Auth |
|-----------|-------------|---------------|
| `page_view` | User viewed a page | Yes |
| `search` | User searched for products | Yes |
| `add_to_cart` | Product added to cart | Yes |
| `remove_from_cart` | Product removed from cart | Yes |
| `purchase` | Order completed | Yes |
| `ai_recommendation` | AI recommendation shown | Yes |
| `click` | User clicked a product/link | Yes |
| `view` | User viewed a product detail | Yes |
