# DelegateCart — Observability & Monitoring Documentation

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Last Updated** | April 2026 |
| **Scope** | Metrics, tracing, dashboards, health checks, alerting |

---

## 1. Observability Stack

| Component | Tool | Purpose |
|-----------|------|---------|
| **Metrics** | Prometheus (prom-client) | Service health, latency, throughput |
| **Tracing** | OpenTelemetry | Distributed request tracing |
| **Dashboards** | Custom Next.js page | Real-time monitoring UI |
| **Health Checks** | HTTP endpoints | Container orchestration |
| **Kafka Monitoring** | Provectus Kafka UI | Topic/consumer lag visibility |

---

## 2. Metrics Collection

### 2.1 Backend Metrics (NestJS + prom-client)

```typescript
// Counters
http_requests_total{method, path, status}       // Total HTTP requests
order_created_total{payment_method}              // Orders created
wallet_transactions_total{type, status}          // Wallet operations
ai_decisions_total{type, outcome}                // AI decision counts
kafka_messages_published_total{topic}            // Kafka publish count
kafka_messages_consumed_total{topic}             // Kafka consume count

// Histograms
http_request_duration_seconds{method, path}      // API latency distribution
ai_decision_duration_seconds{type}               // AI decision time
kafka_message_processing_seconds{topic}          // Kafka processing time
db_query_duration_seconds{operation}             // Database query time

// Gauges
active_websocket_connections                     // Current WebSocket connections
wallet_total_balance                             // Aggregate wallet balance
pending_approval_requests                        // Awaiting user approval
kafka_consumer_lag{topic, group}                 // Consumer lag
```

### 2.2 Frontend Metrics (Custom)

```typescript
// Client-side performance tracking
page_load_time{route}                           // Time to interactive
api_call_duration{endpoint}                      // Frontend → API latency
render_count{component}                          // Re-render tracking
error_boundary_catches{component}                // Error boundary hits
```

---

## 3. Distributed Tracing

### 3.1 OpenTelemetry Integration

```
Trace: user_search_request
  │
  Span: web.api_route (/api/chat/message) [50ms]
  │
  ├── Span: api.intent_extraction [120ms]
  │   └── Span: llm.openai_call [100ms]
  │
  ├── Span: api.product_search [80ms]
  │   └── Span: db.prisma_query [30ms]
  │
  ├── Span: api.ai_scoring [60ms]
  │   └── Span: scoring.calculate [40ms]
  │
  └── Span: api.response_format [10ms]
  
  Total: ~320ms
```

### 3.2 Trace Context Propagation

```
Web (Next.js) → API (NestJS) → AI Service (FastAPI)
     traceparent: 00-{traceId}-{spanId}-01
     
Kafka Pipeline:
  Producer → Message Header: traceparent
  Consumer → Extract traceparent → Continue trace
```

### 3.3 AI Decision Tracing

Every AI decision includes an OpenTelemetry `traceId` in `AIDecisionLog`:

```typescript
// AIDecisionLog record
{
  traceId: "abc123def456...",  // Links to full distributed trace
  decisionType: "auto_purchase",
  confidence: 0.92,
  executionMs: 450,           // Total end-to-end time
  reasoning: "Best price-quality match within budget"
}
```

---

## 4. Observability Dashboard

### 4.1 Access Control

- **URL**: `/observability`
- **Access**: Admin-only (email whitelist + password)
- **Credentials**: `admin@delegatecart.com` / `Admin@DC2024!`
- **Session**: 8-hour expiry (sessionStorage)

### 4.2 Dashboard Components

```
┌────────────────────────────────────────────────────────┐
│  🔒 Admin Observability Dashboard                       │
├────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│  │ Total    │ │ Avg      │ │ Error    │ │ Active   │ │
│  │ Requests │ │ Latency  │ │ Rate     │ │ Agents   │ │
│  │ 12,450   │ │ 145ms    │ │ 0.3%    │ │ 7        │ │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ │
│                                                          │
│  ┌──────────────────────────────────────────────────┐   │
│  │ Response Time (line chart, 24h)                   │   │
│  │  200ms ─ ··· ···· ···· ··· ···· ···· ···        │   │
│  │  100ms ─ ████████████████████████████████        │   │
│  │    0ms ─                                          │   │
│  └──────────────────────────────────────────────────┘   │
│                                                          │
│  ┌──────────────────────────────────────────────────┐   │
│  │ Error Rate (area chart, 24h)                      │   │
│  │  5% ─                                             │   │
│  │  2% ─ ·  ·                                        │   │
│  │  0% ─ ████████████████████████████████████       │   │
│  └──────────────────────────────────────────────────┘   │
│                                                          │
│  ┌──────────────────────────────────────────────────┐   │
│  │ Active AI Agents                                  │   │
│  │ ┌─────────────────┬────────┬──────────────────┐  │   │
│  │ │ Agent Name      │ Status │ Uptime           │  │   │
│  │ ├─────────────────┼────────┼──────────────────┤  │   │
│  │ │ Intent Parser   │ 🟢     │ 99.9%           │  │   │
│  │ │ Product Agg     │ 🟢     │ 99.8%           │  │   │
│  │ │ Ranking Engine  │ 🟢     │ 99.9%           │  │   │
│  │ │ AI Chat         │ 🟢     │ 99.7%           │  │   │
│  │ │ Autopilot       │ 🟢     │ 99.6%           │  │   │
│  │ │ Memory Service  │ 🟢     │ 99.9%           │  │   │
│  │ │ Execution Agent │ 🟢     │ 99.5%           │  │   │
│  │ └─────────────────┴────────┴──────────────────┘  │   │
│  └──────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────┘
```

### 4.3 Auto-Refresh

Dashboard refreshes every 30 seconds via `setInterval`:
```typescript
useEffect(() => {
  const interval = setInterval(() => {
    fetchMetrics();
    fetchAgentStatus();
    fetchErrorRate();
  }, 30000);
  return () => clearInterval(interval);
}, []);
```

---

## 5. Health Check Endpoints

### 5.1 Service Health

| Endpoint | Service | Checks |
|----------|---------|--------|
| `GET /api/monitoring` | Web (Next.js) | DB connection, Redis, API reachability |
| `GET /health` | API (NestJS) | DB, Kafka, Redis connections |
| `GET /health` | AI Service | Model loaded, DB connection |
| `GET /health` | Intent Parser | LLM provider accessible |
| `GET /health` | Product Aggregator | Redis, external API connectivity |
| `GET /health` | Ranking Engine | Model loaded, Kafka connection |

### 5.2 Docker Health Checks

```yaml
# docker-compose.yml
services:
  api:
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
  
  web:
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000"]
      interval: 30s
      timeout: 10s
      retries: 3
```

---

## 6. Kafka Monitoring

### 6.1 Kafka UI Dashboard

- **URL**: `http://localhost:8080` (via kafka-ui container)
- **Features**: Topic browser, consumer group lag, message inspector
- **Key Metrics**: Consumer lag per topic, message throughput, partition distribution

### 6.2 Key Metrics to Watch

| Metric | Warning Threshold | Critical Threshold |
|--------|-------------------|-------------------|
| Consumer lag (any topic) | > 100 messages | > 1000 messages |
| Message processing time | > 5 seconds | > 30 seconds |
| Failed message delivery | > 1% | > 5% |
| Topic partition imbalance | > 20% skew | > 50% skew |

---

## 7. Monitoring Endpoints

### /api/monitoring (Next.js)

```typescript
GET /api/monitoring
Response:
{
  "status": "healthy",
  "timestamp": "2026-04-15T10:30:00.000Z",
  "services": {
    "database": { "status": "connected", "latency": 5 },
    "redis": { "status": "connected", "latency": 2 },
    "api": { "status": "connected", "latency": 15 },
    "aiService": { "status": "connected", "latency": 25 },
    "kafka": { "status": "connected" }
  },
  "metrics": {
    "activeUsers": 142,
    "ordersToday": 87,
    "avgResponseTime": 145,
    "errorRate": 0.003
  }
}
```

---

## 8. Alerting Strategy

| Alert | Condition | Action |
|-------|-----------|--------|
| High error rate | > 5% for 5 minutes | Notify admin, trigger investigation |
| Service down | Health check fails 3× | Auto-restart container, notify |
| High latency | P95 > 2 seconds for 10 min | Scale up, check DB queries |
| Kafka lag | > 1000 messages for 5 min | Check consumer, add partitions |
| Wallet anomaly | Single transaction > ₹50,000 | Flag for review, notify admin |
| AI confidence drop | Average < 0.5 for 100 decisions | Review model, check data quality |
