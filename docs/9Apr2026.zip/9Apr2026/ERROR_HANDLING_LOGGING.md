# DelegateCart — Error Handling & Logging

> Comprehensive documentation of error handling strategies, logging patterns, and debugging workflows.

---

## Table of Contents

1. [Error Handling Strategy](#error-handling-strategy)
2. [API Error Responses](#api-error-responses)
3. [Client-Side Error Handling](#client-side-error-handling)
4. [Logging Architecture](#logging-architecture)
5. [Audit Trail System](#audit-trail-system)
6. [Debug Workflows](#debug-workflows)

---

## Error Handling Strategy

### Layered Error Handling

```
┌──────────────────────────────────────────────────────────┐
│  Layer 1: UI Error Boundaries                            │
│  - React error boundaries catch render-time crashes      │
│  - Graceful fallback UI instead of white screen          │
├──────────────────────────────────────────────────────────┤
│  Layer 2: API Route Error Handling                        │
│  - try/catch in every route handler                       │
│  - Structured error responses with status codes           │
│  - console.error with prefixed context tags               │
├──────────────────────────────────────────────────────────┤
│  Layer 3: Database Error Handling                         │
│  - Connection pool retry with exponential backoff         │
│  - Transaction rollback on failure                        │
│  - Constraint violation → user-friendly messages          │
├──────────────────────────────────────────────────────────┤
│  Layer 4: External Service Error Handling                 │
│  - AI service: 5s timeout + AbortController               │
│  - Kafka: producer retry with idempotent writes           │
│  - Rule-based fallback when AI service is unavailable     │
└──────────────────────────────────────────────────────────┘
```

---

## API Error Responses

### Standard Error Format
```json
{
  "error": "Human-readable error message",
  "status": 400
}
```

### HTTP Status Code Usage

| Status | When Used | Example |
|--------|-----------|---------|
| `200` | Success | `{ "success": true, "record": {...} }` |
| `400` | Bad request / validation | Missing required `id` parameter |
| `403` | Unauthorized access | Non-admin accessing admin API |
| `404` | Resource not found | Learning record ID doesn't exist |
| `500` | Internal server error | Database query failure |

### Error Handling in Learning API
```typescript
// apps/web/app/api/admin/learning/route.ts
export async function PATCH(request: NextRequest) {
  if (!isAdmin(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }
  try {
    const body = await request.json();
    const { id, supervisedResponse, aiEnrichedResponse, isActive } = body;
    if (!id || typeof id !== 'number') {
      return NextResponse.json({ error: 'id is required' }, { status: 400 });
    }
    // ... handle update
  } catch (error: any) {
    console.error('[Learning API] PATCH error:', error.message);
    return NextResponse.json({ error: 'Failed to update record' }, { status: 500 });
  }
}
```

---

## Client-Side Error Handling

### Toast Notification Pattern
```typescript
// Used across admin dashboard, checkout flow, and settings pages
const showToast = useCallback((msg: string, type: 'success' | 'error') => {
  setToast({ msg, type });
  if (toastTimer.current) clearTimeout(toastTimer.current);
  toastTimer.current = setTimeout(() => setToast(null), 3000);
}, []);
```

### Optimistic Update with Rollback
```typescript
// isActive toggle example
handleToggleActive(id, currentValue) {
  // 1. Optimistic update (immediate UI feedback)
  setRecords(prev => prev.map(r => r.id === id ? { ...r, isActive: !currentValue } : r));
  // 2. Server sync
  const resp = await fetch('/api/admin/learning', { method: 'PATCH', ... });
  // 3. If error → toast error (no rollback needed since fetchRecords() re-syncs)
  if (!resp.ok) showToast('Toggle failed', 'error');
}
```

### React Query Error Handling
```typescript
const { data, error, isLoading } = useInfiniteProducts(filters, pageSize, isHydrated);
// Error displayed in UI via conditional rendering
{error && <ErrorBanner message={error.message} />}
```

---

## Logging Architecture

### Context-Tagged Logging

All server-side logs use prefixed tags for easy filtering:

| Tag | Source | Example |
|-----|--------|---------|
| `[Learning API]` | Admin learning CRUD routes | `[Learning API] PATCH error: ...` |
| `[Chat API]` | Chat message streaming | `[Chat API] Stream error: ...` |
| `[Intent API]` | Intent analysis endpoint | `[Intent API] Analysis failed: ...` |
| `[Learning]` | AI enrichment processing | `[Learning] Failed to enrich record 42: ...` |
| `[DB]` | Database connection/query | `[DB] Connection pool exhausted` |
| `[Wallet]` | Wallet operations | `[Wallet] Insufficient balance for user 1` |
| `[Kafka]` | Message queue operations | `[Kafka] Producer send failed: ...` |

### Docker Container Logs
```bash
# View logs for specific service
docker logs ai-commerce-web --tail 100 -f
docker logs ai-commerce-api --tail 100 -f
docker logs ai-commerce-ai-service --tail 100 -f

# Filter by tag
docker logs ai-commerce-web 2>&1 | grep "[Learning API]"
```

### Log Levels

| Level | Usage |
|-------|-------|
| `console.error()` | Caught exceptions, failed operations |
| `console.warn()` | Degraded functionality, fallback activations |
| `console.log()` | Request flow tracing (dev only) |

---

## Audit Trail System

### AuditLog Table
```sql
CREATE TABLE "AuditLog" (
  id SERIAL PRIMARY KEY,
  "userId" INTEGER REFERENCES "User"(id),
  action VARCHAR(100) NOT NULL,
  entity VARCHAR(100),
  "entityId" VARCHAR(100),
  details JSONB,
  "ipAddress" VARCHAR(45),
  "createdAt" TIMESTAMPTZ DEFAULT NOW()
);
```

### Audited Actions

| Action | Entity | Trigger |
|--------|--------|---------|
| `order.created` | Order | New order placement |
| `wallet.credit` | Wallet | Wallet top-up |
| `wallet.debit` | Wallet | Payment deduction |
| `learning.update` | SmartIntentEngineResponse | Supervised response edit |
| `learning.toggle` | SmartIntentEngineResponse | isActive flag toggle |
| `learning.delete` | SmartIntentEngineResponse | Record deletion |
| `auth.login` | User | Admin/elevated user login |

---

## Debug Workflows

### Common Issues & Resolution

| Symptom | Likely Cause | Debug Steps |
|---------|-------------|-------------|
| Products page shows unfiltered on return | Race condition (pre-hydration query) | Fixed with `isHydrated` gate on `useInfiniteProducts` |
| Learning records not loading | Admin auth failure | Check `localStorage.getItem('userEmail')` matches elevated email |
| isActive toggle fails | Network/DB error | Check `docker logs ai-commerce-web` for `[Learning API] PATCH error` |
| AI enrichment returns null | AI service timeout | Check `docker logs ai-commerce-ai-service`; falls back to rule-based engine |
| Wallet balance incorrect | Duplicate transactions | Verify `idempotencyKey` uniqueness in `WalletTransactionLog` |

### Health Check Endpoints
```
GET http://localhost:3000/api/health       → Web service health
GET http://localhost:3001/api/health       → API service health
GET http://localhost:8000/health           → AI service health
```

### Database Diagnostics
```sql
-- Check active connections
SELECT count(*) FROM pg_stat_activity WHERE datname = 'ai_commerce';

-- Check table sizes
SELECT relname, pg_size_pretty(pg_total_relation_size(relid))
FROM pg_stat_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 10;

-- Check SmartIntentEngineResponse stats
SELECT
  count(*) AS total,
  count(*) FILTER (WHERE "enhancedByAI" = true) AS ai_enriched,
  count(*) FILTER (WHERE "isActive" = true) AS active,
  count(*) FILTER (WHERE "isActive" = false) AS inactive
FROM "SmartIntentEngineResponse";
```
