# DelegateCart — Smart Intent Engine Documentation

## Document Metadata

| Field            | Value                                                           |
| ---------------- | --------------------------------------------------------------- |
| **Version**      | 1.0                                                             |
| **Last Updated** | April 2026                                                      |
| **Scope**        | Intent Parser, NLP pipeline, Kafka event chain, LLM integration |

---

## 1. Overview

The Smart Intent Engine converts natural language shopping requests into structured, actionable intents. It's the first stage of DelegateCart's autonomous shopping pipeline.

```
"Find me wireless earbuds under ₹3000 from Sony or JBL, deliver by Friday"
                    │
                    ▼
    ┌───────────────────────────────┐
    │       SMART INTENT ENGINE     │
    │  (Intent Parser - Port 3002)  │
    └───────────────┬───────────────┘
                    │
                    ▼
{
  "product": "wireless earbuds",
  "budgetMin": 1000,
  "budgetMax": 3000,
  "preferredBrands": ["Sony", "JBL"],
  "deliveryDate": "2026-04-18",
  "qualityScore": 70,
  "category": "electronics"
}
```

---

## 2. Architecture

### 2.1 Service Details

| Property     | Value                          |
| ------------ | ------------------------------ |
| Service      | `apps/intent-parser`           |
| Framework    | FastAPI 0.104                  |
| Language     | Python 3.11                    |
| Port         | 3002                           |
| LLM Primary  | OpenAI GPT-4                   |
| LLM Fallback | Anthropic Claude 3 Opus        |
| Messaging    | confluent-kafka                |
| Retry        | tenacity (exponential backoff) |

### 2.2 Pipeline Position

```
User → Buy Request → API → Kafka
                              │
                    ┌─────────▼──────────┐
                    │  INTENT PARSER     │ ← You are here
                    │  (Smart Intent)    │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │ PRODUCT AGGREGATOR │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  RANKING ENGINE    │
                    └────────────────────┘
```

---

## 3. Intent Extraction Process

### 3.1 Input Processing

```python
# models.py
class BuyRequestEvent(BaseModel):
    id: str
    userId: str
    productName: str
    budgetMin: Optional[float]
    budgetMax: Optional[float]
    qualityScore: Optional[int]        # 0-100
    preferredBrands: Optional[List[str]]
    deliveryDate: Optional[str]
    autoExecute: bool = False
    rawText: Optional[str]             # Original natural language input
```

### 3.2 LLM Prompt Engineering

```python
# prompts.py
INTENT_EXTRACTION_PROMPT = """
You are an AI shopping assistant that extracts structured purchase intent
from natural language shopping requests.

Given the following shopping request, extract:
1. Product name/type (normalized)
2. Budget range (min and max in INR)
3. Quality expectations (score 0-100)
4. Preferred brands (list)
5. Delivery requirements (date or urgency)
6. Category (electronics, fashion, home, food, sports, etc.)
7. Key features/specifications mentioned
8. Quantity needed

Respond in JSON format only.

Shopping Request: {user_input}
"""
```

### 3.3 LLM Provider Pattern

```python
# config.py
class Settings(BaseSettings):
    LLM_PROVIDER: str = "openai"           # 'openai' or 'anthropic'
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4"
    ANTHROPIC_API_KEY: Optional[str] = None
    ANTHROPIC_MODEL: str = "claude-3-opus-20240229"

# main.py
class IntentExtractor:
    async def extract(self, text: str) -> ProcessedIntent:
        try:
            return await self._call_primary(text)    # GPT-4
        except Exception as e:
            logger.warning(f"Primary LLM failed: {e}, trying fallback")
            return await self._call_fallback(text)   # Claude 3
        except Exception as e:
            logger.error(f"All LLMs failed: {e}")
            return self._rule_based_fallback(text)   # Regex extraction
```

### 3.4 Rule-Based Fallback

When both LLMs fail, a rule-based parser extracts basic intent:

```python
def _rule_based_fallback(self, text: str) -> ProcessedIntent:
    # Extract price with regex: ₹X, Rs X, under X, below X
    price_match = re.search(r'(?:₹|Rs\.?|INR)\s*(\d+[,\d]*)', text)

    # Extract brands: match against known brand list
    brands = [b for b in KNOWN_BRANDS if b.lower() in text.lower()]

    # Extract delivery: "by Friday", "tomorrow", "within X days"
    delivery = extract_delivery_date(text)

    # Product name: longest noun phrase
    product = extract_product_name(text)

    return ProcessedIntent(
        product=product,
        budgetMax=float(price_match.group(1)) if price_match else None,
        preferredBrands=brands,
        deliveryDate=delivery
    )
```

---

## 4. Kafka Integration

### 4.1 Consumer

```python
# Consumes from: buy_request.created
consumer = Consumer({
    'bootstrap.servers': KAFKA_BOOTSTRAP_SERVERS,
    'group.id': KAFKA_CONSUMER_GROUP,      # 'intent-parser-group'
    'auto.offset.reset': 'earliest'
})
consumer.subscribe(['buy_request.created'])
```

### 4.2 Producer

```python
# Publishes to: intent.processed
producer = Producer({
    'bootstrap.servers': KAFKA_BOOTSTRAP_SERVERS,
    'acks': 'all'                          # Ensure delivery
})

# Message format
{
    "buyRequestId": "br_123",
    "userId": "usr_456",
    "processedIntent": {
        "product": "wireless earbuds",
        "budgetMin": 1000,
        "budgetMax": 3000,
        "qualityScore": 70,
        "preferredBrands": ["Sony", "JBL"],
        "deliveryDate": "2026-04-18",
        "category": "electronics",
        "features": ["wireless", "noise-canceling", "bluetooth 5.0"],
        "quantity": 1
    },
    "confidence": 0.95,                    // Extraction confidence
    "llmProvider": "openai",               // Which LLM was used
    "processingTimeMs": 450,
    "traceId": "abc123..."                 // OpenTelemetry trace
}
```

---

## 5. Category Detection

### 5.1 Category Classification

The intent parser classifies products into categories for downstream routing:

| Category      | Keywords                        | Sub-categories                    |
| ------------- | ------------------------------- | --------------------------------- |
| `electronics` | phone, laptop, earbuds, speaker | mobile, computing, audio, display |
| `fashion`     | shirt, shoes, dress, watch      | clothing, footwear, accessories   |
| `home`        | furniture, decor, kitchen       | furniture, kitchen, decor, garden |
| `food`        | snacks, organic, fresh          | grocery, gourmet, health          |
| `sports`      | fitness, gym, cricket           | equipment, clothing, accessories  |
| `beauty`      | skincare, makeup, perfume       | skincare, haircare, fragrance     |
| `books`       | novel, textbook, fiction        | fiction, non-fiction, academic    |

### 5.2 allNameRelevant Logic

When `detectCategory()` returns a non-generic category:

- `allNameRelevant = true` — all search terms are relevant
- Minimum term length > 2 characters (filters noise words)
- This optimization improves search precision for category-specific queries

---

## 6. Error Handling

### 6.1 Error Types

| Error                 | Handling                                    |
| --------------------- | ------------------------------------------- |
| LLM timeout (>30s)    | Retry with exponential backoff (3 attempts) |
| LLM rate limit (429)  | Switch to fallback provider                 |
| Invalid JSON from LLM | Re-prompt with stricter format instructions |
| Kafka connection lost | Retry with backoff, buffer messages         |
| Malformed input       | Return partial intent with low confidence   |

### 6.2 Retry Configuration

```python
# Using tenacity
@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=30),
    retry=retry_if_exception_type((TimeoutError, RateLimitError))
)
async def call_llm(prompt: str) -> str:
    ...
```

---

## 7. Performance Characteristics

| Metric                   | Value                             |
| ------------------------ | --------------------------------- |
| Average processing time  | 400-800ms (with LLM call)         |
| Rule-based fallback time | <50ms                             |
| Kafka consume → produce  | <1 second                         |
| Confidence threshold     | 0.7 (below → low confidence flag) |
| Max concurrent requests  | 50 (limited by LLM API rate)      |

---

## 8. Configuration

| Env Variable                   | Default                  | Purpose                  |
| ------------------------------ | ------------------------ | ------------------------ |
| `LLM_PROVIDER`                 | `openai`                 | Primary LLM provider     |
| `OPENAI_API_KEY`               | —                        | OpenAI authentication    |
| `OPENAI_MODEL`                 | `gpt-4`                  | OpenAI model selection   |
| `ANTHROPIC_API_KEY`            | —                        | Anthropic authentication |
| `ANTHROPIC_MODEL`              | `claude-3-opus-20240229` | Anthropic model          |
| `KAFKA_BOOTSTRAP_SERVERS`      | `kafka:29092`            | Kafka broker address     |
| `KAFKA_CONSUMER_GROUP`         | `intent-parser-group`    | Consumer group ID        |
| `KAFKA_TOPIC_BUY_REQUEST`      | `buy_request.created`    | Input topic              |
| `KAFKA_TOPIC_INTENT_PROCESSED` | `intent.processed`       | Output topic             |
