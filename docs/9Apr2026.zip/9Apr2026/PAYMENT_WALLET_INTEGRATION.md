# DelegateCart — Payment, Wallet & AI Integration Documentation

## Document Metadata

| Field            | Value                                                                              |
| ---------------- | ---------------------------------------------------------------------------------- |
| **Version**      | 1.0                                                                                |
| **Last Updated** | April 2026                                                                         |
| **Scope**        | Digital wallet, payment methods, AI-authorized spending, transaction orchestration |

---

## 1. Wallet System Overview

DelegateCart's wallet is a **prepaid digital wallet** that supports:

- Manual top-up and spending
- AI-authorized autonomous spending (for agentic checkout)
- Hold/release pattern for pending approvals
- Full transaction audit trail
- Configurable spending limits (daily, weekly, monthly, per-order)

### Database Models

```
Wallet (1 per user)
├── WalletTransaction (N) — Every debit/credit/refund/hold/release
├── WalletAuthorization (N) — AI spending authorization tokens
├── WalletSpendingLimit (N) — User-defined spending rules
└── WalletAuditLog (N) — Detailed change audit
```

---

## 2. Wallet Schema

```prisma
model Wallet {
  id               String   @id @default(uuid())
  userId           String   @unique
  balance          Float    @default(0)
  currency         String   @default("INR")
  maxPerOrder      Float    @default(50000)
  dailyLimit       Float    @default(100000)
  isAiAuthorized   Boolean  @default(false)
  aiSpendingLimit  Float    @default(5000)
  isLocked         Boolean  @default(false)
  createdAt        DateTime @default(now())
  updatedAt        DateTime @updatedAt

  transactions     WalletTransaction[]
  authorizations   WalletAuthorization[]
  spendingLimits   WalletSpendingLimit[]
  auditLogs        WalletAuditLog[]
}
```

---

## 3. Transaction Types

| Type         | Direction  | Trigger                       |
| ------------ | ---------- | ----------------------------- |
| `topup`      | Credit (+) | User adds funds               |
| `debit`      | Debit (−)  | Purchase payment              |
| `refund`     | Credit (+) | Failed order refund           |
| `hold`       | Debit (−)  | Pending approval reservation  |
| `release`    | Credit (+) | Expired/rejected hold release |
| `adjustment` | Either     | Admin correction              |

### Transaction Lifecycle

```
topup:   pending → completed
debit:   pending → completed | failed → (auto-refund if failed)
refund:  pending → completed
hold:    pending → completed → released | captured
```

---

## 4. Transaction Orchestration (wallet-transactions.ts)

### 4.1 Architecture

```typescript
class TransactionOrchestrator {
  // Core operations
  executeDebit(walletId, amount, orderId, idempotencyKey): Promise<TransactionResult>;
  executeRefund(originalTxId): Promise<TransactionResult>;
  executeHold(walletId, amount, purpose): Promise<HoldResult>;
  releaseHold(holdId): Promise<void>;

  // Resilience
  replayFailedTransaction(txId): Promise<TransactionResult>;
  getTransactionStatus(txId): Promise<TransactionStatus>;

  // Validation
  validateSpendingLimits(walletId, amount): Promise<ValidationResult>;
  checkDailySpend(walletId): Promise<number>;
}
```

### 4.2 Idempotency Pattern

```
Request with idempotencyKey: "order-123-payment"
  │
  ▼
Check: SELECT * FROM WalletTransaction WHERE idempotencyKey = ?
  │
  ├── Found → Return cached result (no duplicate charge)
  │
  └── Not found → Execute transaction → Store with idempotencyKey
```

### 4.3 Debit Flow

```
executeDebit(walletId, amount, orderId, key)
  │
  ├── 1. Validate idempotency key (prevent duplicates)
  ├── 2. Lock wallet (SELECT FOR UPDATE)
  ├── 3. Check balance >= amount
  ├── 4. Check spending limits (daily, per-order)
  ├── 5. Create transaction record (status: pending)
  ├── 6. Deduct balance: wallet.balance -= amount
  ├── 7. Update transaction (status: completed, balanceAfter)
  ├── 8. Create audit log entry
  └── 9. Return TransactionResult
        │
        On Error → Rollback + Create failed transaction + Log
```

### 4.4 Refund Flow (Auto on Failure)

```
executeRefund(originalTxId)
  │
  ├── 1. Load original transaction
  ├── 2. Verify original was completed
  ├── 3. Create refund transaction (linked to original)
  ├── 4. Credit balance: wallet.balance += originalAmount
  ├── 5. Update refund status → completed
  └── 6. Notify user: "Refund of ₹X processed"
```

---

## 5. AI-Authorized Spending

### 5.1 Authorization Flow

```
User enables "AI Wallet Authorization" in wallet settings
  │
  ▼
Sets AI spending limit (default: ₹5,000)
  │
  ▼
AI identifies best product → price <= aiSpendingLimit?
  │         │
  │ Yes     │ No → Create ApprovalRequest (HITL)
  ▼
Check: Wallet.isAiAuthorized == true?
  │         │
  │ Yes     │ No → Block auto-checkout
  ▼
Create WalletAuthorization:
  { walletId, amount, purpose: "auto-checkout", expiresAt: +1h }
  │
  ▼
Execute debit with authorization reference
  │
  ▼
Log: AIDecisionLog + WalletAuditLog + WalletTransaction
```

### 5.2 Spending Limit Enforcement

```typescript
async function validateSpendingLimits(walletId: string, amount: number): Promise<boolean> {
  const wallet = await getWallet(walletId);
  const limits = await getSpendingLimits(walletId);

  // Per-order limit
  if (amount > wallet.maxPerOrder) return false;

  // Daily limit
  const todaySpend = await getTodaySpend(walletId);
  const dailyLimit = limits.find((l) => l.limitType === 'daily')?.amount || wallet.dailyLimit;
  if (todaySpend + amount > dailyLimit) return false;

  // Weekly limit (if set)
  const weeklyLimit = limits.find((l) => l.limitType === 'weekly');
  if (weeklyLimit) {
    const weekSpend = await getWeekSpend(walletId);
    if (weekSpend + amount > weeklyLimit.amount) return false;
  }

  // AI-specific limit
  if (isAiInitiated) {
    if (amount > wallet.aiSpendingLimit) return false;
  }

  return true;
}
```

---

## 6. Payment Methods

### 6.1 Supported Methods

| Method               | Status     | Integration                               |
| -------------------- | ---------- | ----------------------------------------- |
| **Digital Wallet**   | Active     | Internal wallet system                    |
| **Razorpay**         | Configured | `RAZORPAY_KEY_ID` + `RAZORPAY_KEY_SECRET` |
| **Cash on Delivery** | Active     | No payment processing                     |
| **UPI**              | Planned    | Via Razorpay                              |

### 6.2 Payment Method Enum

```typescript
enum PaymentMethod {
  WALLET = 'wallet',
  RAZORPAY = 'razorpay',
  COD = 'cod',
  UPI = 'upi',
}
```

### 6.3 Auto-Checkout Payment Methods

Configured via environment variable:

```
NEXT_PUBLIC_AUTO_CHECKOUT_PAYMENT_METHODS=wallet
```

When AI+ auto-checkout is active, **only wallet payment** is used (security guarantee — no external payment without explicit user action).

---

## 7. Wallet Dashboard UI

### 7.1 Features

- **Balance display**: Current balance with ₹ formatting (`toLocaleString('en-IN')`)
- **Quick top-up**: Preset amounts (₹500, ₹1000, ₹5000, ₹10000)
- **Transaction history**: Filterable by type, date range
- **Spending limits**: Configure daily/weekly/monthly/per-order
- **AI authorization**: Toggle + set AI spending cap
- **Auto-checkout sync**: Wallet settings sync with shopping list auto-checkout toggle

### 7.2 Auto-Checkout Sync

```
Wallet page: Enable AI authorization → Sync to shopping list
Shopping list: Enable auto-checkout → Check wallet authorization
  │
  If wallet not authorized → Prompt to enable in wallet settings
  If authorized → Use wallet for auto-purchases
```

---

## 8. Transaction Audit Trail

Every wallet operation creates multiple audit records:

```
WalletTransaction:
  { id, type, amount, status, balanceBefore, balanceAfter, idempotencyKey, metadata }

WalletAuditLog:
  { action, performer ('user'|'ai'|'system'), changesBefore, changesAfter, ipAddress }

AIDecisionLog (if AI-initiated):
  { traceId, decisionType, confidence, reasoning, successful }
```

---

## 9. Error Handling

| Scenario                 | Action                                   |
| ------------------------ | ---------------------------------------- |
| Insufficient balance     | Block transaction, notify user           |
| Spending limit exceeded  | Block transaction, show limit details    |
| Wallet locked            | Block all operations, admin intervention |
| Transaction timeout      | Mark as failed, auto-refund if debited   |
| Duplicate request        | Return cached result (idempotency)       |
| AI authorization expired | Re-prompt user for authorization         |
| Refund failure           | Alert admin, manual intervention         |
