# DelegateCart — Infographic Page Detailed Explanations

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Last Updated** | April 2026 |
| **Scope** | Complete explanation of all infographic and dashboard pages in DelegateCart |

---

## Table of Contents

1. [Analytics Dashboard](#1-analytics-dashboard)
2. [Smart Delegate (AI Results) Page](#2-smart-delegate-ai-results-page)
3. [Profile Page](#3-profile-page)
4. [Cart Page — Dual Product System](#4-cart-page--dual-product-system)
5. [Checkout Page — 4-Step Flow](#5-checkout-page--4-step-flow)
6. [Shopping List Page](#6-shopping-list-page)
7. [AI Chat Interface](#7-ai-chat-interface)

---

## 1. Analytics Dashboard

**Route:** `/admin/analytics`  
**Access:** Authenticated users only  
**Charts Library:** Recharts 3.8.0  
**Animation:** Framer Motion (staggered)

### Layout Overview

```
┌─────────────────────────────────────────────────────────────┐
│  Analytics Dashboard              [7 days ▼] [↻ Refresh]   │
├───────────┬───────────┬───────────┬─────────────────────────┤
│  Total    │  Unique   │ Conversion│   AI Success            │
│  Events   │  Users    │  Rate %   │    Rate %               │
│  12,450   │  3,210    │  4.2% ↑   │   78.5% ↑              │
│  📊       │  👥       │  🛒       │    🧠                   │
├───────────┴───────────┴───────────┴─────────────────────────┤
│                                                             │
│  ┌──── Daily Activity Trend (2/3) ────┐ ┌─ AI Outcomes ──┐ │
│  │                                    │ │                │ │
│  │  AreaChart: events per day         │ │  PieChart      │ │
│  │  X: date | Y: event count         │ │  (donut)       │ │
│  │  Gradient fill under curve         │ │                │ │
│  │  Tooltip: date + count             │ │  ● Clicked     │ │
│  │                                    │ │  ● Purchased   │ │
│  │                                    │ │  ● Ignored     │ │
│  └────────────────────────────────────┘ └────────────────┘ │
│                                                             │
│  ┌──── Top Products (BarChart) ────────────────────────────┐│
│  │                                                         ││
│  │  Horizontal bars: Views vs Conversions                  ││
│  │  Top 8 products by interaction                          ││
│  │  Blue bars = Views | Green bars = Conversions           ││
│  │                                                         ││
│  └─────────────────────────────────────────────────────────┘│
│                                                             │
│  ┌── AI Stats Summary (3-col) ─────────────────────────────┐│
│  │  Total AI Recs  │  Clicked Count  │  Purchased Count    ││
│  └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

### Metric Cards (Top Row)

| Metric | Icon | Calculation | Trend Indicator |
|--------|------|-------------|-----------------|
| **Total Events** | TrendingUp | `SUM(analytics_events)` in date range | Count |
| **Unique Users** | Users | `COUNT(DISTINCT userId)` in date range | Count |
| **Conversion Rate** | ShoppingCart | `(purchase events / total events) × 100` | ↑ green / ↓ red |
| **AI Success Rate** | Brain | `(clicked + purchased) / total_ai_recs × 100` | ↑ green / ↓ red |

### Chart Details

#### Daily Activity Trend (AreaChart)
- **Type:** Recharts `AreaChart` with gradient fill
- **Data Source:** `GET /api/analytics?days=N` → `dailyTrend[]`
- **X-Axis:** Date (formatted as short date)
- **Y-Axis:** Event count
- **Fill:** Linear gradient from blue (top) to transparent (bottom)
- **Tooltip:** Shows exact date and event count on hover
- **Responsive:** Adapts to container width

#### AI Recommendation Outcomes (PieChart)
- **Type:** Recharts `PieChart` with `innerRadius` (donut style)
- **Segments:**
  - **Clicked** (blue #6366f1) — user clicked an AI recommendation
  - **Purchased** (green #10b981) — AI recommendation led to purchase
  - **Ignored** (gray #94a3b8) — AI recommendation was not acted upon
- **Data Source:** `GET /api/analytics` → `aiStats`
- **Labels:** Percentage of total

#### Top Products (BarChart)
- **Type:** Recharts `BarChart` (horizontal layout)
- **Data Source:** `GET /api/analytics` → `topProducts[]`
- **Bars:** Two per product — Views (blue) and Conversions (green)
- **Max Items:** 8 products shown
- **Sorting:** By total interactions descending

### Interaction Features
- **Date Range Filter:** Dropdown — 7 / 30 / 90 days
- **Refresh Button:** Re-fetches all analytics data with loading spinner
- **Animations:** Framer Motion staggered fade-in (0.1s delay per element)
- **Dark Mode:** Full support with slate color palette

---

## 2. Smart Delegate (AI Results) Page

**Route:** `/smart-delegate`  
**Access:** Authenticated users only (redirects to `/signin` otherwise)  
**Data Source:** `localStorage.shoppingListResults`

### Layout Overview

```
┌─────────────────────────────────────────────────────────────┐
│  ┌─── Hero Banner (violet→indigo gradient) ───────────────┐ │
│  │  🤖 Smart Delegate — AI Shopping Assistant              │ │
│  │  "Your AI-powered shopping delegation results"          │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌── Stats Row ──────────────────────────────────────────┐  │
│  │  📋 Total Searches: 3     │  📦 Total Matches: 12    │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌── Info Flow Banner ───────────────────────────────────┐  │
│  │  Shopping List  →  AI Search  →  Score & Rank  →  Buy │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌── Submission Card #1 (Expandable) ────────────────────┐  │
│  │  🕐 2 hours ago | 2 items searched | 8 matches found  │  │
│  │  [WhatsApp ✓] [Email ✓]                               │  │
│  │                                                        │  │
│  │  ┌── Item: "Laptop" ─────────────────────────────────┐ │  │
│  │  │                                                    │ │  │
│  │  │  ┌─ Match Card ───┐  ┌─ Match Card ───┐          │ │  │
│  │  │  │ Dell XPS 15    │  │ HP Pavilion    │          │ │  │
│  │  │  │ ₹79,990       │  │ ₹74,990       │          │ │  │
│  │  │  │ ★ 4.6         │  │ ★ 4.3         │          │ │  │
│  │  │  │ AI: 87/100    │  │ AI: 82/100    │          │ │  │
│  │  │  │ [Add to Cart] │  │ [Add to Cart] │          │ │  │
│  │  │  └────────────────┘  └────────────────┘          │ │  │
│  │  └────────────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### Match Card Anatomy

```
┌─────────────────────────────────────────┐
│  🏅 Best Match                          │ ← Only for rank #1 (amber badge)
│                                         │
│  Dell XPS 15                            │ ← Product name (link if external)
│  Dell                                   │ ← Brand (small gray text)
│                                         │
│  ₹79,990                               │ ← Price (red if over budget)
│  ★ 4.6/5                               │ ← Rating with yellow star
│  92% match                              │ ← Match score badge
│                                         │
│  📅 3-5 days delivery                   │ ← Delivery estimate
│  ✓ EMI Available                        │ ← EMI badge (if applicable)
│  EXT                                    │ ← Source badge (amber for EXTERNAL)
│                                         │
│  ┌── AI Score Section ────────────────┐ │
│  │  🟣 AI Score: 87/100               │ │ ← Violet background badge
│  │  Confidence: 92%                    │ │
│  │                                     │ │
│  │  "High relevance to 'Laptop'.      │ │ ← AI explanation (italic)
│  │   Matches your brand preferences.   │ │
│  │   Highly rated (4.6/5)."           │ │
│  └─────────────────────────────────────┘ │
│                                         │
│  [ 🛒 Add to Cart ]                    │ ← Blue (INTERNAL) or Amber (EXTERNAL)
└─────────────────────────────────────────┘
```

### AI Score Breakdown

The AI Score badge displays the final weighted score. The explanation text describes which factors contributed most:

| Factor | Weight | Explanation Text Example |
|--------|--------|-------------------------|
| Relevance (30%) | Name/brand/keyword match | "High relevance to 'Laptop'" |
| Preference (25%) | User behavior history | "Matches your brand preferences" |
| Price Fit (20%) | Budget comparison | "Within your budget of ₹80,000" |
| Rating (15%) | Star rating | "Highly rated (4.6/5)" |
| Confidence (10%) | matchScore × 1.05 | "97% confidence" |

---

## 3. Profile Page

**Route:** `/profile`  
**Access:** Authenticated users only  
**Persistence:** Auto-save via PUT API on form changes

### Section Layout

```
┌─────────────────────────────────────────────────────────────┐
│  Profile Settings                              [💾 Save]    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌── 👤 Personal Information ────────────────────────────┐  │
│  │  First Name: [________]    Last Name: [________]      │  │
│  │  Email: user@example.com (read-only)                  │  │
│  │  Display Name: [________]  Alias: [________]          │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌── 💬 Communication ───────────────────────────────────┐  │
│  │  Preferred Email: [________________]                  │  │
│  │  WhatsApp: [+91 987 654 3210]                        │  │
│  │  ℹ️ Receive shopping list results, order updates       │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌── 📍 Saved Addresses ─────────────────────────────────┐  │
│  │  ┌─ Address 1 ──────────────────────────────────────┐ │  │
│  │  │  John Doe | +91 900 000 0000                     │ │  │
│  │  │  123 Main St, Mumbai 400001                      │ │  │
│  │  │  [Default Billing 💳] [Default Shipping 🏠]      │ │  │
│  │  │  [Edit ✏️] [Delete 🗑️]                           │ │  │
│  │  └──────────────────────────────────────────────────┘ │  │
│  │  [+ Add New Address]                                  │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌── 🤖 AI & Subscription ───────────────────────────────┐  │
│  │                                                        │  │
│  │  Subscription Plan:                                    │  │
│  │  ○ Basic — Standard features, manual checkout          │  │
│  │  ● AI Plus — AI scoring, auto-checkout, smart delegate │  │
│  │                                                        │  │
│  │  Preferred AI Model: [GPT-4 ▼]                        │  │
│  │                                                        │  │
│  │  Agentic Auto-Checkout: [═══●] ON                     │  │
│  │  Auto-approve limit: ₹5,000 [────────●──] ₹5,00,000  │  │
│  │  ☑ I accept the auto-checkout terms (view terms)      │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### Key Infographic Elements

| Element | Visualization | Purpose |
|---------|---------------|---------|
| Subscription Plan Toggle | Radio buttons with blue highlight + checkmark on selected | Visual plan comparison |
| Auto-Checkout Slider | Range input (₹100 → ₹5,00,000) | Budget threshold control |
| Default Address Badges | CreditCard / Home icons with blue bg | Quick identification of billing/shipping defaults |
| Section Cards | Rounded containers with icon headers | Grouped information display |
| Terms Modal | 8-section legal overlay | Auto-checkout consent |

---

## 4. Cart Page — Dual Product System

**Route:** `/cart`  
**Data Source:** `localStorage.cart` (JSON array)

### Visual Layout

```
┌──────────────────────────────────────────────────────────────┐
│  🛒 Shopping Cart (5 items)                                  │
├──────────────────────────────────────┬───────────────────────┤
│                                      │                       │
│  ┌── Item (INTERNAL) ─────────────┐  │  Order Summary        │
│  │  📦 Dell XPS 15                │  │                       │
│  │  ₹79,990   [- 1 +]   [🗑️]    │  │  Subtotal:  ₹81,489  │
│  │                                │  │  Tax (18%): ₹14,668  │
│  └────────────────────────────────┘  │  Shipping:  FREE      │
│                                      │  ─────────────────    │
│  ┌── Item (INTERNAL) ─────────────┐  │  Total:    ₹96,157   │
│  │  📦 Logitech Mouse             │  │                       │
│  │  ₹1,499    [- 1 +]   [🗑️]    │  │  ℹ️ Tax calculated    │
│  └────────────────────────────────┘  │  at checkout          │
│                                      │                       │
│  ┌── Item (EXTERNAL) ── ⚠ ──────┐  │  ⚠️ External products  │
│  │  📦 Samsung Galaxy S24   EXT  │  │  cannot be purchased  │
│  │  ₹74,999    [- 1 +]   [🗑️]  │  │  here (2 items)       │
│  │  ⚡ amber left border         │  │                       │
│  │  [🔗 View on Amazon]          │  │  [Proceed to Checkout │
│  └────────────────────────────────┘  │   (2 items)]          │
│                                      │                       │
│  ┌── Item (EXTERNAL) ── ⚠ ──────┐  │  [Continue Shopping]   │
│  │  📦 iPhone 16 Pro        EXT  │  │  [Clear Cart]         │
│  │  ₹1,29,999  [- 1 +]   [🗑️]  │  │                       │
│  │  ⚡ amber left border         │  │                       │
│  │  [🔗 View on Flipkart]        │  │                       │
│  └────────────────────────────────┘  │                       │
│                                      │                       │
├──────────────────────────────────────┴───────────────────────┤
│  Empty state: "Your cart is empty — start shopping!"         │
└──────────────────────────────────────────────────────────────┘
```

### Dual System Rules

| Aspect | INTERNAL Products | EXTERNAL Products |
|--------|-------------------|-------------------|
| **Border** | Default (no special styling) | Amber left border |
| **Badge** | None | "External" amber badge |
| **Checkout** | Included in subtotal/tax | **Excluded** from checkout |
| **Add to Cart** | Standard button | Adds with `source: "EXTERNAL"` |
| **Action** | Buy on DelegateCart | "View on [source]" external link |
| **Cart Button** | "Proceed to Checkout" | N/A (cannot purchase) |
| **Stock Warning** | Shows if quantity < 5 | Not tracked |

### Checkout Button Logic

```
If INTERNAL items > 0:
  Button enabled: "Proceed to Checkout (N items)"
  Only INTERNAL items sent to checkout

If ALL items are EXTERNAL:
  Button disabled: "No purchasable items"
  Amber warning banner shown

If cart empty:
  Empty state illustration shown
```

---

## 5. Checkout Page — 4-Step Flow

**Route:** `/checkout`  
**Access:** Authenticated, cart must have INTERNAL items

### Visual Step Indicator

```
┌─────────────────────────────────────────────────────────┐
│  Step 1         Step 2         Step 3         Step 4    │
│  ●─────────────○─────────────○─────────────○            │
│  Address       Shipping       Payment       Review      │
│  (current)                                              │
└─────────────────────────────────────────────────────────┘
```

### Step 1: Address Selection

```
┌─────────────────────────────────────────┐
│  Select Delivery Address                │
│                                         │
│  ● 123 Main St, Mumbai 400001          │
│    John Doe | +91 9000000000           │
│    [Default Billing 💳] [Default 🏠]  │
│                                         │
│  ○ 456 Park Ave, Delhi 110001          │
│    John Doe | +91 9111111111           │
│                                         │
│  [+ Add New Address]                    │
│                                         │
│  [Next →]                               │
└─────────────────────────────────────────┘
```

### Step 2: Shipping Method

| Option | Delivery Time | Cost |
|--------|---------------|------|
| Standard Delivery | 5-7 business days | **FREE** |
| Express Delivery | 2-3 business days | ₹99 |
| Overnight Delivery | Next business day | ₹299 |

### Step 3: Payment Method

| Method | Icon | Additional Fields |
|--------|------|-------------------|
| UPI / PhonePe / GPay | 📱 | UPI ID input |
| Credit / Debit Card | 💳 | Card number, expiry, CVV |
| Net Banking | 🏦 | Bank selection |
| Cash on Delivery | 💵 | None |
| EMI (No Cost) | 📅 | EMI tenure selection |

### Step 4: Review & Confirm

```
┌─────────────────────────────────────────┐
│  Order Review                           │
│                                         │
│  📍 Delivery: 123 Main St, Mumbai      │
│  🚚 Shipping: Standard (5-7 days)      │
│  💳 Payment: Credit Card               │
│                                         │
│  ─────────────────────────────────      │
│  Subtotal:    ₹81,489                   │
│  Shipping:    ₹0                        │
│  Tax (18%):   ₹14,668                   │
│  ─────────────────────────────────      │
│  Total:       ₹96,157                   │
│                                         │
│  [← Back]           [🛒 Place Order]    │
└─────────────────────────────────────────┘
```

### Post-Order Success Screen

```
┌─────────────────────────────────────────┐
│                                         │
│           ✅ Order Placed!              │
│                                         │
│     Order #ORD-20260415-A1B2           │
│                                         │
│  Thank you for your order. You'll       │
│  receive a confirmation at your email.  │
│                                         │
│  [🏠 Go to Dashboard]                  │
│  [🛍️ Continue Shopping]                │
│                                         │
└─────────────────────────────────────────┘
```

### Calculation Formula

```
subtotal = ∑(item.price × item.quantity)  // INTERNAL items only
shipping = SHIPPING_OPTIONS[selected].cost
tax      = Math.round(subtotal × 18) / 100  // Fixed precision
total    = subtotal + shipping + tax
```

---

## 6. Shopping List Page

**Route:** `/shopping-list`  
**Access:** Authenticated users only

### Form Layout

```
┌─────────────────────────────────────────────────────────────┐
│  🛍️ AI Shopping List                                        │
│  Tell us what you need — our AI finds the best matches      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌── Item #1 🛒 ────────────────────────────────────────┐  │
│  │  Product Name*: [Laptop___________]                   │  │
│  │  Preferred Brand: [Dell____________]                  │  │
│  │  Budget ₹: [80000]  Quantity*: [1]  Delivery: [5] d  │  │
│  │  Payment: [Credit Card ▼]  ☐ EMI Only                │  │
│  │                                              [🗑️]    │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌── Item #2 🛒 ────────────────────────────────────────┐  │
│  │  Product Name*: [Mouse____________]                   │  │
│  │  Preferred Brand: [Logitech________]                  │  │
│  │  Budget ₹: [2000]   Quantity*: [1]  Delivery: [3] d  │  │
│  │  Payment: [UPI ▼]   ☐ EMI Only                       │  │
│  │                                              [🗑️]    │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  [+ Add Another Item]                                       │
│                                                             │
│  ┌── Auto-Checkout Panel ────────────────────────────────┐  │
│  │  ☑ Enable auto-checkout for this list                 │  │
│  │                                                        │  │
│  │  ℹ️ Conditions:                                        │  │
│  │  • All items must be exact product match               │  │
│  │  • Payment method must match selection                 │  │
│  │  • Total within auto-payment limit (₹5,000)           │  │
│  │  • Items in stock in specified quantity                │  │
│  │                                                        │  │
│  │  ☑ I accept the auto-checkout terms (view terms)      │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                             │
│  ☐ Force fresh search (skip cache)                          │
│                                                             │
│  [🔍 Submit List for AI Search]                             │
│  — or —                                                     │
│  [🚀 Auto-Checkout] (when auto-checkout enabled)            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Item Field Validation

| Field | Required | Validation | Error Message |
|-------|----------|------------|---------------|
| Product Name | Yes | Alphanumeric, A-Z 0-9 spaces | "Product name must be alphanumeric" |
| Preferred Brand | No | Alphanumeric | "Brand name must be alphanumeric" |
| Budget | No | Numeric > 0 | "Budget must be a positive number" |
| Quantity | Yes | Integer ≥ 1 | "Quantity must be at least 1" |
| Delivery Days | No | Integer > 0 | N/A |
| Payment Method | No | Dropdown selection | N/A |
| EMI Only | No | Checkbox | N/A |

### After Submission

Results are saved to `localStorage.shoppingListResults` and user is redirected to the **Smart Delegate** page (`/smart-delegate`) where the AI-scored results are displayed in the Match Card format described in Section 2.

---

## 7. AI Chat Interface

**Route:** `/chat` (or embedded in sidebar)  
**Component:** Floating chat widget or full-page

### Layout

```
┌─────────────────────────────────────────┐
│  🤖 DelegateCart AI Assistant           │
├─────────────────────────────────────────┤
│                                         │
│  ┌── Bot Message ─────────────────────┐ │
│  │  Hi! I'm your AI shopping          │ │
│  │  assistant. What are you           │ │
│  │  looking for today?                │ │
│  └────────────────────────────────────┘ │
│                                         │
│         ┌── User Message ────────────┐  │
│         │  Best laptop under 80K     │  │
│         └────────────────────────────┘  │
│                                         │
│  ┌── Bot Message ─────────────────────┐ │
│  │  I found 4 laptops matching your   │ │
│  │  budget! Here are the top picks:   │ │
│  │                                    │ │
│  │  ┌─ Product Card ──────────────┐  │ │
│  │  │  Dell XPS 15 · ₹79,990     │  │ │
│  │  │  AI Score: 87 · ★ 4.6      │  │ │
│  │  │  [Add to Cart]             │  │ │
│  │  └────────────────────────────┘  │ │
│  │                                    │ │
│  │  ┌─ Product Card ──────────────┐  │ │
│  │  │  HP Pavilion · ₹74,990     │  │ │
│  │  │  AI Score: 82 · ★ 4.3      │  │ │
│  │  │  [Add to Cart]             │  │ │
│  │  └────────────────────────────┘  │ │
│  └────────────────────────────────────┘ │
│                                         │
├─────────────────────────────────────────┤
│  [Type your message...        ] [Send]  │
└─────────────────────────────────────────┘
```

### Chat Product Card

| Element | Description |
|---------|-------------|
| Product Name | Clickable (opens product or external URL) |
| Price | ₹ formatted with Indian numbering |
| AI Score | Badge with score out of 100 |
| Rating | Star rating out of 5 |
| Add to Cart | Adds to localStorage cart with source tag |
| Source Badge | "INTERNAL" or "EXTERNAL" |

### Conversation Flow

```
User message
    ↓
POST /api/chat/message {message, userId}
    ↓
NLP: Extract intent (13+ category maps)
    ↓
Product search: Match against catalog
    ↓
AI Scoring: 5-factor weighted algorithm
    ↓
Response: {reply: string, products: ScoredProduct[]}
    ↓
Render: Chat bubble with embedded product cards
    ↓
Behavior tracking: {action: "search", metadata: {query}}
```

---

## Summary — Pages at a Glance

| Page | Route | Charts Used | Key Infographic Feature |
|------|-------|-------------|------------------------|
| Analytics Dashboard | `/admin/analytics` | AreaChart, PieChart, BarChart | Metric cards with trend indicators |
| Smart Delegate | `/smart-delegate` | None (custom cards) | AI Score badges + score breakdown |
| Profile | `/profile` | None (form layout) | Subscription plan toggle, auto-checkout slider |
| Cart | `/cart` | None (list layout) | Dual INTERNAL/EXTERNAL product badges |
| Checkout | `/checkout` | None (stepper) | 4-step progress indicator |
| Shopping List | `/shopping-list` | None (form layout) | Auto-checkout conditions panel |
| AI Chat | `/chat` | None (chat UI) | Inline product cards with AI scores |
