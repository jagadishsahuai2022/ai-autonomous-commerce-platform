# DelegateCart — State Management Architecture

> Documentation of Zustand stores, session persistence, hydration patterns, and resolved race conditions.

---

## Overview

DelegateCart uses a hybrid state management approach:
- **Zustand stores** for cross-component state (sphere, product page, cart)
- **React useState** for component-local state (forms, modals, loading)
- **React Query** for server state (products, categories, search results)
- **sessionStorage** for navigation-persistent state (filters, scroll position, sphere dock state)

---

## Stores

### 1. Product Page Store (`lib/stores/product-page-store.ts`)

Persists filter/sort/scroll state across page navigations.

| State | Type | Persisted | Purpose |
|-------|------|:---------:|---------|
| `searchQuery` | string | ✅ | Active search text |
| `sortBy` | string | ✅ | Sort order (relevance, price-low, etc.) |
| `filterState` | Record | ✅ | Categories, price range, rating, delivery options |
| `scrollY` | number | ✅ | Scroll position for restoration |
| `sphereCategory` | string | ✅ | Last selected sphere category |
| `hasHydrated` | boolean | ❌ | Hydration guard (prevents double-init) |

**Session key**: `dc-product-page-store`

### 2. Sphere Store (`store/useSphereStore.ts`)

Controls the 3D category sphere's expanded/docked state.

| State | Type | Persisted | Purpose |
|-------|------|:---------:|---------|
| `selectedCategory` | string | ✅ | Currently selected category |
| `isSphereExpanded` | boolean | ✅ | Sphere overlay visible |
| `isSphereDocked` | boolean | ✅ | Sphere minimized to icon |
| `hasHydrated` | boolean | ❌ | Hydration guard |

**Session key**: `dc-sphere-v1`

---

## Hydration Flow

### Products Page Mount Sequence

```
Page Mount
  │
  ├─ [1] Persistence effects fire (searchQuery, sortBy, filterState)
  │       └─ hasMountedRef.current = false → ALL SKIP (no store writes)
  │
  ├─ [2] Hydration effect fires (useEffect with [] deps)
  │       ├─ useProductPageStore.getState().hydrate()
  │       ├─ Read hydrated values: searchQuery, sortBy, filterState
  │       ├─ Call setSearchQuery(), setSortBy(), setFilterState() with restored values
  │       ├─ useSphereStore.getState().hydrate()
  │       ├─ Restore sphereCategory if needed
  │       ├─ hasMountedRef.current = true  (enables persistence)
  │       └─ setIsHydrated(true)  ← GATES the product query
  │
  ├─ [3] Re-render with restored state
  │       ├─ serverFilters useMemo recalculates with restored filterState
  │       └─ isHydrated = true → useInfiniteProducts ENABLED
  │
  └─ [4] useInfiniteProducts fires with CORRECT filters
          └─ React Query fetches: GET /api/products?category=Sports&sortBy=price-low
```

### The Race Condition (FIXED)

**Before fix**: `useInfiniteProducts` fired during initial render with empty `filterState` (before hydration), fetching all products. When hydration restored the filter, React Query already had cached empty results.

**After fix**: `isHydrated` state is `false` until hydration completes. `useInfiniteProducts` has `enabled: isHydrated`, so it waits for the hydrated filter state before fetching.

```typescript
// products/page.tsx
const [isHydrated, setIsHydrated] = useState(false);

// In hydration effect:
hasMountedRef.current = true;
setIsHydrated(true);

// Query waits for hydration:
useInfiniteProducts(
  { category: serverFilters.category, ... },
  pageSize,
  isHydrated  // ← query disabled until true
);
```

---

## Persistence Effects Ordering

The order of `useEffect` declarations matters critically:

```
1. Persistence effects (searchQuery, sortBy, filterState)
   └─ Guard: if (!hasMountedRef.current) return;
   └─ On mount: hasMountedRef = false → SKIP (don't overwrite session with defaults)

2. Hydration effect
   └─ Restores from sessionStorage → calls setState → sets hasMountedRef = true
   └─ Now persistence effects will fire on future changes

3. URL param effect
   └─ Reads ?category=X from URL → sets filterState
   └─ Runs after hydration, so store values take priority unless URL overrides
```

---

## React Query Integration

### Query Key Structure
```
['products', 'list', 'infinite', { category: 'Sports', sortBy: 'price-low', pageSize: 20 }]
```

When `filterState` changes → `serverFilters` useMemo recalculates → new query key → cache miss → fresh fetch.

### Stale/GC Times
| Cache | Stale Time | GC Time |
|-------|-----------|---------|
| Product list | 2 min | 30 min |
| Product detail | 5 min | 1 hour |
| Search results | 30 sec | 10 min |

---

## Best Practices (Lessons Learned)

1. **Always gate initial queries on hydration** — `enabled: isHydrated` prevents stale-state fetches
2. **Use refs for mount guards, not state** — `hasMountedRef` prevents persistence effects from overwriting session data on mount
3. **Don't subscribe to full Zustand store** — Use `useSphereStore((s) => s.selectedCategory)` selectors, not `useSphereStore()`, to prevent excessive re-renders
4. **Hydrate both stores in the same effect** — Product page store and sphere store must hydrate together so `initialExpanded` prop calculation uses restored filter state
5. **Idempotent hydration** — `hasHydrated` flag in stores prevents double-hydration from React strict mode or fast refresh
