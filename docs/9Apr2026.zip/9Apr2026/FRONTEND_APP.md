# DelegateCart — Frontend Application Documentation

> **Framework**: Next.js 14 (App Router)  
> **UI**: Tailwind CSS + shadcn/ui + Framer Motion  
> **State**: React hooks + Context + Zustand  
> **Testing**: Vitest (unit) + Playwright (E2E)

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Page Structure](#page-structure)
3. [Component Hierarchy](#component-hierarchy)
4. [Custom Hooks](#custom-hooks)
5. [Services Layer](#services-layer)
6. [Library Modules](#library-modules)
7. [State Management](#state-management)
8. [Design System](#design-system)
9. [Testing](#testing)
10. [Build & Development](#build--development)

---

## Architecture Overview

```
apps/web/
├── app/                    # Next.js App Router pages
│   ├── api/                # API routes (serverless functions)
│   ├── products/           # Product pages
│   ├── checkout/           # Checkout flow
│   ├── orders/             # Order management
│   └── ...                 # 40+ page routes
├── components/             # Reusable UI components
│   ├── ui/                 # Base UI (shadcn/ui)
│   ├── product/            # Product components
│   ├── chat/               # Chat interface
│   ├── commerce/           # E-commerce components
│   └── ...
├── hooks/                  # Custom React hooks
├── services/               # API service layer
├── lib/                    # Core utilities
│   ├── db.ts               # PostgreSQL direct queries
│   ├── safe-api.ts         # Fetch with retry/backoff
│   ├── error-handling.ts   # Error utilities
│   ├── contexts/           # React contexts
│   ├── stores/             # Zustand stores
│   └── types/              # TypeScript types
├── test/                   # Unit tests
├── e2e/                    # E2E tests (Playwright)
└── public/                 # Static assets
```

---

## Page Structure

### Shopping Core

| Route            | Page           | Description                                                                             |
| ---------------- | -------------- | --------------------------------------------------------------------------------------- |
| `/`              | Homepage       | Hero section, stats (21K+ products, 95% AI confidence), CTA buttons                     |
| `/products`      | Products       | Dockable filter sidebar, grid with AI+ badges, search with 350ms debounce               |
| `/products/[id]` | Product Detail | Image gallery (420px max), 3D rotation, virtual try-on, tabs (Highlights/Specs/Reviews) |
| `/cart`          | Shopping Cart  | Cart items with product links (`/products/{id}`), quantity controls                     |
| `/checkout`      | Checkout       | Address, payment method (wallet), order creation with `fetchWithRetry`                  |
| `/wishlist`      | Wishlist       | Saved products                                                                          |

### Orders & Finance

| Route              | Page           | Description                                                        |
| ------------------ | -------------- | ------------------------------------------------------------------ |
| `/orders`          | Order List     | User orders with status badges, product thumbnails                 |
| `/orders/[id]`     | Order Detail   | Order items with images, links to product detail via `productSlug` |
| `/order-insights`  | Order Insights | Analytics on order history                                         |
| `/wallet`          | Wallet         | Balance display, transaction history                               |
| `/spending`        | Spending       | Spending analytics and trends                                      |
| `/budget-tracker`  | Budget Tracker | Budget tracking interface                                          |
| `/payment-methods` | Payments       | Manage payment methods                                             |
| `/price-alerts`    | Price Alerts   | Price monitoring                                                   |

### AI Features

| Route                 | Page               | Description                        |
| --------------------- | ------------------ | ---------------------------------- |
| `/ai-assistant`       | AI Assistant       | General AI chat interface          |
| `/shopping-assistant` | Shopping Assistant | AI-powered product recommendations |
| `/shopping-list`      | Shopping List      | Smart shopping list management     |
| `/ai-shopping-list`   | AI Shopping List   | AI-generated shopping lists        |
| `/smart-delegate`     | Smart Delegate     | Delegate shopping tasks to AI      |
| `/ai-plus`            | AI+                | Premium AI features                |
| `/ai-preferences`     | AI Preferences     | AI preference settings             |
| `/aibuy`              | AI Buy             | AI-powered buying                  |
| `/decision`           | Decision           | AI-assisted product comparison     |
| `/purchase-predictor` | Predictor          | Future purchase predictions        |

### Account & Settings

| Route        | Page      | Description                            |
| ------------ | --------- | -------------------------------------- |
| `/signin`    | Sign In   | Email/password login, demo credentials |
| `/signup`    | Sign Up   | User registration                      |
| `/account`   | Account   | Account settings                       |
| `/profile`   | Profile   | Profile management                     |
| `/security`  | Security  | Security settings                      |
| `/dashboard` | Dashboard | Main dashboard                         |

### Seller Features

| Route                     | Page             | Description               |
| ------------------------- | ---------------- | ------------------------- |
| `/sellers/dashboard`      | Seller Dashboard | Sales analytics, listings |
| `/sellers/profile`        | Seller Profile   | Seller profile management |
| `/sellers/create-listing` | Create Listing   | Product listing creation  |
| `/copilot`                | Seller Copilot   | AI assistance for sellers |

### Static Pages

| Route       | Page              |
| ----------- | ----------------- |
| `/about`    | About page        |
| `/contact`  | Contact page      |
| `/features` | Features overview |
| `/pricing`  | Pricing tiers     |
| `/blog`     | Blog section      |
| `/careers`  | Careers           |
| `/privacy`  | Privacy policy    |
| `/terms`    | Terms of service  |

---

## Component Hierarchy

### Product Components (`components/product/`)

#### AmazonProductCard

The primary product card used in the products grid.

**Key Features:**

- Hover action overlay with cart/wishlist/buy buttons (spring animations)
- "AI+" gradient badge (violet → cyan) on all products
- Cart feedback ("Added!") for 1.2 seconds
- Discount badge with percentage
- Trust score, delivery ETA, COD/EMI badges
- Star ratings display

**Props:**

```typescript
interface AmazonProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
  onWishlist?: (product: Product) => void;
  onBuyNow?: (product: Product) => void;
}
```

#### ProductFilters

Filter panel for the products page.

**Props:**

```typescript
interface ProductFiltersProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
}
```

### Chat Components (`components/chat/`)

| Component          | Description                      |
| ------------------ | -------------------------------- |
| `ChatWindow.tsx`   | Main chat container              |
| `ChatInput.tsx`    | Message input with send button   |
| `ChatMessage.tsx`  | Individual message display       |
| `ChatToggle.tsx`   | Floating chat toggle button      |
| `ShoppingChat.tsx` | Shopping-specific chat interface |

### UI Components (`components/ui/`)

Base shadcn/ui components: Button, Card, Badge, Input, Select, Dialog, Tabs, Toast, etc.

### Commerce Components

| Directory     | Components               |
| ------------- | ------------------------ |
| `commerce/`   | E-commerce specific UI   |
| `checkout/`   | Checkout workflow steps  |
| `approval/`   | HITL approval requests   |
| `comparison/` | Product comparison       |
| `decision/`   | Decision-making UI       |
| `order/`      | Order display components |

---

## Custom Hooks

### Core Hooks (`hooks/`)

| Hook                      | Description                                         |
| ------------------------- | --------------------------------------------------- |
| `useAuth.ts`              | Login, logout, session management, demo credentials |
| `useProducts.ts`          | Product fetching with filters, pagination, sorting  |
| `useCart.ts`              | Cart CRUD operations, optimistic updates            |
| `useOrders.ts`            | Order list fetching                                 |
| `useOrder.ts`             | Single order details                                |
| `useCheckout.ts`          | Checkout workflow state                             |
| `usePayments.ts`          | Payment processing                                  |
| `useAddresses.ts`         | Address CRUD                                        |
| `useAI.ts`                | AI feature operations                               |
| `useAutopilot.ts`         | Autopilot/automation features                       |
| `useChat.ts`              | Chat messaging                                      |
| `useShoppingAssistant.ts` | AI shopping assistant                               |
| `useBuyRequest.ts`        | Buy request operations                              |
| `useWebSocket.ts`         | WebSocket connections                               |
| `useToast.ts`             | Toast notifications                                 |
| `useApiErrorHandler.ts`   | Centralized error handling                          |

### Inline Hooks

#### useDebounce

Debounces a value by a specified delay. Used for search input (350ms).

```typescript
function useDebounce<T>(value: T, delay: number): T;
```

---

## Services Layer

### Service Files (`services/`)

| Service                | Methods                                      | Description                                      |
| ---------------------- | -------------------------------------------- | ------------------------------------------------ |
| `product.service.ts`   | getProducts, getProduct                      | Product API calls with `fetchWithRetry` fallback |
| `order.service.ts`     | getOrders, createOrder                       | Order management                                 |
| `cart.service.ts`      | getCart, addItem, removeItem, updateQuantity | Cart operations                                  |
| `auth.service.ts`      | login, register, logout, getSession          | Authentication                                   |
| `ai.service.ts`        | analyze, recommend, chat                     | AI endpoint calls                                |
| `analytics.service.ts` | track, getAnalytics                          | Analytics tracking                               |
| `seller.service.ts`    | getDashboard, createListing                  | Seller operations                                |
| `admin.service.ts`     | getStats, manageUsers                        | Admin operations                                 |

---

## Library Modules

### Core Libraries (`lib/`)

#### db.ts — Database Access

Direct PostgreSQL queries using `pg` pool.

**Key Functions:**

- `initDB()` — Create tables if not exists
- `ensureOrderItemSlug()` — Idempotent schema migration
- `createUser(email, password, name)` — User registration
- `getUserByEmail(email)` — User lookup
- `createOrder(userId, total, items[], ...)` — Order creation with productSlug
- `getUserOrders(userId)` — Orders with item details (productId, productSlug)
- `getOrderById(orderId)` — Single order with full item data
- `getWalletBalance(userId)` / `debitWallet()` / `creditWallet()` — Wallet ops

#### safe-api.ts — Fetch with Retry

Enterprise-grade fetch wrapper with exponential backoff.

**Key Exports:**

```typescript
// Exponential backoff: min(baseMs × 2^attempt + jitter, 10000ms)
function backoffDelay(baseMs: number, attempt: number): number;

// Safe API calls returning { data, error } objects
function safeGet<T>(url: string, options?): Promise<SafeResult<T>>;
function safePost<T>(url: string, body: any, options?): Promise<SafeResult<T>>;

// Drop-in fetch replacement that throws on failure
function fetchWithRetry(url: string, options?): Promise<Response>;
```

**Configuration:**

- `DEFAULT_RETRIES = 2`
- `MAX_RETRY_DELAY = 10000` (10 seconds)
- No retry on 4xx client errors
- Retry on 5xx and network errors

#### error-handling.ts — Error Utilities

**Key Exports:**

```typescript
function handleApiError(error: unknown): string;
function normalizeError(error: unknown): ErrorResponse;
function isNetworkError(error: unknown): boolean;
function isAuthError(error: unknown): boolean;
const ErrorCode: Record<string, string>; // NETWORK_ERROR, UNAUTHORIZED, etc.
```

#### formatting.ts — Data Formatting

Currency formatting (`formatPrice`), date formatting, number formatting.

#### ai-scoring.ts — AI Product Scoring

Product scoring algorithms with personalized weights for category, brand, price, quality, delivery, trending signals.

---

## State Management

### Context Providers (`lib/contexts/`)

React Context for auth state, cart state, and theme.

### Zustand Stores (`lib/stores/`)

Zustand for more complex global state (chat, preferences).

### URL State

Next.js `useSearchParams` for product filters, pagination, and sorting.

### Component State

React `useState` and `useRef` for local UI state (modals, hover, animations).

---

## Design System

### Theme

- **Light theme** — White/gray backgrounds, blue-600 primary accents
- All `dark:` Tailwind classes preserved for future dark mode toggle
- "AI+" gradient: `from-violet-600 to-cyan-600`

### Typography

- Font: System font stack
- Headings: `font-bold text-gray-900`
- Body: `text-gray-700`
- Muted: `text-gray-500`

### Spacing

- Page padding: `px-4 md:px-6 lg:px-8`
- Card padding: `p-3` to `p-4`
- Grid gaps: `gap-3` to `gap-4`

### Animations (Framer Motion)

- Card hover: `y: -3, boxShadow elevation`
- Button press: `scale: 0.9`
- Button hover: `scale: 1.15`
- Filter panel: `width 0↔264px`
- Mobile overlay: `spring damping:25, stiffness:300`
- Image modal: `AnimatePresence` fade in/out
- Product card overlay: slide up with fade

### Responsive Breakpoints

- Mobile: `< 768px`
- Tablet: `768px–1024px`
- Desktop: `> 1024px`
- Products grid: `grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4`

---

## Testing

### Unit Tests (Vitest)

**Configuration**: `vitest.config.ts`

- Environment: `jsdom`
- Excludes: `e2e/`, `test/e2e/`
- Path aliases: `@/` → `./`

**Test Files** (10 files, 252 tests):

| File                                       | Tests | Description                                         |
| ------------------------------------------ | ----- | --------------------------------------------------- |
| `test/unit/safe-api.test.ts`               | 11    | Exponential backoff, retry behavior, fetchWithRetry |
| `test/unit/payment-validation.test.ts`     | 29    | Payment validation logic                            |
| `test/unit/cart.test.ts`                   | 29    | Cart operations                                     |
| `test/unit/product-api.test.ts`            | 28    | Product API responses                               |
| `test/unit/product-card.test.tsx`          | 16    | AmazonProductCard rendering, interactions           |
| `test/unit/shopping-list.test.ts`          | 53    | Shopping list operations                            |
| `test/unit/mock-product-generator.test.ts` | 11    | Mock data generation                                |
| `test/unit/useAutopilot.test.ts`           | 10    | Autopilot hook                                      |
| `test/error-handling.test.ts`              | 33    | Error handling library                              |
| `test/lib/error-handling.test.ts`          | 32    | Error classification                                |

**Run**: `npx vitest run`

### E2E Tests (Playwright)

**Configuration**: `playwright.config.ts`

- Browser: Chromium
- baseURL: `http://127.0.0.1:3000`
- Video: `on`, Screenshot: `on`
- Timeout: 120s per test
- Global setup pre-warms all pages

**Key E2E Specs** (35+ spec files):

| Spec                                  | Tests | Description                                                |
| ------------------------------------- | ----- | ---------------------------------------------------------- |
| `e2e/products-redesign.spec.ts`       | 15    | Dockable filter, AI+ badges, hover actions, 3D view, modal |
| `e2e/pages.spec.ts`                   | 29    | All page loads, navigation, performance, accessibility     |
| `e2e/product-detail-enhanced.spec.ts` | 16    | Image gallery, tabs, buy now, related products, stock      |
| `e2e/product-links.spec.ts`           | 6     | Cart/checkout product links use `/products/{id}`           |
| `e2e/orders.spec.ts`                  | -     | Order flow tests                                           |
| `e2e/wallet-validation.spec.ts`       | -     | Wallet tests                                               |
| `e2e/shopping-assistant.spec.ts`      | -     | AI shopping tests                                          |
| `e2e/performance.spec.ts`             | -     | Performance benchmarks                                     |

**Run**: `npx playwright test`  
**Report**: `npx playwright show-report`

---

## Build & Development

### Prerequisites

- Node.js 18+
- pnpm 8+
- PostgreSQL 15+ (or Docker)
- Docker Desktop (optional, for full stack)

### Setup

```bash
# Install dependencies
pnpm install

# Start PostgreSQL (Docker)
docker-compose up -d postgres

# Start development server
cd apps/web
pnpm dev          # → http://localhost:3000

# Start NestJS backend (optional)
cd apps/api
pnpm start:dev    # → http://localhost:3001
```

### Environment Variables

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/delegatecart
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres
POSTGRES_DB=delegatecart

# Auth
JWT_SECRET=your-jwt-secret
NEXTAUTH_SECRET=your-nextauth-secret

# AI (placeholder — see AI_PAYMENT_API_CONFIG.md)
OPENAI_API_KEY=sk-placeholder
ANTHROPIC_API_KEY=sk-ant-placeholder

# Payments (placeholder)
RAZORPAY_KEY_ID=rzp_test_placeholder
RAZORPAY_KEY_SECRET=placeholder
```

### Key Commands

```bash
# Development
pnpm dev              # Start dev server
pnpm build            # Production build
pnpm start            # Start production server

# Testing
npx vitest run        # All unit tests (252 tests)
npx playwright test   # All E2E tests
npx playwright show-report  # View HTML report

# Database
npx prisma generate   # Generate Prisma client
npx prisma migrate    # Run migrations
npx prisma studio     # Database GUI
```

### Docker

```bash
docker-compose up -d            # Start all services
docker-compose up -d postgres   # Start only PostgreSQL
docker-compose logs -f          # Follow logs
```

---

_Last updated: 2025-05-30_
